"use client";

import { useState, type ReactNode } from "react";
import { Tip } from "@/components/ui";
import AssistantPersonal from "./assistant-personal";
import AiActivityView from "./ai-activity-view";

type Acct = { team_id: string; role: string } | null;

export default function AssistantView({ account, demo, toast, tools }: {
  account: Acct; demo: boolean; toast: (t: string) => void; tools: ReactNode;
  editable?: boolean; go?: (view: string) => void; addDnc?: unknown; onChanged?: () => void; dnc?: unknown;
}) {
  const [tab, setTab] = useState<"tools" | "activity" | "personal">("tools");
  return (
    <div className="app-page as-page">
      <header className="head">
        <div>
          <h1>
            Kestrel AI{" "}
            <Tip text="Score many leads at once with your own AI key, write their emails, customize tone and persona, and inspect the activity log of everything AI changed for your team." />
          </h1>
          <span className="sub">
            {tab === "tools"
              ? "Score many leads and write their emails at once"
              : tab === "activity"
              ? "Everything Kestrel AI changed for your team"
              : "Your AI, about you, and what it remembers"}
          </span>
        </div>
        <div className="head-actions">
          <div className="seg" role="tablist" aria-label="Kestrel AI sections">
            <button
              type="button"
              role="tab"
              aria-selected={tab === "tools"}
              className={tab === "tools" ? "on" : ""}
              onClick={() => setTab("tools")}
            >
              Score and write
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={tab === "activity"}
              className={tab === "activity" ? "on" : ""}
              onClick={() => setTab("activity")}
            >
              Activity
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={tab === "personal"}
              className={tab === "personal" ? "on" : ""}
              onClick={() => setTab("personal")}
            >
              Personalize
            </button>
          </div>
        </div>
      </header>
      {tab === "personal" ? (
        <AssistantPersonal account={account} demo={demo} toast={toast} />
      ) : tab === "activity" ? (
        <AiActivityView account={account} demo={demo} />
      ) : (
        <div className="as-tools">{tools}</div>
      )}
    </div>
  );
}
