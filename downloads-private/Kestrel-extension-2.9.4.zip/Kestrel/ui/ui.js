// Small DOM helpers and shared export. Scraped text only ever reaches the page through textContent.
(function (root) {
  const L = root.QuarryLib;
  const GLYPHS = {
    target: "M11 2h2v3.1a7 7 0 0 1 5.9 5.9H22v2h-3.1a7 7 0 0 1-5.9 5.9V22h-2v-3.1A7 7 0 0 1 5.1 13H2v-2h3.1A7 7 0 0 1 11 5.1V2zm1 5a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4z",
    sites: "M3 4h18v16H3V4zm2 2v2h14V6H5zm0 4v8h14v-8H5zm2 2h6v2H7v-2zm0 3h10v1.6H7V15z",
    sheet: "M3 3h18v18H3V3zm2 2v4h6V5H5zm8 0v4h6V5h-6zm-8 6v8h6v-8H5zm8 0v8h6v-8h-6z",
    down: "M11 3h2v10.2l3.6-3.6L18 11l-6 6-6-6 1.4-1.4 3.6 3.6V3zM4 19h16v2H4v-2z",
    up: "M11 16V6.8L7.6 10.2 6.2 8.8 12 3l5.8 5.8-1.4 1.4L13 6.8V16zM4 19h16v2H4z",
    filter: "M3 5h18v2H3zM6 11h12v2H6zM10 17h4v2h-4z",
    gauge: "M12 4a10 10 0 0 0-8.4 15.4l1.7-1.1a8 8 0 1 1 13.4 0l1.7 1.100A10 10 0 0 0 12 4zm4.700 4.900-5.400 4a2 2 0 1 0 2.400 2.400z",
    book: "M5 3h12a2 2 0 0 1 2 2v16H7a2 2 0 0 1-2-2V3zm2 14v2h10v-2H7zM8 6v2h8V6H8z",
    clock: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-1 5h2v5.600l3.600 2.100-1 1.700L11 13.700z",
    inbox: "M4 4h16l2 9v7H2v-7zM5.600 6 4.200 12H9a3 3 0 0 0 6 0h4.800l-1.400-6z",
    star: "M12 2.500l2.900 6.200 6.800.8-5 4.600 1.300 6.700-6-3.400-6 3.400 1.300-6.700-5-4.600 6.800-.8z",
    sparkle: "M12 2l2.200 6.800L21 11l-6.800 2.200L12 20l-2.200-6.800L3 11l6.800-2.200zM19 16l.9 2.100L22 19l-2.100.9L19 22l-.9-2.100L16 19l2.100-.9z",
    mail: "M2 6.500 12 13l10-6.500V5H2zM2 9v10h20V9l-10 6.500z",
    phone: "M6.600 2.500 10 6.200 8.200 9.100c1.200 2.700 3.900 5.400 6.700 6.700l2.900-1.800 3.700 3.400c.4.400.4 1 .1 1.400-1.200 1.700-3 2.700-5 2.200C9.700 19.400 4.600 14.300 3 7.400c-.5-2 .5-3.800 2.200-5 .4-.3 1-.3 1.400.1z",
    globe: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-1.500 2.200C9 6 8.100 8.700 8 11h8c-.1-2.300-1-5-2.500-6.800a8 8 0 0 0-3 0zM4.100 11H6c.1-2.200.8-4.400 1.800-6.100A8 8 0 0 0 4.100 11zm13.900 0h1.900a8 8 0 0 0-3.700-6.100c1 1.700 1.700 3.900 1.800 6.100zM4.100 13a8 8 0 0 0 3.700 6.100C6.800 17.400 6.100 15.200 6 13zM8 13c.1 2.300 1 5 2.500 6.800a8 8 0 0 0 3 0C15 18 15.900 15.300 16 13zm10 0c-.1 2.200-.8 4.400-1.800 6.100a8 8 0 0 0 3.700-6.100z",
    check: "M9.500 16.600 4.900 12l-1.400 1.400 6 6L21 7.900l-1.400-1.400z",
    xmark: "M6.400 5 12 10.600 17.600 5 19 6.400 13.400 12l5.600 5.600-1.400 1.400-5.600-5.600L6.400 19 5 17.600l5.600-5.600L5 6.400z",
    person: "M12 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10zM3 21c0-4.400 4-7 9-7s9 2.600 9 7z",
    sliders: "M4 6h9.200a2.500 2.500 0 0 1 4.600 0H20v2h-2.200a2.500 2.500 0 0 1-4.600 0H4zM4 16h2.200a2.500 2.500 0 0 1 4.600 0H20v2h-9.200a2.500 2.500 0 0 1-4.600 0H4z",
    list: "M8 5h13v2H8zM8 11h13v2H8zM8 17h13v2H8zM3 4.500h3v3H3zM3 10.500h3v3H3zM3 16.500h3v3H3z",
    plus: "M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z",
    eye: "M12 5c5 0 9 3.700 10.500 7C21 15.300 17 19 12 19S3 15.300 1.500 12C3 8.700 7 5 12 5zm0 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
    bookmark: "M6 3h12v18l-6-4-6 4z",
    trash: "M9 3h6l1 2h5v2H3V5h5zM5 9h14l-1 12H6z",
    layers: "M12 2 22 7l-10 5L2 7zM2 12l2.600-1.300L12 14.400l7.400-3.700L22 12l-10 5zM2 17l2.600-1.300L12 19.400l7.400-3.700L22 17l-10 5z",
    shield: "M12 2 4 5v6.200c0 4.900 3.400 9.300 8 10.800 4.600-1.500 8-5.900 8-10.800V5zm-1 13.400-3.700-3.700 1.400-1.400 2.300 2.300 4.900-4.900 1.400 1.400z",
    mic: "M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V5a3 3 0 0 1 3-3zm-7 9h2a5 5 0 0 0 10 0h2a7 7 0 0 1-6 6.900V21h3v2H8v-2h3v-3.100A7 7 0 0 1 5 11z",
    building: "M4 21V3h11v4h5v14h-6v-4h-4v4zm3-15v2h2V6zm4 0v2h2V6zM7 10v2h2v-2zm4 0v2h2v-2zm5 0v2h2v-2zM7 14v2h2v-2zm4 0v2h2v-2zm5 0v2h2v-2z",
    briefcase: "M9 3h6a2 2 0 0 1 2 2v2h4v13H3V7h4V5a2 2 0 0 1 2-2zm0 2v2h6V5zM5 9v4h14V9zm0 6v3h14v-3z",
    search: "M10 3a7 7 0 1 0 4.200 12.600l5.100 5.100 1.400-1.400-5.100-5.100A7 7 0 0 0 10 3zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10z",
  };
  const NS = "http://www.w3.org/2000/svg";

  function icon(name) {
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("class", "ico");
    const path = document.createElementNS(NS, "path");
    path.setAttribute("d", root.QuarryIconPaths[name] || GLYPHS[name] || "");
    if (!root.QuarryIconPaths[name]) path.setAttribute("fill-rule", "evenodd");
    svg.append(path);
    return svg;
  }

  function el(tag, props, ...kids) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === "class") node.className = v;
      else if (k === "text") node.textContent = v;
      else if (k.startsWith("on")) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v);
    }
    node.append(...kids.filter((k) => k !== null && k !== undefined));
    return node;
  }

  const safeUrl = (u) => (/^https?:\/\//i.test(String(u)) ? String(u) : "");

  // Kestrel mark (Ink): the letter K whose upper arm is a three-feather wing. Follows light/dark mode.
  function fillMark(target) {
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 32 32");
    const add = (tag, attrs) => { const n = document.createElementNS(NS, tag); Object.entries(attrs).forEach(([k, v]) => n.setAttribute(k, v)); svg.append(n); };
    add("rect", { width: "32", height: "32", rx: "7.5", style: "fill:var(--label)" });
    add("rect", { x: "7.6", y: "6", width: "4.4", height: "20", rx: "1.4", style: "fill:var(--card)" });
    [["M12 16Q19 12.8 25.2 5.4Q23.8 11.5 17.2 15.4Z", "1"], ["M12.1 16.9Q18.8 15.3 23.8 10.7Q21.9 14.8 16.9 16.9Z", "0.8"], ["M12.2 17.8Q17.6 17.2 21.6 15.1Q19.7 17.7 15.8 18.2Z", "0.6"]]
      .forEach(([d, o]) => add("path", { d, opacity: o, style: "fill:var(--card)" }));
    add("path", { d: "M14.6 18.6L24 26H19.5L12.6 20.2Z", style: "fill:var(--card)" });
    target.prepend(svg);
  }

  async function exportLeads(leads) {
    const groups = {};
    leads.forEach((l) => { (groups[L.exportFolder(l.source)] = groups[L.exportFolder(l.source)] || []).push(l); });
    const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
    for (const [folder, rows] of Object.entries(groups)) {
      const url = URL.createObjectURL(new Blob(["﻿" + L.leadsToCsv(rows)], { type: "text/csv" }));
      await chrome.downloads.download({ url, filename: await place(`kestrel/${folder}/${folder}_${rows.length}_${stamp}.csv`), conflictAction: "uniquify" });
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    }
    leads.forEach((l) => { l.exported = true; });
    await root.QuarryDB.putMany(leads);
  }

  // Each workspace saves into its own folder; raw=true keeps the path as given (guide files at kestrel/).
  const place = async (path, raw) => (!raw && root.QuarryProfile ? root.QuarryProfile.outPath(path) : path);
  async function saveFile(filename, text, type, raw, overwrite) {
    const url = URL.createObjectURL(new Blob([text], { type }));
    await chrome.downloads.download({ url, filename: await place(filename, raw), conflictAction: overwrite ? "overwrite" : "uniquify", saveAs: false });
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  async function loadSettings() { return L.mergeDefaults(await root.QuarryDB.get("settings", null)); }

  // Built-in keywords and locations, plus anything you imported.
  const EMPTY_LIB = () => ({ keywordGroups: [], countries: [] });
  async function loadLibrary() {
    const custom = await root.QuarryDB.get("customLibrary", null);
    root.QuarryActiveLibrary = custom ? L.mergeLibrary(root.QuarryLibrary, custom) : root.QuarryLibrary;
    return root.QuarryActiveLibrary;
  }
  async function importLibrary(kind, text, fileName) {
    let parsed = kind === "locations" ? L.parseLocationImport(text, fileName) : L.parseKeywordImport(text, fileName);
    if (kind === "niches") parsed = { keywordGroups: [], countries: [], ytNiches: parsed.keywordGroups.map((g) => ({ name: g.name, terms: g.items })) };
    const n = L.libraryCounts(parsed);
    n.terms = (parsed.ytNiches || []).reduce((k, g) => k + g.terms.length, 0);
    if (!(kind === "locations" ? n.places : kind === "niches" ? n.terms : n.keywords)) return null;
    const custom = await root.QuarryDB.get("customLibrary", EMPTY_LIB());
    await root.QuarryDB.set("customLibrary", L.mergeLibrary(custom, parsed));
    await loadLibrary();
    return { parsed, counts: n };
  }
  async function removeImported(kind, name) {
    const custom = await root.QuarryDB.get("customLibrary", EMPTY_LIB());
    if (kind === "group") custom.keywordGroups = custom.keywordGroups.filter((g) => g.name !== name);
    else if (kind === "niche") custom.ytNiches = (custom.ytNiches || []).filter((g) => g.name !== name);
    else custom.countries = custom.countries.filter((c) => c.name !== name);
    await root.QuarryDB.set("customLibrary", custom);
    await loadLibrary();
  }
  const activeLibrary = () => root.QuarryActiveLibrary || root.QuarryLibrary;
  function pickText(accept, handler) {
    const input = el("input", { type: "file", accept, hidden: "" });
    input.addEventListener("change", async () => { const file = input.files[0]; input.remove(); if (file) handler(await file.text(), file.name); });
    document.body.append(input);
    input.click();
  }

  // A full backup built straight from storage, in the same format as Back Up All, so either page can make one.
  async function buildBackup() {
    const DB = root.QuarryDB, s = await loadSettings();
    const parts = {
      leads: await DB.all(),
      rules: s.refine.rules,
      ai: s.ai,
      scoring: { weights: s.weights, tiers: s.tiers },
      settings: { limits: s.limits, refine: { ...s.refine, rules: undefined }, page: s.page, safety: s.safety },
      playbooks: await DB.get("playbooks", {}),
      views: await DB.get("views", {}),
      history: { maps: await DB.get("doneMaps", []), search: await DB.get("doneSearch", []), coverage: await DB.get("coverage", {}) },
      dnc: await DB.get("dnc", []),
      safety: { usage: await DB.get("usage", null), cooldown: await DB.get("cooldown", {}), daily: await DB.get("daily", null), searchLog: await DB.get("searchLog", []) },
      library: await DB.get("customLibrary", EMPTY_LIB()),
      selection: { pick: s.targets.pick, source: s.targets.source, youtube: s.targets.youtube },
    };
    const version = (root.chrome && chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : "";
    const ws = await DB.workspace();
    return { type: "quarry-backup", version: 1, app: version, at: Date.now(), workspace: ws.name, parts };
  }
  // Auto backup: one file that is replaced each time, so only the newest copy is kept.
  // Only when something changed. After a run it saves at once; otherwise at most once an hour (fewer download pop-ups).
  async function autoBackup(reason, force) {
    const DB = root.QuarryDB;
    try {
      const s = await loadSettings();
      if (s.backup && s.backup.auto === false && !force) return false;
      const last = await DB.get("autoBackup", { at: 0, count: -1 });
      const count = (await DB.keys()).length, activity = (await DB.get("activity", []))[0];
      const changed = count !== last.count || (activity && activity.at > last.at);
      const gap = reason === "run" ? 0 : 60 * 60000;
      if (!force && (!changed || Date.now() - last.at < gap)) return false;
      const data = await buildBackup();
      const url = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: "application/json" }));
      await chrome.downloads.download({ url, filename: await place("kestrel/backups/kestrel_auto_backup.json"), conflictAction: "overwrite", saveAs: false });
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      await DB.set("autoBackup", { at: Date.now(), count, reason: reason || "" });
      return true;
    } catch (_) { return false; }
  }

  // A small "?" circle. Click it to read a short note; click anywhere else (or scroll) to close it.
  // The note floats on the page itself, so no card, window or scroll area can cut it off.
  let openBubble = null;
  function closeTips() { if (openBubble) { openBubble.remove(); openBubble = null; } document.querySelectorAll(".tip.open").forEach((x) => x.classList.remove("open")); }
  function tip(text) {
    const box = el("span", { class: "tip" });
    const btn = el("button", { class: "tip-q", type: "button", "aria-label": "Help", text: "?", onclick: (e) => {
      e.preventDefault(); e.stopPropagation();
      const wasOpen = box.classList.contains("open");
      closeTips();
      if (wasOpen) return;
      box.classList.add("open");
      openBubble = el("div", { class: "tip-bubble", text });
      document.body.append(openBubble);
      placeTip(openBubble, btn);
    } });
    box.append(btn);
    return box;
  }
  function placeTip(b, q0) {
    const vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight, w = Math.min(260, vw - 16);
    const q = q0.getBoundingClientRect();
    b.style.width = `${w}px`;
    b.style.left = `${Math.max(8, Math.min(vw - w - 8, q.left + q.width / 2 - w / 2))}px`;
    const h = b.getBoundingClientRect().height;
    b.style.top = `${q.bottom + 6 + h > vh - 8 ? Math.max(8, q.top - 6 - h) : q.bottom + 6}px`;
  }
  if (typeof document !== "undefined") {
    document.addEventListener("click", (e) => { if (!e.target.closest || (!e.target.closest(".tip") && !e.target.closest(".tip-bubble"))) closeTips(); });
    document.addEventListener("scroll", closeTips, true);
  }
  // <span data-tip="…"></span> in a page becomes a "?" circle.
  function mountTips(scope) { (scope || document).querySelectorAll("[data-tip]").forEach((n) => { n.replaceWith(tip(n.getAttribute("data-tip"))); }); }
  root.QuarryUI = { tip, mountTips, icon, el, safeUrl, fillMark, exportLeads, saveFile, loadSettings, loadLibrary, importLibrary, removeImported, activeLibrary, pickText, EMPTY_LIB, buildBackup, autoBackup };
})(globalThis);
