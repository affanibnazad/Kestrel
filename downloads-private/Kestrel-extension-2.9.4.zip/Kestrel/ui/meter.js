// Live usage meter for the top corner of the side panel and the workspace.
// Plans: Google searches in the last 2 hours (ring + countdown) and new leads today.
// Owner copy: Safe daily Maps searches, with a countdown to midnight.
(function (root) {
  const UI = root.QuarryUI, DB = root.QuarryDB, L = root.QuarryLib, el = UI.el;
  const NS = "http://www.w3.org/2000/svg";

  function ring(frac, tone) {
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 20 20");
    svg.setAttribute("class", `mring ${tone}`);
    const C = 2 * Math.PI * 8;
    for (const [cls, dash] of [["bg", `${C} ${C}`], ["fg", `${Math.max(0, Math.min(1, frac)) * C} ${C}`]]) {
      const c = document.createElementNS(NS, "circle");
      c.setAttribute("cx", "10"); c.setAttribute("cy", "10"); c.setAttribute("r", "8");
      c.setAttribute("class", cls); c.setAttribute("stroke-dasharray", dash);
      svg.append(c);
    }
    return svg;
  }

  // "1h 12m", "12m 05s", "45s"
  function left(ms) {
    if (!(ms > 0)) return "now";
    const s = Math.ceil(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    return h ? `${h}h ${String(m).padStart(2, "0")}m` : m ? `${m}m ${String(sec).padStart(2, "0")}s` : `${sec}s`;
  }
  const tone = (frac, full) => (full ? "bad" : frac >= 0.8 ? "warn" : "ok");

  function mount(target) {
    let data = null;
    const box = el("button", { class: "meter", title: "Your limits. Click for details." });
    box.addEventListener("click", () => root.QuarryGate.licencePanel());
    target.replaceChildren(box);

    async function load() {
      const settings = await UI.loadSettings();
      const daily = await DB.get("daily", null);
      data = { plan: root.QuarryGate.plan(), searchLog: await DB.get("searchLog", []), today: daily && daily.date === L.todayKey() ? daily.count : 0, day: L.todayKey(),
        usage: L.usageToday(await DB.get("usage", null)), daily: (settings.safety.daily || {}).maps || 0, mine: Number(settings.limits.maxPerDay) || 0 };
      draw();
    }

    function draw() {
      if (!data) return;
      const p = data.plan, now = Date.now(), parts = [];
      if (p.searchesPerWindow) {
        const w = L.windowState(data.searchLog, p.windowHours || 2, p.searchesPerWindow, now);
        const frac = w.used / w.cap;
        parts.push(el("span", { class: "mpart" }, ring(frac, tone(frac, w.full)),
          el("span", { class: "mtext" }, el("b", { text: `${w.used}/${w.cap}` }), ` searches · ${w.full ? "frees in " : w.used ? "next frees in " : `${p.windowHours || 2}h window`}`,
            w.used ? el("b", { class: "mclock", text: left(w.resetAt - now) }) : null)));
      } else {
        const used = data.usage.maps || 0, cap = data.daily, frac = cap ? used / cap : 0;
        const midnight = new Date(); midnight.setHours(24, 0, 0, 0);
        parts.push(el("span", { class: "mpart" }, ring(frac, tone(frac, cap && used >= cap)),
          el("span", { class: "mtext" }, el("b", { text: `${used}/${cap || "∞"}` }), " Maps today · resets in ", el("b", { class: "mclock", text: left(midnight - now) }))));
      }
      // The real daily cap is the lower of your own "Leads per day" setting and your plan.
      const cap = root.QuarryPlans.tighter(data.mine, p.leadsPerDay);
      if (cap) {
        const used = L.todayKey() === data.day ? data.today : 0, frac = used / cap, full = used >= cap;
        const midnight = new Date(); midnight.setHours(24, 0, 0, 0);
        parts.push(el("span", { class: `mpart lead ${tone(frac, full)}`, title: p.leadsPerDay && cap < p.leadsPerDay ? `Your own setting (Limits → Leads per day) is ${cap.toLocaleString()}. Your plan allows up to ${p.leadsPerDay.toLocaleString()}.` : "" },
          el("b", { text: `${used.toLocaleString()}/${cap.toLocaleString()}` }), " leads today",
          full ? el("span", {}, " · resets in ", el("b", { class: "mclock", text: left(midnight - now) })) : null));
      }
      box.replaceChildren(...parts);
    }

    load();
    DB.onChange((what) => { if (["searchLog", "daily", "usage", "settings"].includes(what)) load(); });
    setInterval(draw, 1000);    // live countdown
    setInterval(load, 30000);   // pick up searches made in the other window
    return { refresh: load };
  }

  root.QuarryMeter = { mount, left };
})(globalThis);
