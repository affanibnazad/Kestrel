// YouTube niche and country picker for the side panel, with channel filters and progress.
// ctx: { cfg(), save(), coverage(), log(text, bad) }
(function (root) {
  const L = root.QuarryLib, UI = root.QuarryUI, { el, icon } = UI;
  const yt = () => UI.activeLibrary().youtube;

  function YtPicker(box, ctx) {
    let find = "";
    const opt = () => ctx.cfg().targets.youtube;
    const commit = () => { ctx.save(); render(); ctx.onChange(); };
    const toggle = (list, items, on) => { const s = new Set(list); items.forEach((i) => (on ? s.add(i) : s.delete(i))); return [...s]; };
    const tick = (on) => el("i", { class: `tick${on ? " on" : ""}` });
    const countries = () => opt().countries.map((n) => yt().countries.find((c) => c.name === n)).filter(Boolean);
    const places = () => (opt().countries.length ? opt().countries : [L.ANY_COUNTRY]);

    function nicheBlock(s) {
      const o = opt(), chosen = new Set(o.terms);
      const chips = yt().niches.map((n) => {
        const k = n.terms.filter((t) => chosen.has(t)).length, on = k === n.terms.length;
        return el("button", { class: `chip${on ? " on" : k ? " part" : ""}`, onclick: () => { o.terms = toggle(o.terms, n.terms, !on); commit(); } }, `${n.name} `, el("span", { class: "n", text: String(n.terms.length) }));
      });
      const q = find.toLowerCase();
      const rows = [];
      for (const n of yt().niches) {
        const terms = n.terms.filter((t) => !q || t.toLowerCase().includes(q) || n.name.toLowerCase().includes(q));
        if (!terms.length) continue;
        rows.push(el("div", { class: "areah", text: n.name }));
        for (const t of terms) {
          const on = chosen.has(t), st = s.perKeyword[t];
          rows.push(el("button", { class: "pickrow", onclick: () => { o.terms = toggle(o.terms, [t], !on); commit(); } },
            tick(on), el("span", { class: "nm", text: t }), on && st ? el("span", { class: `meta${st.done === st.total ? " ok" : ""}`, text: `${st.done}/${st.total}` }) : null));
        }
      }
      const input = el("input", { type: "search", placeholder: "Find niche or term", value: find, class: "ytfind" });
      input.addEventListener("input", () => { find = input.value; const at = input.selectionStart; render(); const f = box.querySelector(".ytfind"); f.focus(); f.setSelectionRange(at, at); });
      const all = yt().niches.flatMap((n) => n.terms);
      return [
        el("div", { class: "cap row" }, el("span", { text: "Niches" }), el("span", { class: "cnt", text: `${o.terms.length} search terms` })),
        el("div", { class: "group" },
          el("div", { class: "cell chips" }, ...chips),
          el("div", { class: "cell" }, icon("search"), input,
            el("button", { class: "link", text: "All", onclick: () => { o.terms = toggle(o.terms, all, true); commit(); } }),
            el("button", { class: "link", text: "Clear", onclick: () => { o.terms = []; commit(); } }),
            el("button", { class: "link", text: "Import", title: "Add search terms from a .txt or .csv file", onclick: importNiches })),
          el("div", { class: "picklist tall scroll" }, ...rows)),
      ];
    }

    function countryBlock(s) {
      const o = opt(), chosen = new Set(o.countries);
      const chips = yt().countries.map((c) => {
        const on = chosen.has(c.name), st = s.perPlace[c.name];
        const state = on && st ? L.placeState(st) : "none";
        return el("button", { class: `chip${on ? " on" : ""}`, onclick: () => { o.countries = toggle(o.countries, [c.name], !on); commit(); } },
          state !== "none" ? el("i", { class: `dot ${state}` }) : null, c.name);
      });
      return [
        el("div", { class: "cap row" }, el("span", { text: "Countries" }), el("span", { class: "cnt", text: o.countries.length ? `${o.countries.length} selected` : "Any country" })),
        el("div", { class: "group" },
          el("div", { class: "cell chips" }, ...chips),
          el("div", { class: "cell" }, el("span", { class: "muted", text: "None selected searches all countries." }),
            el("button", { class: "link", text: "All", onclick: () => { o.countries = yt().countries.map((c) => c.name); commit(); } }),
            el("button", { class: "link", text: "Clear", onclick: () => { o.countries = []; commit(); } }))),
      ];
    }

    function num(label, key, min, max, step) {
      const input = el("input", { type: "number", min: String(min), max: String(max), step: String(step || 1) });
      input.value = opt()[key];
      input.addEventListener("input", () => { opt()[key] = Number(input.value) || 0; clearTimeout(input.t); input.t = setTimeout(() => { ctx.save(); renderProgress(); }, 250); });
      return el("label", { class: "cell" }, el("span", { text: label }), input);
    }
    function sw(label, key, note) {
      const input = el("input", { type: "checkbox", class: "sw" });
      input.checked = !!opt()[key];
      input.addEventListener("change", () => { opt()[key] = input.checked; commit(); });
      return el("label", { class: "cell" }, el("span", {}, label, note ? el("em", { text: ` ${note}` }) : null), input);
    }

    function filterBlock(search) {
      return [
        el("div", { class: "cap", text: "Channel filters" }),
        el("div", { class: "group" },
          num("Minimum subscribers", "minSubs", 0, 1e9, 100), num("Maximum subscribers", "maxSubs", 0, 1e10, 1000), num("Minimum videos", "minVideos", 0, 100000),
          search ? num("Result pages per search", "pages", 1, 10) : null,
          search ? sw("Add country name to search", "addWord") : null, search ? sw("Channel country must match", "matchCountry") : null, search ? sw("Keep channels with no country", "keepUnknown") : null),
        el("p", { class: "foot-note", text: `${search ? "Each page holds about 20 channels. " : "Set minimum subscribers and videos to 0 to keep every channel. "}YouTube keeps the business email behind its own sign-in check, so Kestrel reads emails from the channel description and the channel's website instead.` }),
      ];
    }

    function listBlock() {
      const o = opt();
      const area = el("textarea", { rows: "8", placeholder: "@channelname\nhttps://www.youtube.com/@another\nhttps://www.youtube.com/channel/UC..." });
      area.value = o.list;
      const count = el("em", { text: countText() });
      function countText() { const n = L.parseChannelInput(opt().list).length; return n ? `${n} ${n === 1 ? "channel" : "channels"}` : ""; }
      area.addEventListener("input", () => { o.list = area.value; count.textContent = countText(); clearTimeout(area.t); area.t = setTimeout(() => ctx.save(), 300); });
      return [
        el("div", { class: "cap row" }, el("span", {}, "Channels to read ", UI.tip("Paste channel links, @handles or channel IDs, one per line, or import a file. Channels you already collected are skipped.")), el("button", { class: "link", text: "Import file", style: "margin-right:0", onclick: importList })),
        el("div", { class: "group" }, el("label", { class: "cell stack" }, el("span", {}, "Links, @handles or channel IDs, one per line ", count), area)),
      ];
    }

    function pageBlock() {
      return [
        el("div", { class: "cap row" }, el("span", {}, "Collect from the open page ", UI.tip("1. Open YouTube in this browser and search, or open a channel or video. 2. Scroll to load more results. 3. Click Collect page. Kestrel reads every channel on that page, also the channel behind each video. Comments and the sidebar are ignored."))),
      ];
    }

    function importList() {
      UI.pickText(".txt,.csv,text/plain,text/csv", async (text, name) => {
        const found = L.parseChannelInput(text);
        if (!found.length) return ctx.log(`No YouTube channel links found in ${name}.`, true);
        const o = opt();
        o.list = [...new Set([...L.parseChannelInput(o.list), ...found])].join("\n");
        ctx.log(`Added ${found.length} channels from ${name}.`);
        commit();
      });
    }

    function sourceSeg() {
      const o = opt(), list = [["niches", "Niches"], ["list", "Channel list"], ["page", "Open page"]];
      return el("nav", { class: "seg src", style: `--n:3;--i:${Math.max(0, list.findIndex((x) => x[0] === o.source))}` }, el("span", { class: "thumb" }),
        ...list.map(([v, t]) => el("button", { text: t, onclick: () => { o.source = v; commit(); } })));
    }

    function stats() { return L.coverageStats("youtube", opt().terms, places(), ctx.coverage()); }

    function progressBlock(s) {
      const done = Object.values(s.perPlace).filter((x) => L.placeState(x) === "done").length;
      const saved = Object.values(s.perPlace).reduce((n, x) => n + x.saved, 0);
      const left = s.total - s.done;
      return el("div", { class: "ytprog" },
        el("div", { class: "cap row" }, el("span", { text: "Progress" })),
        el("div", { class: "group" },
          el("div", { class: "cell prog" }, el("div", { class: "bar" }, el("i", { style: `transform:scaleX(${s.total ? s.done / s.total : 0})` })),
            el("div", { class: "nums" },
              el("div", {}, el("b", { text: String(s.done) }), el("span", { text: `of ${s.total} searches` })),
              el("div", {}, el("b", { text: String(done) }), el("span", { text: `of ${places().length} countries` })),
              el("div", {}, el("b", { text: String(saved) }), el("span", { text: "channels saved" })))),
          el("div", { class: "cell" }, el("span", { class: "muted", text: !s.total ? "Pick search terms to start." : left ? `${left} searches left` : "All searches in this selection are done." }))));
    }

    function renderProgress() {
      const node = box.querySelector(".ytprog");
      if (node) node.replaceWith(progressBlock(stats()));
    }

    function importNiches() {
      UI.pickText(".txt,.csv,text/plain,text/csv", async (text, name) => {
        const res = await UI.importLibrary("niches", text, name);
        if (!res) return ctx.log(`No search terms found in ${name}.`, true);
        const terms = res.parsed.ytNiches.flatMap((n) => n.terms);
        opt().terms = toggle(opt().terms, terms, true);
        ctx.log(`Imported ${terms.length} YouTube search terms from ${name}.`);
        commit();
      });
    }

    function render() {
      const s = stats();
      const scroller = box.closest(".body") || box.parentElement;
      const top = scroller.scrollTop, lists = [...box.querySelectorAll(".picklist")].map((n) => n.scrollTop);
      const src = opt().source || "niches";
      if (src === "list") box.replaceChildren(sourceSeg(), ...listBlock(), ...filterBlock(false));
      else if (src === "page") box.replaceChildren(sourceSeg(), ...pageBlock(), ...filterBlock(false));
      else box.replaceChildren(sourceSeg(), ...nicheBlock(s), ...countryBlock(s), ...filterBlock(true), progressBlock(s));
      box.querySelectorAll(".picklist").forEach((n, i) => { n.scrollTop = lists[i] || 0; });
      scroller.scrollTop = top;
    }

    return { render, selection: () => ({ terms: [...opt().terms], countries: countries() }) };
  }

  root.QuarryYtPicker = YtPicker;
})(globalThis);
