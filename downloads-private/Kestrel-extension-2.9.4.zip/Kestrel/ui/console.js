const L = QuarryLib, DB = QuarryDB, UI = QuarryUI;
const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const today = () => L.todayKey(); // local day, same as the safety counters
const SITES = [["instagram", "instagram.com"], ["facebook", "facebook.com"], ["linkedin", "linkedin.com/company"], ["x", "x.com"], ["tiktok", "tiktok.com"], ["youtube", "youtube.com"]];

let cfg;
const engine = { state: "idle", stop: false, pause: false, tab: null, run: null, known: new Set(), coverage: {}, usage: null, cooldown: {} };
const pickers = {};
let searchItem = null, pageLists = [], pageChoice = -1;

// ---- getters and setters for data-set paths
const read = (path) => path.split(".").reduce((o, k) => o[k], cfg);
function write(path, value) {
  const keys = path.split(".");
  keys.slice(0, -1).reduce((o, k) => o[k], cfg)[keys[keys.length - 1]] = value;
}
function pushFields() {
  document.querySelectorAll("[data-set]").forEach((f) => {
    if (f.type === "checkbox") f.checked = !!read(f.dataset.set); else f.value = read(f.dataset.set);
  });
  renderMeta();
}
const saveCfg = () => DB.set("settings", cfg).then(() => { if (globalThis.quarryMeter) globalThis.quarryMeter.refresh(); });

// ---- progress records, one per keyword and location search
async function loadCoverage() {
  let cov = await DB.get("coverage", null);
  if (!cov) {
    cov = L.migrateCoverage(await DB.get("doneMaps", []), await DB.get("doneSearch", []));
    await DB.set("coverage", cov);
  }
  // Connected to the Kestrel App? Add the team's progress, so nobody searches the same keyword and place twice.
  const team = globalThis.QuarryCloud ? await QuarryCloud.pullProgress() : null;
  if (team && Object.keys(team).length) { cov = L.mergeCoverage(cov, team); await DB.set("coverage", cov); }
  engine.coverage = cov;
}
async function record(item, status, numbers) {
  if (!item || !item.key) return;
  engine.coverage[item.key] = { status, at: Date.now(), ...numbers };
  await DB.set("coverage", engine.coverage);
  if (globalThis.QuarryCloud) QuarryCloud.pushProgress(item.key, engine.coverage[item.key]);
  const what = item.query || [item.keyword, item.location].filter(Boolean).join(" in ");
  DB.log("search", `${status === "done" ? "Finished" : "Stopped part way"}: ${what}. Saved ${Number((numbers || {}).saved) || 0}.`, { key: item.key, status, saved: Number((numbers || {}).saved) || 0 });
  renderPickers();
}
const fromLibrary = (mode) => cfg.targets.source[mode] === "library";
function targetsFor(mode) {
  if (engine.autopilot && engine.autopilot.mode === mode) return { keywords: engine.autopilot.keywords, locations: engine.autopilot.places };
  if (fromLibrary(mode)) return pickers[mode].selection();
  return mode === "maps"
    ? { keywords: L.parseLines(cfg.targets.keywords), locations: L.parseLines(cfg.targets.locations) }
    : { keywords: L.parseLines(cfg.targets.sKeywords), locations: L.parseLines(cfg.targets.sLocations) };
}
function renderPickers() {
  for (const mode of ["maps", "search", "osm"]) if (pickers[mode] && fromLibrary(mode) && cfg.mode === mode) pickers[mode].render();
  if (pickers.youtube && cfg.mode === "youtube") pickers.youtube.render();
  if (pickers.companies && cfg.mode === "companies") pickers.companies.render();
}

function log(text, bad) {
  const time = new Date().toTimeString().slice(0, 5);
  $("log").prepend(UI.el("li", bad ? { class: "bad" } : {}, UI.el("time", { text: time }), UI.el("span", { text })));
  while ($("log").children.length > 80) $("log").lastChild.remove();
}

function setState(state, text) {
  engine.state = state;
  $("lamp").dataset.state = state;
  const word = text || state;
  $("lampText").textContent = word[0].toUpperCase() + word.slice(1);
  const live = ["running", "paused", "cooling"].includes(state);
  $("start").disabled = live;
  $("pause").disabled = !live;
  $("stop").disabled = !live;
  $("pause").textContent = state === "paused" ? "Resume" : "Pause";
  const apRun = document.getElementById("apRun");
  if (apRun) apRun.disabled = live || apRun.textContent === "All searches done";
}

const status = (t) => { $("status").textContent = t; $("status").title = t; };

function renderDials() {
  const r = engine.run;
  if (!r) return;
  $("dFound").textContent = r.found;
  $("dSaved").textContent = r.saved;
  $("dEmail").textContent = r.emails;
  $("dA").textContent = r.a;
  const entries = Object.entries(r.rejected).sort((a, b) => b[1] - a[1]);
  $("filtered").textContent = entries.length ? `Filtered: ${entries.map(([k, v]) => `${k} ${v}`).join(" / ")}` : "";
  $("progress").style.transform = `scaleX(${r.total ? Math.min(1, r.step / r.total) : 0})`;
}

// Modes in this edition. A selling build can switch off the Google modes.
const enabledModes = () => ["maps", "search", "youtube", "osm", "jobs", "companies", "podcasts", "page", "sites"].filter((m) => L.featureOn(globalThis.QuarryLicenseConfig, m));

function renderMeta() {
  const kw = L.parseLines(cfg.targets.keywords).length, loc = L.parseLines(cfg.targets.locations).length;
  $("kwCount").textContent = kw ? String(kw) : "";
  $("locCount").textContent = loc ? String(loc) : "";
  const total = kw * loc;
  const minutes = Math.ceil(total * (Number(cfg.limits.delaySec) + 40) / 60);
  $("eta").textContent = total ? ` / ${total} searches, about ${minutes} min` : "";
  $("siteCount").textContent = L.parseLines(cfg.targets.sites).length || "";
  const r = cfg.refine;
  const on = [r.minRating, r.minReviews, r.maxReviews, r.includeWords, r.excludeWords, r.needEmail, r.businessEmailOnly, r.needWebsite, r.needPhone, r.needSocial, r.minQuality, r.minSocials, r.minChannels, r.needDescription, r.needAddress, r.emailMatchesSite].filter(Boolean).length;
  $("refineCount").textContent = on ? `${on} active` : "";
  document.querySelectorAll("#modes button").forEach((b) => b.classList.toggle("on", b.dataset.mode === cfg.mode));
  document.querySelectorAll("[data-jobs]").forEach((n) => { n.hidden = n.dataset.jobs !== (cfg.jobs || {}).from; });
  document.querySelectorAll("[data-pod]").forEach((n) => { n.hidden = n.dataset.pod !== (cfg.podcasts || {}).method; });
  if (cfg.mode === "companies") { const why = companiesFilterWarning(); $("chWarn").hidden = !why; $("chWarn").textContent = why; }
  document.querySelectorAll("section[data-for]").forEach((s) => { s.hidden = s.dataset.for !== cfg.mode; });
  document.querySelectorAll("#siteChips .chip").forEach((c) => {
    const on2 = c.dataset.site === "" ? !SITES.some((s) => s[1] === cfg.targets.site) : c.dataset.site === cfg.targets.site;
    c.classList.toggle("on", on2);
  });
  $("customWrap").hidden = SITES.some((s) => s[1] === cfg.targets.site);
  const label = { search: "Open next search", youtube: { niches: "Start", list: "Read channels", page: "Collect page" }[cfg.targets.youtube.source] || "Start", page: "Collect", jobs: "Check Jobs" }[cfg.mode] || "Start";
  $("start").textContent = label;
  $("pause").hidden = cfg.mode === "search";
  $("stop").hidden = cfg.mode === "search";
  document.querySelector(".actions").classList.toggle("two", cfg.mode === "search");
  collectBtn().hidden = cfg.mode !== "search";
  renderSafety();
  document.querySelectorAll("nav.src[data-src]").forEach((n) => {
    const lib = fromLibrary(n.dataset.src);
    n.style.setProperty("--i", lib ? 0 : 1);
    n.querySelectorAll("button").forEach((b) => b.classList.toggle("sel", b.dataset.v === cfg.targets.source[n.dataset.src]));
    $(n.dataset.src === "maps" ? "pickMaps" : "pickSearch").hidden = !lib;
    document.querySelector(`[data-custom="${n.dataset.src}"]`).hidden = lib;
  });
  renderPickers();
}

function collectBtn() {
  let btn = $("collectSearch");
  if (!btn) {
    btn = UI.el("button", { class: "btn", id: "collectSearch", text: "Collect page", onclick: collectSearch });
    document.querySelector(".actions").append(btn);
  }
  return btn;
}

// ---- pacing
async function wait(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end && !engine.stop) await sleep(Math.min(200, end - Date.now()));
}
async function gate() { while (engine.pause && !engine.stop) await sleep(200); }

async function pool(items, size, fn) {
  const queue = [...items];
  const worker = async () => {
    while (queue.length && !engine.stop) {
      const item = queue.shift();
      await gate();
      if (!engine.stop) await fn(item);
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, size) }, worker));
}

// Stop cancels whatever request is waiting right now (a slow map server, a website, a job board), not only the next step.
function stopSignal(ms) {
  const own = (engine.abort || (engine.abort = new AbortController())).signal, time = AbortSignal.timeout(ms);
  return AbortSignal.any ? AbortSignal.any([own, time]) : time;
}
async function beginRun(total) {
  engine.abort = new AbortController();
  engine.stop = false;
  engine.pause = false;
  // Tell Chrome a run is active, so an update waits until it ends (see background.js).
  chrome.storage.local.set({ runActive: Date.now() });
  clearInterval(engine.beat);
  engine.beat = setInterval(() => { chrome.runtime.sendMessage({ type: "quarry-running" }).catch(() => {}); chrome.storage.local.set({ runActive: Date.now() }); }, 20000);
  engine.known = new Set(await DB.keys());
  engine.dup = L.dupIndex(await DB.all());   // every business already in this workspace, from any source
  engine.queued = new Set();                 // leads of this run still being read (not saved yet)
  engine.robotsSkipped = 0;
  engine.run = { found: 0, saved: 0, emails: 0, a: 0, rejected: {}, step: 0, total, startedAt: Date.now(), searches: 0 };
  renderDials();
  setState("running");
}

function endRun(state, text) {
  clearInterval(engine.beat);
  chrome.storage.local.set({ runActive: 0 });
  const r = engine.run;
  if (engine.robotsSkipped) { log(`Skipped ${engine.robotsSkipped} website pages that ask robots not to read them.`); engine.robotsSkipped = 0; }
  Promise.resolve(flush()).then(() => {
    if (r && r.repeats) log(`${r.repeats} ${r.repeats === 1 ? "business was" : "businesses were"} already saved. New details were added to them.`);
    if (r && r.startedAt) DB.log("run", `Run ended: found ${r.found}, saved ${r.saved}, ${r.emails} emails${r.repeats ? `, ${r.repeats} repeats merged` : ""}.${text ? ` ${text}` : ""}`, { found: r.found, saved: r.saved });
    if (globalThis.QuarryCloud) QuarryCloud.flush().catch(() => {}).finally(renderSync); // everything goes to the Kestrel App
  });
  if (engine.state !== "halted") setState(state || "idle", text);
  $("progress").style.transform = "scaleX(0)";
}

const plan = () => QuarryGate.plan();
// Your own daily lead limit, or the plan's, whichever is lower.
const dayCap = () => QuarryPlans.tighter(cfg.limits.maxPerDay, plan().leadsPerDay);
async function dailyLeft() {
  const daily = await DB.get("daily", { date: today(), count: 0 });
  const cap = dayCap();
  return cap ? cap - (daily.date === today() ? daily.count : 0) : Infinity;
}
async function addDaily(n) {
  const daily = await DB.get("daily", { date: today(), count: 0 });
  await DB.set("daily", { date: today(), count: (daily.date === today() ? daily.count : 0) + n });
  if (globalThis.quarryMeter) globalThis.quarryMeter.refresh();
}

// Returns why the run must end, or "".
async function limitReached() {
  const r = engine.run, lim = cfg.limits;
  if ((Date.now() - r.startedAt) / 60000 >= Number(lim.maxRunMin)) return `Run time limit of ${lim.maxRunMin} minutes reached.`;
  if (Number(lim.maxPerRun) && r.saved >= Number(lim.maxPerRun)) return `Run limit of ${lim.maxPerRun} leads reached.`;
  if (await dailyLeft() <= 0) return `Daily limit of ${dayCap()} leads reached${dayCap() < Number(lim.maxPerDay) ? ` on the ${plan().name} plan` : ""}. Continue tomorrow.`;
  if (QuarryPlans.full(plan(), "maxLeads", engine.known.size)) return `Your ${plan().name} plan holds ${plan().maxLeads.toLocaleString()} leads. Remove old leads or upgrade.`;
  return "";
}

const reject = (reason) => { engine.run.rejected[reason] = (engine.run.rejected[reason] || 0) + 1; };

// ---- tabs and page scripts
function navigate(url) {
  return new Promise((resolve, reject2) => {
    const finish = (fn, v) => { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(on); fn(v); };
    const on = (id, info) => { if (id === engine.tab && info.status === "complete") finish(resolve); };
    const timer = setTimeout(() => finish(reject2, new Error("Page took too long to load")), 45000);
    chrome.tabs.onUpdated.addListener(on);
    (async () => {
      try {
        if (engine.tab === null) throw new Error("none");
        await chrome.tabs.update(engine.tab, { url, active: true });
      } catch (_) { engine.tab = (await chrome.tabs.create({ url })).id; }
    })().catch((e) => finish(reject2, e));
  });
}

async function call(tabId, files, func, args) {
  await chrome.scripting.executeScript({ target: { tabId }, files });
  const [hit] = await chrome.scripting.executeScript({ target: { tabId }, func, args: args || [] });
  return hit.result;
}

const HALT = {
  blocked: "Google asked for a verification check. Run stopped. Wait several hours before starting again.",
  consent: "Google is showing a consent page. Answer it in the tab, then start again.",
  ytblocked: "YouTube is limiting requests. Run stopped. Wait a few hours before starting again.",
  signedin: "You are signed in to a Google account in this browser. To protect that account, Kestrel will not search here. Use a separate Brave profile that is not signed in, or turn off 'Stop if signed in' under Safety.",
  ytsignedin: "You are signed in to YouTube in this browser. To protect that account, Kestrel will not search here. Use a separate Brave profile that is not signed in, or turn off 'Stop if signed in' under Safety.",
  safety: "",
  ytconsent: "YouTube is asking for cookie consent. Open youtube.com once in this browser, answer it, then start again.",
};
function halt(key, text) {
  const msg = text || HALT[key];
  log(msg, true); status(msg); setState("halted");
  // A verification check pauses that source for hours, so the next run cannot make it worse.
  const sources = { blocked: ["maps", "search"], ytblocked: ["youtube"] }[key];
  if (sources) pauseSources(sources);
}

// ---- safety: daily caps, pauses after a check, sign-in protection
async function loadSafety() {
  engine.searchLog = L.pruneSearchLog(await DB.get("searchLog", []));
  engine.usage = L.usageToday(await DB.get("usage", null));
  engine.cooldown = await DB.get("cooldown", {});
}
async function pauseSources(sources) {
  const until = Date.now() + Number(cfg.safety.cooldownHours || 12) * 3600000;
  sources.forEach((s) => { engine.cooldown[s] = until; });
  await DB.set("cooldown", engine.cooldown);
  renderSafety();
}
// Returns why this source cannot search now ("" when it can), and logs it.
async function safetyStop(source, pauseOnly) {
  engine.usage = L.usageToday(engine.usage);
  let why = pauseOnly ? L.safetyBlock(source, {}, engine.cooldown, { daily: {} }) : L.safetyBlock(source, engine.usage, engine.cooldown, cfg.safety);
  // Plan time limits (5 hours and 7 days), shared by every workspace.
  if (!why && !pauseOnly && L.WINDOW_SOURCES.includes(source)) why = L.windowBlock(engine.searchLog || [], plan());
  if (why) { const text = `Safety: ${why}.`; log(text, true); status(text); }
  return why;
}
async function countUse(source, n = 1) {
  engine.usage = L.usageToday(engine.usage);
  engine.usage[source] = (engine.usage[source] || 0) + n;
  await DB.set("usage", engine.usage);
  if (L.WINDOW_SOURCES.includes(source)) {
    const now = Date.now();
    engine.searchLog = L.mergeSearchLog(await DB.get("searchLog", []), Array.from({ length: n }, (_, i) => ({ at: now + i, s: source })));
    await DB.set("searchLog", engine.searchLog);
    if (globalThis.quarryMeter) globalThis.quarryMeter.refresh();
  }
  renderSafety();
}
async function googleSignedIn(tabId) {
  if (!cfg.safety.blockSignedIn) return false;
  try {
    // Safety: every signed-in selector is checked (live rules only add to the built-in ones, see core/rules.js).
    const sels = [...new Set([...(QuarryRules.get("google").signedIn || []), 'a[aria-label^="Google Account"]', 'a[href^="https://accounts.google.com/SignOutOptions"]'])];
    const [hit] = await chrome.scripting.executeScript({ target: { tabId }, args: [sels],
      func: (list) => list.some((s) => { try { return !!document.querySelector(s); } catch (_) { return false; } }) });
    return !!hit.result;
  } catch (_) { return false; }
}
const nextWait = () => L.pace(cfg.limits.delaySec, cfg.safety.jitter);

function renderSafety() {
  const box = $("safetyBox");
  if (!box || !engine.usage) return;
  const u = L.usageToday(engine.usage), d = cfg.safety.daily, now = Date.now();
  const lvl = cfg.safety.level;
  box.querySelectorAll("#safeSeg button").forEach((b) => b.classList.toggle("sel", b.dataset.v === lvl));
  $("safeSeg").style.setProperty("--i", ["safe", "balanced", "custom"].indexOf(lvl));
  const row = (label, used, cap) => UI.el("div", { class: "cell" }, UI.el("span", { text: label }), UI.el("span", { class: `muted${cap && used >= cap ? " bad" : ""}`, text: `${used} of ${cap || "no limit"}` }));
  const paused = Object.entries(engine.cooldown).filter(([, t]) => t > now);
  const p = plan(), win = L.windowState(engine.searchLog, p.windowHours || 2, p.searchesPerWindow);
  const when = (t) => (t ? new Date(t).toLocaleString(undefined, { weekday: "short", hour: "2-digit", minute: "2-digit" }) : "");
  const windowRow = (label, w) => UI.el("div", { class: "cell" }, UI.el("span", { text: label }), UI.el("span", { class: `muted${w.full ? " bad" : ""}`, text: `${w.used} of ${w.cap}${w.full ? `, frees up ${when(w.resetAt)}` : ""}` }));
  $("safeUse").replaceChildren(...(win.cap ? [windowRow(`Google searches, last ${p.windowHours || 2} hours (${p.name})`, win)] : []),
    row("Maps searches today", u.maps, d.maps), row("Google searches today", u.search, d.search), row("YouTube searches today", u.youtube, d.youtube), row("YouTube channels read today", u.ytChannels, d.ytChannels), row("OpenStreetMap searches today", u.osm || 0, d.osm), row("Job board checks today", u.jobs || 0, d.jobs), row("Companies House requests today", u.companies || 0, d.companies), row("Listen Notes requests today", u.podcasts || 0, d.podcasts),
    ...paused.map(([src, t]) => UI.el("div", { class: "cell" }, UI.el("span", { class: "bad", text: `${src === "youtube" ? "YouTube" : src === "maps" ? "Maps" : "Google Search"} paused until ${new Date(t).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}` }),
      UI.el("button", { class: "link", text: "End pause", onclick: async () => { if (!confirm("End this pause early? Searching again soon after a check raises the risk of a longer block.")) return; delete engine.cooldown[src]; await DB.set("cooldown", engine.cooldown); renderSafety(); } }))));
  $("safetyCount").textContent = paused.length ? "Paused" : { safe: "Safe", balanced: "Balanced", custom: "Custom" }[lvl];
}

// ---- website reading
// robots.txt rules per website, kept for this session. A missing or broken file means "allowed".
const robotsCache = new Map();
async function robotsOk(url) {
  if (!cfg.safety.respectRobots) return true;
  let u;
  try { u = new URL(url); } catch (_) { return false; }
  if (!robotsCache.has(u.origin)) {
    robotsCache.set(u.origin, (async () => {
      try {
        const r = await fetch(`${u.origin}/robots.txt`, { credentials: "omit", redirect: "follow", signal: stopSignal(5000) });
        return r.ok && /text\/plain/i.test(r.headers.get("content-type") || "text/plain") ? L.parseRobots((await r.text()).slice(0, 500000)) : [];
      } catch (_) { return []; }
    })());
  }
  return L.robotsAllows(await robotsCache.get(u.origin), u.pathname + u.search);
}

async function fetchPage(url, allowPrivate) {
  if (!(await robotsOk(url))) { engine.robotsSkipped = (engine.robotsSkipped || 0) + 1; return null; }
  const res = await fetch(url, { credentials: "omit", redirect: "follow", signal: stopSignal(Number(cfg.limits.siteTimeout) * 1000) });
  // A public website must not bounce us into your home or office network.
  const finalUrl = res.url || url;
  if (!allowPrivate && L.isPrivateHost(L.hostOf(finalUrl))) return null;
  if (!res.ok || !(res.headers.get("content-type") || "").includes("text/html")) return null;
  return { html: (await res.text()).slice(0, 2000000), url: finalUrl };
}

async function enrich(lead) {
  if (!lead.website) return;
  // Scraped links never reach your home or office network; only websites you type in Sites mode may be local.
  if (lead.source !== "site" && L.isPrivateHost(L.hostOf(lead.website))) { lead.website = ""; return; }
  const social = L.socialFromUrl(lead.website);
  if (social) { lead.socials[social.key] = lead.socials[social.key] || social.url; lead.website = ""; return; }
  try {
    const home = await fetchPage(lead.website, lead.source === "site").catch(() => null);
    lead.siteCheck = home ? "ok" : "down";
    lead.siteCheckedAt = Date.now();
    if (!home) return;
    const first = L.parseSite(home.html, home.url);
    let emails = [...lead.emails, ...first.emails];
    lead.socials = { ...first.socials, ...lead.socials };
    lead.description = lead.description || first.description;
    if (!lead.name) lead.name = (first.title || "").split(/\s[|\u2022\u00b7\u2013\u2014:-]\s/)[0].trim() || L.hostOf(home.url);
    if (!lead.phone && first.phones[0]) lead.phone = first.phones[0];
    let place = first.place;
    for (const link of first.contactLinks.slice(0, Number(cfg.limits.sitePages) - 1)) {
      if (emails.length || engine.stop) break;
      const page = await fetchPage(link, lead.source === "site").catch(() => null);
      if (page) {
        const parsed = L.parseSite(page.html, page.url);
        emails = [...emails, ...parsed.emails];
        lead.socials = { ...parsed.socials, ...lead.socials };
        if (!lead.phone && parsed.phones[0]) lead.phone = parsed.phones[0];
        place = place || parsed.place;
      }
    }
    L.applySiteAddress(lead, place);
    L.setEmails(lead, emails);
  } catch (_) { /* Unreachable site: the lead is kept without site data. */ }
}

let pending = [], flushTimer = null;
async function flush() {
  clearTimeout(flushTimer);
  flushTimer = null;
  if (!pending.length) return;
  const batch = pending;
  pending = [];
  await DB.putMany(batch);
  await addDaily(batch.length);
}

// Same business already saved (from any source: Maps, Search, OSM, pages, imports)? Then add what this copy
// knows to the lead you have, and don't save a second one. Returns true when it was a repeat.
async function sameBusiness(lead) {
  const id = engine.dup ? engine.dup.find(lead) : "";
  const keeper = id ? pending.find((l) => l.id === id) || await DB.one(id) : null;
  // Only a lead that is saved, or still being read in this run, counts. One your filters dropped does not.
  if (!keeper && !(id && engine.queued && engine.queued.has(id))) {
    if (engine.dup) engine.dup.add(lead);
    if (engine.queued) engine.queued.add(lead.id);
    return false;
  }
  if (keeper) {
    L.mergeSighting(keeper, lead);
    L.applyScore(keeper, cfg);
    if (!pending.includes(keeper)) await DB.putMany([keeper]);
  }
  reject(`already have this business${keeper ? ` (from ${L.SOURCE_LABEL[keeper.source] || keeper.source})` : ""}`);
  engine.run.repeats = (engine.run.repeats || 0) + 1;
  return true;
}

async function finishLead(lead) {
  L.setEmails(lead, lead.emails);
  // Second check after the website visit, when emails and the real website are known.
  if (await sameBusiness(lead)) return false;
  L.applyScore(lead, cfg);
  const reason = L.postFilter(lead, cfg.refine);
  if (reason) { reject(reason); return false; }
  pending.push(lead);
  if (!flushTimer) flushTimer = setTimeout(flush, 300);
  const r = engine.run;
  r.saved += 1;
  if (lead.email) r.emails += 1;
  if (lead.ruleMark === "Good") r.a += 1;   // "Marked Good" by a team rule (points and tiers removed in 2.9.4)
  renderDials();
  return true;
}

// ---- maps
async function runMaps() {
  const { keywords, locations } = targetsFor("maps");
  if (!keywords.length || !locations.length) return log("Pick at least one keyword and one location.", true);
  const queue = L.mapsQueue(keywords, locations, await DB.get("doneMaps", []), engine.coverage);
  if (!queue.length) return log("All these searches are already done.");
  if (await safetyStop("maps")) return;
  const lim = cfg.limits;
  await beginRun(Math.min(queue.length, Number(lim.maxSearches)));
  log(`Run started: ${engine.run.total} searches.`);
  let failures = 0;
  for (const item of queue.slice(0, Number(lim.maxSearches))) {
    await gate();
    if (engine.stop) break;
    const over = await limitReached();
    if (over) { log(over); status(over); break; }
    if (await safetyStop("maps")) { engine.run.safety = true; break; }
    status(item.query);
    const savedBefore = engine.run.saved;
    let found = 0;
    try {
      await navigate(L.buildMapsUrl(item.query));
      await countUse("maps");
      await wait(250);
      if (await googleSignedIn(engine.tab)) { halt("signedin"); break; }
      await QuarryRules.load();
      const page = await call(engine.tab, ["pages/maps.js"], (o) => globalThis.__quarryMaps(o), [{ scrollRounds: Number(lim.scrollRounds), maxPerSearch: Number(lim.maxPerSearch),
        rules: QuarryRules.get("maps"), blocked: QuarryRules.get("google")["re:blocked"] }]);
      if (HALT[page.status]) { halt(page.status); break; }
      const fresh = [];
      for (const p of page.places) {
        const id = L.placeKey(p.url, p.name, p.address);
        if (engine.known.has(id)) continue;
        engine.known.add(id);
        const lead = L.newLead("maps", { id, name: p.name, category: p.category, address: p.address, location: item.location, keyword: item.keyword,
          phone: p.phone, website: L.cleanWebsite(p.website), rating: p.rating, reviews: p.reviews, url: p.url.split("?")[0] });
        const reason = L.preFilter(lead, cfg.refine);
        if (reason) reject(reason); else if (!(await sameBusiness(lead))) fresh.push(lead);
      }
      engine.run.found += page.places.length;
      found = page.places.length;
      renderDials();
      status(`${item.query}: reading ${fresh.length} websites`);
      await pool(fresh, Number(lim.siteWorkers), async (lead) => { await enrich(lead); await finishLead(lead); });
      await flush();
      if (engine.stop) { await record(item, "partial", { found, saved: engine.run.saved - savedBefore }); break; }
      await record(item, "done", { found, fresh: fresh.length, saved: engine.run.saved - savedBefore });
      engine.run.step += 1;
      engine.run.searches += 1;
      renderDials();
      log(`${item.query}: ${page.places.length} found, ${fresh.length} new`);
      failures = 0;
    } catch (error) {
      failures += 1;
      log(`${item.query}: ${error.message}`, true);
      if (failures >= Number(lim.failStop)) { log("Stopped after repeated failures.", true); setState("halted"); break; }
    }
    if (engine.stop) break;
    const every = Number(lim.breakEvery);
    if (every && engine.run.searches && engine.run.searches % every === 0 && engine.run.step < engine.run.total) {
      setState("cooling");
      status(`Break for ${lim.breakMin} minutes`);
      await wait(Number(lim.breakMin) * 60000);
      if (!engine.stop) setState("running");
    } else if (engine.run.step < engine.run.total) {
      const ms = nextWait();
      status(`Next search in ${Math.round(ms / 1000)}s`);
      await wait(ms);
    }
  }
  if (!engine.run.safety && engine.state !== "halted") status(engine.stop ? "Stopped." : `Done. ${engine.run.saved} leads saved.`);
  endRun();
}

// ---- youtube: channel search through YouTube's own pages, then each channel's About page
// Links that are not the channel's own website: shorteners, payment, podcast and store platforms.
const NOT_A_SITE = /(^|\.)(bit\.ly|tinyurl\.com|t\.co|goo\.gl|ow\.ly|buff\.ly|rebrand\.ly|cutt\.ly|amzn\.to|geni\.us|smarturl\.it|youtu\.be|youtube\.com|patreon\.com|paypal\.me|paypal\.com|ko-fi\.com|buymeacoffee\.com|gofundme\.com|spotify\.com|apple\.com|amazon\.[a-z.]+|snapchat\.com|twitch\.tv|discord\.gg|discord\.com|teespring\.com|spreadshirt\.[a-z.]+|nytimes\.com|soundcloud\.com|bandcamp\.com|substack\.com|gumroad\.com|onlyfans\.com|cameo\.com|google\.com|forms\.gle)$/i;
const LINK_PAGES = /(^|\.)(linktr\.ee|beacons\.ai|linkin\.bio|lnk\.bio|campsite\.bio|bio\.link|carrd\.co|stan\.store)$/i;
const ytFiles = ["core/lib.js", "pages/youtube.js"];
// Every YouTube request runs inside a youtube.com tab, like a normal visit to the site.
async function ytCall(method, args) {
  const out = await call(engine.tab, ytFiles, (m, a) => globalThis.__quarryYt[m](...a), [method, args]);
  if (out && out.halt) throw Object.assign(new Error(out.halt), { halt: out.halt });
  if (out && out.error) throw new Error(out.error);
  return out;
}
async function ytOpenTab() {
  await navigate("https://www.youtube.com/?hl=en");
  await wait(1500);
  const st = await call(engine.tab, ytFiles, () => globalThis.__quarryYt.state());
  if (st.state !== "ok") throw Object.assign(new Error(st.state), { halt: st.state });
  if (st.signedIn && cfg.safety.blockSignedIn) throw Object.assign(new Error("signedin"), { halt: "signedin" });
}

function ytLead(ch, about, item) {
  const socials = { youtube: ch.url };
  let website = "", linkPage = "";
  for (const link of about ? about.links : []) {
    const social = L.socialFromUrl(link);
    if (social && social.key !== "youtube") { socials[social.key] = socials[social.key] || social.url; continue; }
    const host = L.hostOf(link);
    if (!host || NOT_A_SITE.test(host)) continue;
    if (LINK_PAGES.test(host)) { linkPage = linkPage || L.cleanWebsite(link); continue; }
    if (!website) website = L.cleanWebsite(link);
  }
  // A link page (Linktree and similar) is still worth reading for emails when there is no real site.
  website = website || linkPage;
  const description = (about && about.description) || ch.snippet || "";
  const country = about ? about.country : "";
  return L.newLead("youtube", { id: `yt:${ch.id}`, name: ch.name, category: `YouTube: ${item.keyword}`, description: description.slice(0, 1500),
    location: country || (item.location === L.ANY_COUNTRY ? "" : item.location), country, target: item.location, keyword: item.keyword, url: ch.url, website, socials,
    subscribers: about ? about.subs || ch.subs || 0 : ch.subs || 0, videos: about ? about.videos || ch.videos || 0 : ch.videos || 0, views: about ? about.views : 0,
    joined: about ? about.joined : "", ytEmailHidden: !!(about && about.hiddenEmail), emails: L.findEmails(description) });
}

// Reads each channel's About page and saves the ones that pass the filters.
// Channels from a search already carry an id; pasted or page channels only have a path until About is read.
async function ytProcess(list, item, checkCountry) {
  const o = cfg.targets.youtube, lim = cfg.limits;
  const fresh = [];
  for (const ch of list) {
    if (ch.id) {
      if (engine.known.has(`yt:${ch.id}`)) { reject("already collected"); continue; }
      engine.known.add(`yt:${ch.id}`);
      if (o.minSubs && ch.subs && ch.subs < Number(o.minSubs)) { reject("too few subscribers"); continue; }
      if (o.maxSubs && ch.subs > Number(o.maxSubs)) { reject("too many subscribers"); continue; }
    }
    fresh.push(ch);
  }
  status(`YouTube: reading ${fresh.length} channels`);
  await pool(fresh, Math.min(3, Number(lim.siteWorkers)), async (ch) => {
    const capWhy = L.safetyBlock("ytChannels", engine.usage = L.usageToday(engine.usage), {}, cfg.safety);
    if (capWhy) { if (!engine.stop) { engine.stop = true; const t = `Safety: daily limit of ${cfg.safety.daily.ytChannels} YouTube channel reads reached. Continue tomorrow.`; log(t, true); status(t); } return; }
    await countUse("ytChannels");
    let about = null;
    try { about = (await ytCall("about", [ch.path])).about; } catch (e) { if (e.halt) throw e; }
    if (!ch.id) {
      if (!about || !about.id) { reject("channel not found"); return; }
      if (engine.known.has(`yt:${about.id}`)) { reject("already collected"); return; }
      engine.known.add(`yt:${about.id}`);
      Object.assign(ch, { id: about.id, name: about.name || ch.name || ch.path.replace(/^\//, ""), url: `https://www.youtube.com${ch.path}` });
    }
    const info = { subs: about ? about.subs || ch.subs || 0 : ch.subs || 0, videos: about ? about.videos || ch.videos || 0 : ch.videos || 0, country: about ? about.country : "" };
    const why = L.ytCheck(info, checkCountry ? item.location : L.ANY_COUNTRY, o);
    engine.run.step += item.key ? 0 : 1;
    if (why) { reject(why); renderDials(); await wait(350); return; }
    const lead = ytLead(ch, about, item);
    const reason = L.preFilter(lead, cfg.refine);
    if (reason) reject(reason);
    else { await enrich(lead); await finishLead(lead); }
    renderDials();
    await wait(350);
  });
  await flush();
  return fresh.length;
}

const ytHalt = (e) => halt({ blocked: "ytblocked", signedin: "ytsignedin", safety: "safety" }[e.halt] || "ytconsent", e.halt === "safety" ? e.message : "");

function runYouTube() {
  return ({ niches: ytNiches, list: ytList, page: ytPage })[cfg.targets.youtube.source || "niches"]();
}

// Pasted or imported channel links.
async function ytList() {
  const paths = L.parseChannelInput(cfg.targets.youtube.list);
  if (!paths.length) return log("Paste or import at least one channel link or @handle.", true);
  if (await safetyStop("youtube", true)) return;
  await beginRun(paths.length);
  log(`Reading ${paths.length} channels from your list.`);
  try {
    await ytOpenTab();
    const item = { keyword: "Channel list", location: L.ANY_COUNTRY };
    engine.run.found = paths.length;
    await ytProcess(paths.map((path) => ({ path })), item, false);
    if (engine.state !== "halted" && !/^Safety/.test($("status").textContent)) status(engine.stop ? "Stopped." : `Done. ${engine.run.saved} channels saved.`);
  } catch (e) { if (e.halt) ytHalt(e); else log(e.message, true); }
  endRun();
}

// Channels on the YouTube page you have open in the browser.
async function ytPage() {
  const tab = await targetTab();
  if (!tab || !/^https:\/\/(www\.|m\.)?youtube\.com\//.test(tab.url || "")) return log("Open a YouTube page first: a search, a channel or a video.", true);
  const res = await call(tab.id, ytFiles, () => globalThis.__quarryYt.pageChannels());
  if (!res.channels.length) return log("No channels found on this page. Scroll to load more, then try again.", true);
  if (await safetyStop("youtube", true)) return;
  await beginRun(res.channels.length);
  engine.tab = tab.id;
  engine.run.found = res.channels.length;
  log(`Found ${res.channels.length} channels on this ${res.page} page.`);
  try {
    let label = "Open page";
    try { label = `Page: ${decodeURIComponent((new URL(tab.url).searchParams.get("search_query") || "").replace(/\+/g, " ")) || res.page}`; } catch (_) { /* keep default */ }
    await ytProcess(res.channels, { keyword: label, location: L.ANY_COUNTRY }, false);
    if (engine.state !== "halted" && !/^Safety/.test($("status").textContent)) status(engine.stop ? "Stopped." : `Done. ${engine.run.saved} channels saved.`);
  } catch (e) { if (e.halt) ytHalt(e); else log(e.message, true); }
  engine.tab = null;
  endRun();
}

// Niche and country searches, tracked in progress.
async function ytNiches() {
  const { terms, countries } = pickers.youtube.selection();
  if (!terms.length) return log("Pick at least one niche or search term.", true);
  const o = cfg.targets.youtube, lim = cfg.limits;
  const queue = L.ytQueue(terms, countries, o.addWord, engine.coverage);
  if (!queue.length) return log("All these YouTube searches are already done.");
  if (await safetyStop("youtube")) return;
  await beginRun(Math.min(queue.length, Number(lim.maxSearches)));
  log(`YouTube run started: ${engine.run.total} searches.`);
  try { await ytOpenTab(); } catch (e) { if (e.halt) ytHalt(e); else log(e.message, true); return endRun(); }
  let failures = 0;
  for (const item of queue.slice(0, Number(lim.maxSearches))) {
    await gate();
    if (engine.stop) break;
    const over = await limitReached();
    if (over) { log(over); status(over); break; }
    if (await safetyStop("youtube")) { engine.run.safety = true; break; }
    status(`YouTube: ${item.query}`);
    const savedBefore = engine.run.saved;
    try {
      const pages = Math.max(1, Math.min(10, Number(o.pages) || 1));
      const found = (await ytCall("search", [item.query, item.gl, pages])).channels.slice(0, Number(lim.maxPerSearch));
      await countUse("youtube");
      engine.run.found += found.length;
      renderDials();
      const fresh = await ytProcess(found, item, true);
      if (engine.stop) { await record(item, "partial", { found: found.length, saved: engine.run.saved - savedBefore }); break; }
      await record(item, "done", { found: found.length, fresh, saved: engine.run.saved - savedBefore });
      engine.run.step += 1;
      engine.run.searches += 1;
      renderDials();
      log(`${item.query}: ${found.length} channels, ${engine.run.saved - savedBefore} saved`);
      failures = 0;
    } catch (error) {
      if (error.halt) { ytHalt(error); break; }
      failures += 1;
      log(`${item.query}: ${error.message}`, true);
      if (failures >= Number(lim.failStop)) { log("Stopped after repeated failures.", true); setState("halted"); break; }
    }
    if (engine.stop) break;
    const every = Number(lim.breakEvery);
    if (every && engine.run.searches && engine.run.searches % every === 0 && engine.run.step < engine.run.total) {
      setState("cooling");
      status(`Break for ${lim.breakMin} minutes`);
      await wait(Number(lim.breakMin) * 60000);
      if (!engine.stop) setState("running");
    } else if (engine.run.step < engine.run.total) {
      const ms = nextWait();
      status(`Next search in ${Math.round(ms / 1000)}s`);
      await wait(ms);
    }
  }
  if (!engine.run.safety && engine.state !== "halted") status(engine.stop ? "Stopped." : `Done. ${engine.run.saved} channels saved.`);
  endRun();
}

// ---- search (one page at a time)
const currentSite = () => (SITES.some((s) => s[1] === cfg.targets.site) ? cfg.targets.site : cfg.targets.customSite.trim() || cfg.targets.site);

async function openNextSearch() {
  const { keywords, locations } = targetsFor("search");
  if (!keywords.length) return log("Pick at least one keyword.", true);
  if (await safetyStop("search")) return;
  const queue = L.searchQueue(keywords, locations, currentSite(), cfg.targets.emailHint, await DB.get("doneSearch", []), engine.coverage);
  if (!queue.length) return log("No searches left in this selection. All are done.");
  searchItem = queue[0];
  try {
    await navigate(L.buildSearchUrl(searchItem.query));
    await countUse("search");
    if (await googleSignedIn(engine.tab)) return halt("signedin");
    $("current").textContent = `Open: ${searchItem.query} (${queue.length} left)`;
  } catch (e) { log(e.message, true); }
}

async function targetTab() {
  const tabs = await chrome.tabs.query({ active: true });
  const web = (t) => t && /^https?:/.test(t.url || "");
  const [focused] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return web(focused) ? focused : tabs.find(web);
}

async function collectSearch() {
  const tabId = engine.tab !== null ? engine.tab : ((await targetTab()) || {}).id;
  if (tabId === undefined) return log("Open a Google search first.", true);
  try {
    await QuarryRules.load();
    const page = await call(tabId, ["pages/search.js"], (r, b) => globalThis.__quarrySearch(r, b), [QuarryRules.get("search"), QuarryRules.get("google")["re:blocked"]]);
    if (HALT[page.status]) return halt(page.status);
    if (page.status === "notsearch") return log("That tab is not a Google search page.", true);
    await beginRun(0);
    engine.run.found = page.results.length;
    for (const r of page.results) {
      const id = L.cleanWebsite(r.url);
      if (!id || engine.known.has(id)) continue;
      const social = L.socialFromUrl(r.url);
      const lead = L.newLead("search", { id, name: r.title.split(/\s[|•·-]\s/)[0].trim(), description: r.text.slice(0, 500), location: (searchItem || {}).location || "", keyword: (searchItem || {}).keyword || "",
        website: social ? "" : id, url: r.url, phone: L.findPhones(r.text)[0] || "", socials: social ? { [social.key]: social.url } : {}, emails: L.findEmails(r.text) });
      const reason = L.preFilter(lead, cfg.refine);
      if (reason) reject(reason); else await finishLead(lead);
    }
    await flush();
    if (searchItem) await record(searchItem, "done", { found: page.results.length, saved: engine.run.saved });
    log(`Collected ${page.results.length} results, ${engine.run.saved} saved.`);
    status(`${engine.run.saved} leads saved from this page.`);
    endRun();
  } catch (e) { log(e.message, true); }
}

// ---- any page
const anyFiles = ["core/lib.js", "pages/any.js"];
const anyCall = (tabId, method, args) => call(tabId, anyFiles, (m, a) => globalThis.__quarryAny[m](...a), [method, args || []]);

function renderLists() {
  const box = $("lists");
  box.replaceChildren();
  const add = (index, title, line) => box.append(UI.el("button", { class: `listopt${pageChoice === index ? " on" : ""}`, onclick: () => choose(index) }, UI.el("b", { text: title }), line ? UI.el("span", { text: line }) : null));
  pageLists.forEach((l) => add(l.index, `List of ${l.count} items`, l.sample.join(" / ")));
  if (pageLists.length || engine.scanned) add(-1, "Whole page", "Emails, phones and socials on this page");
}

async function choose(index) {
  pageChoice = index;
  renderLists();
  const tab = await targetTab();
  if (tab) anyCall(tab.id, "highlight", [index]).catch(() => {});
}

async function scanPage() {
  const tab = await targetTab();
  if (!tab) return log("Open a web page first.", true);
  try {
    const res = await anyCall(tab.id, "scan");
    if (HALT[res.status]) return halt(res.status);
    engine.scanned = true;
    pageLists = res.lists;
    pageChoice = pageLists.length ? 0 : -1;
    renderLists();
    if (pageLists.length) anyCall(tab.id, "highlight", [0]).catch(() => {});
    status(pageLists.length ? `${pageLists.length} list${pageLists.length === 1 ? "" : "s"} found on this page.` : "No repeating lists. Whole page is available.");
  } catch (e) { log(`This page can't be read: ${e.message}`, true); }
}

async function collectPage() {
  const tab = await targetTab();
  if (!tab) return log("Open a web page first.", true);
  if (!engine.scanned) return log("Scan the page first.", true);
  await beginRun(1 + Number(cfg.page.nextPages));
  engine.tab = tab.id;
  let sig = pageChoice >= 0 && pageLists[pageChoice] ? pageLists[pageChoice].sig : "";
  try {
    for (let n = 0; n <= Number(cfg.page.nextPages); n++) {
      await gate();
      if (engine.stop) break;
      const over = await limitReached();
      if (over) { log(over); break; }
      const res = await anyCall(tab.id, "collect", [pageChoice, { scrolls: Number(cfg.page.scrolls), sig }]);
      sig = res.sig || sig;
      engine.run.found += res.rows.length;
      const fresh = [];
      for (const r of res.rows) {
        const id = r.emails[0] || r.website || r.url + "#" + r.name;
        if (engine.known.has(id)) continue;
        engine.known.add(id);
        const lead = L.newLead("page", { id, name: r.name, description: r.text, url: r.url, website: r.website, phone: r.phones[0] || "", socials: r.socials, emails: r.emails });
        const reason = L.preFilter(lead, cfg.refine);
        if (reason) reject(reason); else if (!(await sameBusiness(lead))) fresh.push(lead);
      }
      renderDials();
      await pool(fresh, Number(cfg.limits.siteWorkers), async (lead) => { if (cfg.page.visitSites) await enrich(lead); await finishLead(lead); });
      engine.run.step = n + 1;
      renderDials();
      log(`Page ${n + 1}: ${res.rows.length} items, ${fresh.length} new`);
      if (n === Number(cfg.page.nextPages) || pageChoice < 0) break;
      const moved = await anyCall(tab.id, "next");
      if (!moved) { log("No next page found."); break; }
      const ms = nextWait();
      status(`Next page in ${Math.round(ms / 1000)}s`);
      await wait(ms);
    }
    status(`Done. ${engine.run.saved} leads saved.`);
  } catch (e) { log(e.message, true); }
  engine.tab = null;
  endRun();
}

// ---- OpenStreetMap: official Overpass API, no Google
// The server's rules ask every app to name itself honestly (not as a browser or another app), so Kestrel sets its own
// User-Agent for requests to that server only. It stops at once if the server refuses or does not answer.
async function identifyToOsm(server, all) {
  // Best effort: some browsers (Brave in some setups) don't allow this. Then the request still goes out honestly with
  // the browser's own name and the extension's address (Origin), and the run stops at once if the server refuses.
  try {
    if (!(chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateSessionRules)) return false;
    const hosts = (all || [server]).map((u) => new URL(u).hostname), ua = `Kestrel/${chrome.runtime.getManifest().version} (lead-finder browser extension)`;
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [7001], addRules: [{ id: 7001, priority: 1,
      action: { type: "modifyHeaders", requestHeaders: [{ header: "user-agent", operation: "set", value: ua }] },
      condition: { requestDomains: hosts, resourceTypes: ["xmlhttprequest", "other"] } }] });
    return true;
  } catch (_) { return false; }
}

async function runOsm() {
  const O = QuarryOSM;
  const { keywords, locations } = engine.autopilot && engine.autopilot.mode === "osm" ? { keywords: engine.autopilot.keywords, locations: engine.autopilot.places } : pickers.osm.selection();
  if (!keywords.length || !locations.length) return log("Pick at least one keyword and one place.", true);
  const own = String((cfg.osm && cfg.osm.server) || "").trim();
  const server = O.safeServer(own);
  if (!server) return log("The OpenStreetMap server address must start with https://", true);
  // Your own server only, or the public servers in turn when one is full.
  const servers = own ? [server] : O.PUBLIC_SERVERS;
  const queue = O.queue(keywords, locations, engine.coverage);
  if (!queue.length) return log("All these OpenStreetMap searches are already done.");
  if (await safetyStop("osm")) return;
  await identifyToOsm(servers[0], servers);
  const lim = cfg.limits;
  await beginRun(Math.min(queue.length, Number(lim.maxSearches)));
  log(`OpenStreetMap run started: ${engine.run.total} searches. Map data © OpenStreetMap contributors.`);
  for (const item of queue.slice(0, Number(lim.maxSearches))) {
    await gate();
    if (engine.stop) break;
    const over = await limitReached();
    if (over) { log(over); status(over); break; }
    if (await safetyStop("osm")) { engine.run.safety = true; break; }
    status(`${item.query}: waiting for the map server (up to a minute)`);
    const savedBefore = engine.run.saved;
    let elements, base = "";
    try {
      await countUse("osm");
      const query = O.buildQuery(item.keyword, item.location, Math.max(50, Number(lim.maxPerSearch) * 3));
      for (let i = 0; ; i++) {
        try { ({ elements, base } = await O.search(servers[i], query, stopSignal(150000))); break; }
        catch (error) {
          const busy = error instanceof O.Busy || error.name === "TimeoutError";
          if (!busy || /406|429|too many/i.test(error.message) || i + 1 >= servers.length || engine.stop) throw error;
          log(`${new URL(servers[i]).hostname} is full or slow. Asking ${new URL(servers[i + 1]).hostname}.`);
          await wait(5000);
        }
      }
      if (base && !engine.run.osmBase) { engine.run.osmBase = base; log(`OpenStreetMap data is current to ${new Date(base).toLocaleString()}.`); }
    } catch (error) {
      if (engine.stop) { await record(item, "partial", { found: 0, saved: 0 }); break; } // you clicked Stop
      // Polite by design: a refusal, overload or timeout ends the run. No fast retries against a shared public server.
      const busy = error instanceof O.Busy || error.name === "TimeoutError";
      const text = /406/.test(error.message) ? "The OpenStreetMap server refused Kestrel (406). Stopped. Try again tomorrow or set another server you are allowed to use." : busy ? `${error.message || "The OpenStreetMap server did not answer in time."} Stopped; try again later.` : `${item.query}: ${error.message}`;
      log(text, true); status(text);
      engine.run.safety = true; // keep this message in the status line
      await record(item, "partial", { found: 0, saved: 0 });
      break;
    }
    const fresh = [];
    for (const e of elements) {
      const lead = O.toLead(e, item);
      if (!lead || engine.known.has(lead.id)) continue;
      engine.known.add(lead.id);
      const reason = L.preFilter(lead, cfg.refine);
      if (reason) reject(reason); else if (!(await sameBusiness(lead))) fresh.push(lead);
    }
    engine.run.found += elements.length;
    renderDials();
    status(`${item.query}: reading ${fresh.length} websites`);
    await pool(fresh, Number(lim.siteWorkers), async (lead) => { await enrich(lead); await finishLead(lead); });
    await flush();
    if (engine.stop) { await record(item, "partial", { found: elements.length, saved: engine.run.saved - savedBefore }); break; }
    await record(item, "done", { found: elements.length, fresh: fresh.length, saved: engine.run.saved - savedBefore });
    engine.run.step += 1;
    engine.run.searches += 1;
    renderDials();
    const stale = fresh.filter((l) => l.osm && l.osm.stale).length;
    log(`OpenStreetMap ${item.query}: ${elements.length} found, ${fresh.length} new${stale ? `, ${stale} not edited for 3+ years (check them)` : ""}`);
    if (engine.run.step < engine.run.total && !engine.stop) {
      const ms = Math.max(15000, nextWait());
      status(`Next OpenStreetMap search in ${Math.round(ms / 1000)}s`);
      await wait(ms);
    }
  }
  if (!engine.run.safety && engine.state !== "halted") status(engine.stop ? "Stopped." : `Done. ${engine.run.saved} leads saved.`);
  endRun();
}

// ---- official sources: job boards, Companies House, Listen Notes (and Hunter for emails)
const S = QuarrySources;
const apiKey = async (name) => ((await DB.get("apiKeys", {})) || {})[name] || "";
const pause = (ms) => new Promise((r) => setTimeout(r, ms));
// GET JSON. Returns { status, data }. 404 means "not there" (data null), never an error.
async function getJson(url, headers) {
  let res;
  try { res = await fetch(url, { headers: headers || {}, credentials: "omit", signal: stopSignal(20000) }); }
  catch (_) { return { status: 0, data: null }; } // stopped, timed out or offline
  if (res.status === 404) return { status: 404, data: null };
  let data = null;
  try { data = await res.json(); } catch (_) { /* not JSON */ }
  return { status: res.status, data };
}

// Hiring signals: which companies are hiring video people right now.
// Job boards linked from the lead's website, plus video jobs listed on its own careers page.
async function findBoards(lead) {
  const none = { boards: [], pageJobs: [], careers: "" };
  const home = await fetchPage(lead.website).catch(() => null);
  if (!home) return { ...none, unreachable: true };
  let boards = S.detectBoards(home.html);
  if (boards.length) return { ...none, boards };
  // Not on the home page: try one careers page on the same website.
  const host = L.hostOf(home.url);
  const link = [...home.html.matchAll(/href=["']([^"'#]+)["']/gi)].map((m) => { try { return new URL(m[1], home.url).href; } catch (_) { return ""; } })
    .find((u) => u && L.hostOf(u) === host && /career|jobs?\b|join|work-with-us|vacanc|hiring/i.test(u));
  if (!link) return none;
  const page = await fetchPage(link).catch(() => null);
  if (!page) return { ...none, careers: link };
  boards = S.detectBoards(page.html);
  return { boards, pageJobs: boards.length ? [] : S.careersJobs(page.html, page.url || link, cfg.jobs.words), careers: link };
}
async function jobsFor(board) {
  if (await safetyStop("jobs")) { engine.stop = true; return []; }
  await countUse("jobs");
  const { status, data } = await getJson(S.boardUrl(board));
  if (status === 429) { log("A job board asked Kestrel to slow down. Stopped.", true); engine.stop = true; return []; }
  return status === 200 ? S.matchingJobs(S.parseJobs(board.ats, data), cfg.jobs.words) : [];
}
async function runJobs() {
  const j = cfg.jobs;
  if (j.from === "boards") return runJobBoards();
  const scope = { good: (l) => l.ai && l.ai.verdict === "good", goodmaybe: (l) => l.ai && ["good", "maybe"].includes(l.ai.verdict), all: () => true }[j.scope] || (() => true);
  const week = Date.now() - 7 * 86400000;
  const todo = (await DB.all()).filter((l) => l.website && l.status !== "removed" && scope(l) && !(l.hiring && l.hiring.checkedAt > week)).slice(0, Math.max(1, Number(j.max) || 100));
  if (!todo.length) return log("No leads to check. Every matching lead was checked in the last 7 days, or none has a website.");
  await beginRun(todo.length);
  log(`Checking ${todo.length} leads for open video jobs.`);
  let hits = 0;
  const seen = { board: 0, careers: 0, nothing: 0, down: 0 };
  await pool(todo, 3, async (lead) => {
    if (engine.stop) return;
    await gate();
    const found = await findBoards(lead), boards = found.boards, jobs = [...found.pageJobs];
    for (const b of boards) { if (engine.stop) break; jobs.push(...(await jobsFor(b))); await pause(1000); }
    if (found.unreachable) seen.down += 1; else if (boards.length) seen.board += 1; else if (found.careers) seen.careers += 1; else seen.nothing += 1;
    lead.hiring = { checkedAt: Date.now(), boards: boards.map((b) => `${b.ats}:${b.token}`), careers: found.careers || "", jobs: jobs.slice(0, 20) };
    if (jobs.length) { hits += 1; lead.lists = [...new Set([...(lead.lists || []), "Hiring video"])]; log(`${lead.name}: hiring ${jobs.slice(0, 3).map((x) => x.title).join(", ")}`); }
    await DB.putMany([lead]);
    engine.run.found += 1; engine.run.step += 1;
    if (jobs.length) engine.run.saved += 1;
    renderDials();
  });
  if (hits) DB.log("jobs", `${hits} of ${todo.length} leads are hiring video people`);
  log(`Checked ${todo.length}: ${seen.board} job boards, ${seen.careers} careers pages, ${seen.nothing} no jobs page, ${seen.down} offline.`);
  log(hits ? `${hits} are hiring video people. See them in the Kestrel App.` : "No one is hiring video people right now. Kestrel checks again in 7 days.");
  status(engine.stop ? "Stopped." : `Done. ${hits} of ${todo.length} leads are hiring video people.`);
  engine.run.safety = true;
  endRun();
}
async function runJobBoards() {
  const boards = L.parseLines(cfg.jobs.boards).map(S.parseBoardLine).filter(Boolean);
  if (!boards.length) return log("Add job boards, one per line (for example greenhouse:acme).", true);
  await beginRun(boards.length);
  for (const b of boards) {
    await gate();
    if (engine.stop) break;
    const jobs = await jobsFor(b);
    engine.run.found += 1; engine.run.step += 1;
    if (!jobs.length) { reject("no matching jobs"); renderDials(); continue; }
    let name = S.titleCase(b.token);
    if (b.ats === "greenhouse") { const meta = await getJson(`https://boards-api.greenhouse.io/v1/boards/${encodeURIComponent(b.token)}`); if (meta.data && meta.data.name) name = meta.data.name; }
    const lead = L.newLead("jobs", { id: `jobs:${b.ats}:${b.token}`, name, category: "Hiring video people", keyword: cfg.jobs.words || "video jobs", url: jobs[0].url,
      description: `Hiring: ${jobs.map((x) => x.title).join("; ")}`, hiring: { checkedAt: Date.now(), boards: [`${b.ats}:${b.token}`], jobs }, lists: ["Hiring video"] });
    if (engine.known.has(lead.id) || await sameBusiness(lead)) { renderDials(); continue; }
    engine.known.add(lead.id);
    await finishLead(lead);
    log(`${name}: hiring ${jobs.slice(0, 3).map((x) => x.title).join(", ")}`);
    await pause(1000);
  }
  await flush();
  status(engine.stop ? "Stopped." : `Done. ${engine.run.saved} companies hiring video people.`);
  engine.run.safety = true;
  endRun();
}

// Would the Refine filters drop a company that has no website, email or phone (as the register gives them)?
function companiesFilterWarning() {
  if ((cfg.companies || {}).hunter) return "";
  const sample = QuarrySources.chToLead({ company_number: "00000000", company_name: "Sample Agency Ltd", registered_office_address: { locality: "Leeds" }, sic_codes: ["73110"] }, { category: "Sample", location: "Leeds" });
  L.setEmails(sample, []);
  L.applyScore(sample, cfg);
  const why = L.preFilter(sample, cfg.refine) || L.postFilter(sample, cfg.refine);
  return why ? `Refine would drop every company (${why}). Turn on Hunter below, or loosen Refine.` : "";
}

// UK Companies House: official register, by business type (SIC) and town.
async function runCompanies() {
  const key = await apiKey("companiesHouse");
  if (!key) return log("Add your free Companies House key: click Connect above.", true);
  const c = cfg.companies, { types, towns } = pickers.companies.selection();
  if (!types.length) return log("Tick at least one business type.", true);
  if (!towns.length) return log("Tick or add at least one town.", true);
  const warn = companiesFilterWarning();
  if (warn) return log(warn, true);
  const queue = [];
  for (const p of towns) for (const t of types) queue.push({ query: `${t.label} in ${p}`, keyword: t.label, sic: t.sic, location: p, key: L.coverKey("companies", t.label, p) });
  const todo = queue.filter((i) => !L.isDone(engine.coverage, i.key));
  if (!todo.length) return log("All these Companies House searches are already done.");
  const hunterKey = c.hunter ? await apiKey("hunter") : "";
  if (c.hunter && !hunterKey) log("Hunter is on but has no key, so websites and emails will not be looked up.", true);
  const auth = { authorization: S.chAuth(key) };
  let hunterOn = !!hunterKey;
  await beginRun(todo.length);
  for (const item of todo) {
    await gate();
    if (engine.stop) break;
    const sic = item.sic, label = item.keyword;
    const savedBefore = engine.run.saved, max = Math.max(10, Number(c.max) || 100);
    let start = 0, found = 0;
    while (found < max && !engine.stop) {
      if (await safetyStop("companies")) { engine.stop = true; break; }
      const over = await limitReached();
      if (over) { log(over); engine.stop = true; break; }
      await countUse("companies");
      const { status: st, data } = await getJson(S.chSearchUrl({ sic, location: item.location, start, size: Math.min(100, max - found) }), auth);
      if (st === 401) { log("Companies House did not accept the key. Check it in Connections.", true); engine.stop = true; break; }
      if (st === 429) { log("Companies House limit reached (600 requests per 5 minutes). Stopped; try again in 5 minutes.", true); engine.stop = true; break; }
      const items = (data && data.items) || [];
      if (!items.length) break;
      found += items.length; start += items.length;
      engine.run.found += items.length;
      for (const it of items) {
        if (engine.stop) break;
        const lead = S.chToLead(it, { category: label, location: item.location });
        if (engine.known.has(lead.id) || await sameBusiness(lead)) continue;
        engine.known.add(lead.id);
        if (c.officers) {
          await countUse("companies");
          const off = await getJson(S.chOfficersUrl(it.company_number), auth);
          if (off.status === 429) { log("Companies House limit reached. Stopped; try again in 5 minutes.", true); engine.stop = true; }
          const people = S.chOfficers(off.data);
          if (people.length) lead.contacts = people;
          await pause(600);
        }
        if (hunterOn) hunterOn = await hunterLookup(lead, hunterKey);
        if (lead.website) await enrich(lead);
        await finishLead(lead);
        renderDials();
      }
      await flush();
      if (items.length < 100) break;
      await pause(600);
    }
    await record(item, engine.stop ? "partial" : "done", { found, saved: engine.run.saved - savedBefore });
    engine.run.step += 1;
    log(`Companies House ${item.query}: ${found} found, ${engine.run.saved - savedBefore} saved`);
  }
  if (engine.state !== "halted") status(engine.stop ? "Stopped." : `Done. ${engine.run.saved} companies saved.`);
  engine.run.safety = true;
  endRun();
}

// Hunter.io: emails (and the website) for one lead. Returns false when Hunter says stop.
async function hunterLookup(lead, key) {
  const url = S.hunterUrl(lead, key);
  if (!url) return true;
  const { status: st, data } = await getJson(url);
  if (st === 401) { log("Hunter did not accept the key. Check it in Connections.", true); engine.stop = true; return false; }
  if (st === 429) { log("Hunter: no credits left or too fast. Hunter lookups stopped.", true); return false; }
  if (st !== 200) return true;
  const pick = S.hunterPick(data);
  if (!lead.website && pick.domain) lead.website = L.cleanWebsite(`https://${pick.domain}`);
  if (pick.emails.length) lead.emails = [...new Set([...(lead.emails || []), ...pick.emails])];
  if (pick.contacts.length) lead.contacts = L.mergeContacts(pick.contacts, lead.contacts || []);
  lead.hunterAt = Date.now();
  return true;
}

// Listen Notes: podcasts and the companies behind them.
async function runPodcasts() {
  const key = await apiKey("listenNotes");
  if (!key) return log("Add your Listen Notes key: click Connect above.", true);
  const p = cfg.podcasts, pages = Math.max(1, Math.min(10, Number(p.pages) || 1));
  const genre = S.LN_GENRES.find((g) => String(g[0]) === String(p.genre)) || S.LN_GENRES[0];
  const label = p.method === "search" ? `Podcasts: ${p.q}` : `Top ${genre[1]} podcasts`;
  if (p.method === "search" && !String(p.q || "").trim()) return log("Add keywords for the search.", true);
  await beginRun(pages);
  for (let i = 0; i < pages && !engine.stop; i++) {
    await gate();
    if (await safetyStop("podcasts")) break;
    const over = await limitReached();
    if (over) { log(over); break; }
    await countUse("podcasts");
    const url = p.method === "search" ? S.lnSearchUrl({ q: p.q, region: p.region, offset: i * 10 }) : S.lnBestUrl({ genre: genre[0], region: p.region, page: i + 1 });
    const { status: st, data } = await getJson(url, { "X-ListenAPI-Key": key });
    if (st === 401) { log("Listen Notes did not accept the key. Check it in Connections.", true); break; }
    if (st === 429) { log("Listen Notes: monthly quota or speed limit reached. Stopped.", true); break; }
    if (st === 400 && p.method === "search") { log("Keyword search for podcasts needs Listen Notes PRO. Use Top podcasts by genre instead.", true); break; }
    const list = (data && (data.podcasts || data.results)) || [];
    if (!list.length) break;
    engine.run.found += list.length;
    const fresh = [];
    for (const pod of list) {
      const lead = S.lnToLead(pod, { label, region: p.region });
      if (!lead || engine.known.has(lead.id)) continue;
      engine.known.add(lead.id);
      const reason = L.preFilter(lead, cfg.refine);
      if (reason) reject(reason); else if (!(await sameBusiness(lead))) fresh.push(lead);
    }
    await pool(fresh, Number(cfg.limits.siteWorkers), async (lead) => { if (lead.website) await enrich(lead); await finishLead(lead); });
    await flush();
    engine.run.step += 1;
    renderDials();
    log(`${label}, page ${i + 1}: ${list.length} found, ${fresh.length} new`);
    if (data && data.has_next === false) break;
    await pause(1500);
  }
  if (engine.state !== "halted") status(engine.stop ? "Stopped." : `Done. ${engine.run.saved} podcast leads saved. Data from Listen Notes.`);
  engine.run.safety = true;
  endRun();
}

// ---- site list
async function runSites() {
  let urls = [...new Set(L.parseLines(cfg.targets.sites).map(L.normalizeSiteInput).filter(Boolean))];
  if (!urls.length) return log("Add at least one website.", true);
  if (plan().sitesPerRun && urls.length > plan().sitesPerRun) { log(`Your ${plan().name} plan reads ${plan().sitesPerRun} websites per run. Reading the first ${plan().sitesPerRun}.`); urls = urls.slice(0, plan().sitesPerRun); }
  await beginRun(urls.length);
  log(`Reading ${urls.length} websites.`);
  await pool(urls, Number(cfg.limits.siteWorkers), async (website) => {
    const over = await limitReached();
    if (over) { if (!engine.stop) log(over); engine.stop = true; return; }
    const id = L.hostOf(website);
    engine.run.step += 1;
    engine.run.found += 1;
    if (engine.known.has(id)) { reject("already collected"); renderDials(); return; }
    engine.known.add(id);
    status(id);
    const lead = L.newLead("site", { id, website, url: website });
    await enrich(lead);
    lead.name = lead.name || id;
    const reason = L.preFilter(lead, cfg.refine);
    if (reason) reject(reason); else await finishLead(lead);
    renderDials();
  });
  status(`Done. ${engine.run.saved} leads saved.`);
  endRun();
}

// ---- playbooks
async function renderPlaybooks(selected) {
  const books = await DB.get("playbooks", {});
  const box = $("playbook");
  box.replaceChildren(UI.el("option", { value: "", text: "Playbook" }), ...Object.keys(books).sort().map((n) => UI.el("option", { value: n, text: n })));
  box.value = selected || "";
  $("pbDel").disabled = !box.value;
}

async function savePlaybook() {
  const name = $("pbName").value.trim();
  if (!name) return log("Name the playbook first.", true);
  const books = await DB.get("playbooks", {});
  if (!books[name] && QuarryPlans.full(plan(), "playbooks", Object.keys(books).length)) return QuarryGate.upgrade(`Your ${plan().name} plan keeps ${plan().playbooks} ${plan().playbooks === 1 ? "playbook" : "playbooks"}.`, QuarryPlans.cheapestWith((p) => !p.playbooks || p.playbooks > Object.keys(books).length).id);
  books[name] = JSON.parse(JSON.stringify(cfg));
  await DB.set("playbooks", books);
  $("pbName").value = "";
  await renderPlaybooks(name);
  log(`Playbook saved: ${name}`);
}

async function loadPlaybook() {
  $("pbDel").disabled = !$("playbook").value;
  if (!$("playbook").value) return;
  const books = await DB.get("playbooks", {});
  cfg = L.mergeDefaults(books[$("playbook").value]);
  pushFields();
  saveCfg();
}

async function deletePlaybook() {
  const books = await DB.get("playbooks", {});
  delete books[$("playbook").value];
  await DB.set("playbooks", books);
  renderPlaybooks();
}

// ---- wiring
async function onStart() {
  if (!QuarryGate.allowed()) { status("Activate Kestrel first."); QuarryGate.start(); return; }
  if (!L.featureOn(globalThis.QuarryLicenseConfig, cfg.mode)) { status("This mode is not part of your edition."); return; }
  if (!QuarryPlans.allows(plan(), "modes", cfg.mode)) { QuarryGate.upgrade("This mode is not in your plan.", QuarryPlans.cheapestWith((p) => p.modes.includes(cfg.mode)).id); return; }
  status("Starting");
  // Team progress first (Kestrel App), so searches a teammate finished are skipped.
  if (globalThis.QuarryCloud && ["maps", "search", "osm", "companies"].includes(cfg.mode)) {
    const team = await QuarryCloud.pullProgress();
    if (team && Object.keys(team).length) { engine.coverage = L.mergeCoverage(engine.coverage, team); await DB.set("coverage", engine.coverage); renderPickers(); }
  }
  await ({ maps: runMaps, search: openNextSearch, youtube: runYouTube, osm: runOsm, jobs: runJobs, companies: runCompanies, podcasts: runPodcasts, page: collectPage, sites: runSites })[cfg.mode]();
  // A run that stops before it starts (nothing left, nothing picked) explains why in the status line.
  const first = $("log").firstElementChild;
  if ($("status").textContent === "Starting" && first) status(first.lastElementChild.textContent);
}

async function init() {
  QuarryRules.load().catch(() => {});   // live page rules from kestrelleads.com (never blocks start-up)
  UI.mountTips();
  if (globalThis.QuarryCloud) { QuarryCloud.pullKeys().catch(() => {}); QuarryCloud.syncDnc().catch(() => {}); QuarryCloud.pullRules().then(async (n) => { if (n) cfg = await UI.loadSettings(); }).catch(() => {}); } // team keys and Do-not-contact from the Kestrel App, when connected
  const stored = await DB.get("settings", null);
  cfg = await UI.loadSettings();
  if (stored && !stored.version) {
    cfg.limits.siteWorkers = Math.max(cfg.limits.siteWorkers, 6);
    cfg.limits.siteTimeout = Math.min(cfg.limits.siteTimeout, 8);
    saveCfg();
  }
  UI.fillMark($("brand"));
  $("brand").append(UI.el("button", { class: "ver", title: "What's New", text: QuarryGate.version(), onclick: () => QuarryGate.whatsNew() }));
  QuarryGate.start();
  await QuarryGate.ready;
  await QuarryMigrate.run();
  globalThis.QuarryOnPlan = () => location.reload();
  // Kestrel collects here and keeps everything in the App: send what is still waiting, and once, everything from before.
  if (globalThis.QuarryCloud && await QuarryCloud.connected()) {
    const once = (await chrome.storage.local.get("cloudSentAll")).cloudSentAll;
    const send = once ? QuarryCloud.flush() : QuarryCloud.sendAll().then(() => chrome.storage.local.set({ cloudSentAll: Date.now() }));
    send.catch(() => {}).finally(renderSync);
  }
  renderSync();
  chrome.storage.onChanged.addListener((ch) => { if (ch.cloud || ch.cloudPending) renderSync(); });
  // Autopilot: read the team's goal now and every 10 minutes (it may start by itself; see refreshAutopilot).
  setTimeout(() => { refreshAutopilot().catch(() => {}); }, 3000);
  setInterval(() => { refreshAutopilot().catch(() => {}); }, 10 * 60000);
  // Leads that could not be sent (offline, App busy) are tried again every 5 minutes while the panel is open.
  setInterval(() => { if (globalThis.QuarryCloud) QuarryCloud.flush().catch(() => {}); }, 5 * 60000);
  globalThis.quarryMeter = QuarryMeter.mount($("meterSlot"));
  document.querySelectorAll("[data-g]").forEach((n) => n.append(UI.icon(n.dataset.g)));
  const modes = enabledModes(), mine = modes.filter((m) => QuarryPlans.allows(plan(), "modes", m));
  if (!mine.includes(cfg.mode)) cfg.mode = mine[0] || modes[0];
  document.querySelectorAll("#modes button").forEach((b) => { if (!modes.includes(b.dataset.mode)) b.remove(); else if (!mine.includes(b.dataset.mode)) { b.classList.add("locked"); b.title = `Needs ${QuarryPlans.cheapestWith((p) => p.modes.includes(b.dataset.mode)).name}`; } });
  document.querySelectorAll("#modes button").forEach((b) => {
    b.prepend(UI.icon(b.dataset.ico));
    b.addEventListener("click", () => {
      if (b.classList.contains("locked")) return QuarryGate.upgrade(`${b.textContent.trim()} mode is not in your plan.`, QuarryPlans.cheapestWith((p) => p.modes.includes(b.dataset.mode)).id);
      cfg.mode = b.dataset.mode; if (engine.state === "idle") status("Ready"); renderMeta(); saveCfg();
    });
  });
  const chips = $("siteChips");
  SITES.forEach(([key, site]) => chips.append(UI.el("button", { class: "chip", "data-site": site, style: `--bc:${L.SOCIALS[key].color}`, onclick: () => { cfg.targets.site = site; renderMeta(); saveCfg(); } }, UI.icon(key), L.SOCIALS[key].label)));
  chips.append(UI.el("button", { class: "chip", "data-site": "", text: "Custom", onclick: () => { cfg.targets.site = "custom"; renderMeta(); saveCfg(); } }));
  document.querySelectorAll("[data-set]").forEach((f) => {
    const sync = () => {
      write(f.dataset.set, f.type === "checkbox" ? f.checked : f.type === "number" ? Number(f.value) : f.value);
      // Changing a limit by hand means the settings are no longer a preset.
      if (/^(limits\.|safety\.daily|safety\.cooldown)/.test(f.dataset.set) && cfg.safety.level !== "custom") { cfg.safety.level = "custom"; renderSafety(); }
      clearTimeout(f.syncTimer);
      f.syncTimer = setTimeout(() => { renderMeta(); saveCfg(); }, f.type === "checkbox" ? 0 : 140);
    };
    f.addEventListener(f.type === "checkbox" ? "change" : "input", sync);
  });
  $("locFile").addEventListener("change", async (e) => {
    if (!e.target.files[0]) return;
    cfg.targets.locations = await e.target.files[0].text();
    pushFields();
    saveCfg();
    e.target.value = "";
  });
  $("start").addEventListener("click", onStart);
  document.querySelectorAll("#safeSeg button").forEach((b) => b.addEventListener("click", () => { L.applySafety(cfg, b.dataset.v); pushFields(); saveCfg(); renderSafety(); log(`Safety set to ${b.textContent}.`); }));
  $("pause").addEventListener("click", () => {
    engine.pause = !engine.pause;
    setState(engine.pause ? "paused" : "running");
  });
  $("stop").addEventListener("click", () => { engine.stop = true; engine.pause = false; if (engine.abort) engine.abort.abort(); status("Stopping"); });
  $("scan").addEventListener("click", async () => {
    $("scan").disabled = true;
    $("scan").textContent = "Scanning";
    await scanPage();
    $("scan").disabled = false;
    $("scan").textContent = "Scan Open Page";
  });
  // Everything you collect lives in the Kestrel App (leads, lists, AI, emails, export). This button opens it;
  // an App tab that is already open is brought to the front.
  $("openApp").replaceChildren(UI.icon("sheet"), "Open Kestrel App");
  $("openApp").addEventListener("click", () => openApp(""));
  document.querySelectorAll("[data-conn]").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); openApp("connections"); }));
  $("pbSave").addEventListener("click", savePlaybook);
  $("pbDel").addEventListener("click", deletePlaybook);
  $("playbook").addEventListener("change", loadPlaybook);
  await loadCoverage();
  await loadSafety();
  renderSafety();
  // Time limits roll forward by themselves: refresh the counts every minute.
  setInterval(() => { engine.searchLog = L.pruneSearchLog(engine.searchLog); renderSafety(); }, 60000);
  // First start with this version: switch older, faster settings to the Safe preset once.
  if (stored && !stored.safety) { L.applySafety(cfg, "safe"); saveCfg(); }
  await UI.loadLibrary();
  const pickerCtx = (mode) => ({ cfg: () => cfg, save: saveCfg, coverage: () => engine.coverage, site: () => (mode === "search" ? currentSite() : ""), onChange: () => {}, log: (t, bad) => { log(t, bad); status(t); } });
  pickers.maps = QuarryPicker($("pickMaps"), "maps", pickerCtx("maps"));
  pickers.search = QuarryPicker($("pickSearch"), "search", pickerCtx("search"));
  pickers.osm = QuarryPicker($("pickOsm"), "osm", pickerCtx("osm"));
  pickers.companies = QuarryCompanyPicker($("pickCompanies"), { cfg: () => cfg, save: () => { saveCfg(); renderMeta(); }, coverage: () => engine.coverage, log: (t, bad) => { log(t, bad); status(t); } });
  pickers.youtube = QuarryYtPicker($("pickYt"), { ...pickerCtx("youtube"), onChange: () => renderMeta() });
  document.querySelectorAll("nav.src[data-src]").forEach((n) => {
    n.style.setProperty("--n", 2);
    n.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => { cfg.targets.source[n.dataset.src] = b.dataset.v; renderMeta(); saveCfg(); }));
  });
  pushFields();
  renderPlaybooks();
  DB.onChange(async (what) => {
    if (what === "coverage") { engine.coverage = await DB.get("coverage", {}); renderPickers(); return; }
    if (what === "customLibrary") { await UI.loadLibrary(); renderPickers(); return; }
    if (what === "usage" || what === "cooldown" || what === "searchLog") { await loadSafety(); renderSafety(); return; }
    // Never swap workspace under a running search: finish or stop the run first.
    if (what === "workspace") { if (engine.state === "idle") location.reload(); else log("Workspace changed. It takes effect when this run ends.", true); return; }
    if (what !== "settings") return;
    const latest = await UI.loadSettings();
    const typing = document.activeElement && document.activeElement.matches("[data-set]");
    if (engine.state === "idle" && !typing) { cfg = latest; pushFields(); return; }
    Object.assign(cfg, { weights: latest.weights, tiers: latest.tiers, ai: latest.ai });
    cfg.refine.rules = latest.refine.rules;
  });
}

// ---- Autopilot: the team's goal in the App says which keywords and places to search. This panel runs the searches that are
// still left (team progress skips done ones), with the same safe limits as a normal run. The App then finds emails, scores
// and writes; nothing is ever sent without the team's OK there.
let apGoal = null;
async function apLeft(goal) {
  if (!goal) return 0;
  return goal.source === "osm" ? QuarryOSM.queue(goal.keywords, goal.places, engine.coverage).length
    : L.mapsQueue(goal.keywords, goal.places, await DB.get("doneMaps", []), engine.coverage).length;
}
async function renderAutopilot() {
  const card = $("apCard");
  if (!apGoal) { card.hidden = true; return; }
  const left = await apLeft(apGoal), auto = Boolean((await chrome.storage.local.get("apAuto")).apAuto);
  const where = apGoal.source === "osm" ? "OpenStreetMap" : "Google Maps";
  const run = UI.el("button", { class: "btn go", id: "apRun", text: left ? "Run Autopilot searches" : "All searches done", onclick: runAutopilot });
  run.disabled = !left || engine.state !== "idle";
  const box = UI.el("input", { type: "checkbox", class: "sw", id: "apAuto" });
  box.checked = auto;
  box.addEventListener("change", () => chrome.storage.local.set({ apAuto: box.checked }));
  card.replaceChildren(
    UI.el("div", { class: "ap-top" }, UI.el("b", { text: "Autopilot" }), UI.tip("Your team's Autopilot in the Kestrel App chose these searches. Kestrel runs them here, slowly and safely, then the App finds emails, scores and writes. Nothing is sent without your OK in the App.")),
    UI.el("p", { class: "ap-line", text: `${where} · ${apGoal.keywords.length} ${apGoal.keywords.length === 1 ? "keyword" : "keywords"} × ${apGoal.places.length} ${apGoal.places.length === 1 ? "place" : "places"} · ${left.toLocaleString()} ${left === 1 ? "search" : "searches"} left` }),
    run,
    UI.el("label", { class: "ap-auto" }, box, UI.el("span", { text: "Start by itself while this panel is open" })));
  UI.mountTips();
}
async function runAutopilot() {
  if (!apGoal || engine.state !== "idle") return;
  const before = cfg.mode;
  engine.autopilot = { mode: apGoal.source, keywords: apGoal.keywords, places: apGoal.places };
  cfg.mode = apGoal.source; renderMeta();
  log("Autopilot searches started.");
  try { await onStart(); } finally {
    engine.autopilot = null;
    if (cfg.mode === apGoal.source) cfg.mode = before;   // a mode picked during the run stays picked
    renderMeta(); renderAutopilot();
  }
}
// "Start by itself" only when a normal run could start now: signed in, idle (not stopped for a check), no safety pause,
// no daily or time-window limit reached, and searches left. Checked quietly: nothing is logged or opened when it waits.
async function apCanAutoStart() {
  if (!apGoal || engine.state !== "idle" || !QuarryGate.allowed()) return false;
  if (!(await chrome.storage.local.get("apAuto")).apAuto || (await apLeft(apGoal)) <= 0) return false;
  if (await dailyLeft() <= 0) return false;
  engine.usage = L.usageToday(engine.usage);
  if (L.safetyBlock(apGoal.source, engine.usage, engine.cooldown, cfg.safety)) return false;
  if (L.WINDOW_SOURCES.includes(apGoal.source) && L.windowBlock(engine.searchLog || [], plan())) return false;
  return true;
}
async function refreshAutopilot() {
  apGoal = globalThis.QuarryCloud ? await QuarryCloud.pullAutopilot() : null;
  await renderAutopilot();
  if (await apCanAutoStart()) runAutopilot();
}

const APP_URL = "https://kestrelleads.com/app";
async function openApp(view) {
  const app = String((await chrome.storage.local.get("appUrl")).appUrl || APP_URL);
  const url = view ? `${app}?view=${view}` : app;
  const origin = new URL(app).origin;
  const open = (await chrome.tabs.query({})).find((t) => t.url && t.url.startsWith(origin));
  if (open && !view) { await chrome.tabs.update(open.id, { active: true }); if (open.windowId !== undefined && chrome.windows) chrome.windows.update(open.windowId, { focused: true }); }
  else chrome.tabs.create({ url });
}

// The team this extension sends to, and whether anything is still waiting to be sent.
async function renderSync() {
  const got = await chrome.storage.local.get(["cloud", "cloudPending"]);
  const c = got.cloud, waiting = (got.cloudPending || []).length;
  const pill = $("teamPill"), line = $("syncLine");
  if (!c || !c.token) { pill.hidden = true; line.textContent = "Not connected to the Kestrel App."; return; }
  pill.hidden = false; pill.textContent = c.team || "Your team"; pill.title = c.email ? `Signed in as ${c.email}` : "";
  const ago = c.lastSent ? Math.round((Date.now() - c.lastSent) / 60000) : null;
  line.textContent = waiting ? `${waiting.toLocaleString()} ${waiting === 1 ? "lead" : "leads"} waiting to send to the App. Kestrel tries again by itself.`
    : ago === null ? "New leads go straight to your Kestrel App." : `All leads are in your Kestrel App. Last sent ${ago < 1 ? "just now" : ago < 60 ? `${ago} min ago` : `${Math.round(ago / 60)} h ago`}.`;
}

init();
