// Keyword and location picker for the side panel, with progress for each search.
// ctx: { cfg(), save(), coverage(), site(), onChange() }
(function (root) {
  const L = root.QuarryLib, UI = root.QuarryUI, { el, icon } = UI;
  const lib = () => UI.activeLibrary();

  function Picker(box, mode, ctx) {
    let kwFilter = "", placeFilter = "";
    const pick = () => ctx.cfg().targets.pick[mode];

    function countryName() {
      const p = pick();
      if (!p.country || !L.libCountry(lib(), p.country)) p.country = lib().countries[0].name;
      return p.country;
    }

    const commit = () => { ctx.save(); render(); ctx.onChange(); };

    function toggleMany(list, items, on) {
      const set = new Set(list);
      items.forEach((i) => (on ? set.add(i) : set.delete(i)));
      return [...set];
    }

    function stats() {
      const p = pick();
      return L.coverageStats(mode, p.keywords, p.places, ctx.coverage(), ctx.site());
    }

    function check(on, part) { return el("i", { class: `tick${on ? " on" : part ? " part" : ""}` }); }

    function keywordBlock(s) {
      const p = pick(), chosen = new Set(p.keywords);
      const groups = lib().keywordGroups.map((g) => {
        const n = g.items.filter((k) => chosen.has(k)).length;
        const on = n === g.items.length;
        return el("button", { class: `chip${on ? " on" : n ? " part" : ""}`, title: on ? "Click to clear" : "Click to select all", onclick: () => { p.keywords = toggleMany(p.keywords, g.items, !on); commit(); } },
          `${g.name} `, el("span", { class: "n", text: String(g.items.length) }));
      });
      const q = kwFilter.toLowerCase();
      const all = L.allKeywords(lib()).filter((k) => !q || k.toLowerCase().includes(q));
      const rows = all.map((k) => {
        const on = chosen.has(k), stat = s.perKeyword[k];
        const meta = on && p.places.length ? `${stat.done}/${stat.total}` : "";
        return el("button", { class: "pickrow", onclick: () => { p.keywords = toggleMany(p.keywords, [k], !on); commit(); } },
          check(on), el("span", { class: "nm", text: k }), meta ? el("span", { class: `meta${stat.done === stat.total ? " ok" : ""}`, text: meta }) : null);
      });
      const filter = el("input", { type: "search", placeholder: "Find keyword", value: kwFilter });
      filter.addEventListener("input", () => { kwFilter = filter.value; const at = filter.selectionStart; render(); const f2 = box.querySelector(".kwfind"); f2.focus(); f2.setSelectionRange(at, at); });
      filter.className = "kwfind";
      return [
        el("div", { class: "cap row" }, el("span", { text: "Keywords" }), el("span", { class: "cnt", text: `${p.keywords.length} selected` })),
        el("div", { class: "group" },
          el("div", { class: "cell chips" }, ...groups),
          el("div", { class: "cell" }, icon("search"), filter,
            el("button", { class: "link", text: "All", onclick: () => { p.keywords = toggleMany(p.keywords, all, true); commit(); } }),
            el("button", { class: "link", text: "Clear", onclick: () => { p.keywords = []; commit(); } }),
            el("button", { class: "link", text: "Import", title: "Add keywords from a .txt or .csv file", onclick: () => importFile("keywords") })),
          el("div", { class: "picklist scroll" }, ...rows)),
      ];
    }

    function placeBlock(s) {
      const p = pick(), chosen = new Set(p.places), country = L.libCountry(lib(), countryName());
      const select = el("select", { class: "country" }, ...lib().countries.map((c) => {
        const places = L.allPlaces(c), n = places.filter((x) => chosen.has(x)).length;
        return el("option", { value: c.name, text: `${c.name} (${n ? `${n}/` : ""}${places.length})` });
      }));
      select.value = country.name;
      select.addEventListener("change", () => { p.country = select.value; placeFilter = ""; render(); ctx.save(); });
      const areas = country.areas.map((a) => {
        const n = a.places.filter((x) => chosen.has(x)).length, on = n === a.places.length;
        const done = a.places.filter((x) => s.perPlace[x] && L.placeState(s.perPlace[x]) === "done").length;
        return el("button", { class: `chip${on ? " on" : n ? " part" : ""}`, onclick: () => { p.places = toggleMany(p.places, a.places, !on); commit(); } },
          `${a.name} `, el("span", { class: "n", text: done && n ? `${done}/${a.places.length}` : String(a.places.length) }));
      });
      const q = placeFilter.toLowerCase();
      const list = [];
      for (const a of country.areas) {
        const places = a.places.filter((x) => !q || x.toLowerCase().includes(q));
        if (!places.length) continue;
        list.push(el("div", { class: "areah", text: a.name }));
        for (const x of places) {
          const on = chosen.has(x), st = s.perPlace[x];
          const state = on && st ? L.placeState(st) : "none";
          list.push(el("button", { class: "pickrow", onclick: () => { p.places = toggleMany(p.places, [x], !on); commit(); } },
            check(on), el("span", { class: "nm", text: L.shortPlace(x) === x ? x : x.replace(`, ${country.name}`, "") }),
            on && p.keywords.length ? el("span", { class: `meta${state === "done" ? " ok" : ""}`, text: `${st.done}/${st.total}` }) : null,
            el("i", { class: `dot ${state}`, title: { done: "Finished", partial: "In progress", none: "Not started" }[state] })));
        }
      }
      const filter = el("input", { type: "search", placeholder: "Find place", value: placeFilter, class: "plfind" });
      filter.addEventListener("input", () => { placeFilter = filter.value; const at = filter.selectionStart; render(); const f2 = box.querySelector(".plfind"); f2.focus(); f2.setSelectionRange(at, at); });
      const all = L.allPlaces(country);
      return [
        el("div", { class: "cap row" }, el("span", { text: "Locations" }), el("span", { class: "cnt", text: `${p.places.length} selected` })),
        el("div", { class: "group" },
          el("label", { class: "cell" }, el("span", { text: "Country" }), select),
          el("div", { class: "cell chips" }, ...areas),
          el("div", { class: "cell" }, icon("search"), filter,
            el("button", { class: "link", text: "All", onclick: () => { p.places = toggleMany(p.places, all, true); commit(); } }),
            el("button", { class: "link", text: "Clear", onclick: () => { p.places = toggleMany(p.places, all, false); commit(); } }),
            el("button", { class: "link", text: "Import", title: "Add places from a .txt or .csv file", onclick: () => importFile("locations") })),
          el("div", { class: "picklist tall scroll" }, ...list)),
      ];
    }

    function progressBlock(s) {
      const p = pick();
      const places = Object.values(s.perPlace);
      const finished = places.filter((x) => L.placeState(x) === "done").length;
      const saved = places.reduce((n, x) => n + x.saved, 0);
      const left = s.total - s.done;
      const per = mode === "maps" ? Number(ctx.cfg().limits.delaySec) + 40 : 0;
      return [
        el("div", { class: "cap row" }, el("span", { text: mode === "search" ? `Progress on ${ctx.site()}` : "Progress" })),
        el("div", { class: "group" },
          el("div", { class: "cell prog" }, el("div", { class: "bar" }, el("i", { style: `transform:scaleX(${s.total ? s.done / s.total : 0})` })),
            el("div", { class: "nums" },
              el("div", {}, el("b", { text: String(s.done) }), el("span", { text: `of ${s.total} searches` })),
              el("div", {}, el("b", { text: String(finished) }), el("span", { text: `of ${p.places.length} places done` })),
              el("div", {}, el("b", { text: String(saved) }), el("span", { text: "leads saved" })))),
          el("div", { class: "cell" }, el("span", { class: "muted", text: !s.total ? "Pick keywords and places to start." : left ? `${left} searches left${per ? `, about ${Math.ceil((left * per) / 60)} min` : ""}` : "All searches in this selection are done." }))),
      ];
    }

    function render() {
      const s = stats();
      const scroller = box.closest(".body") || box.parentElement;
      const top = scroller.scrollTop;
      const lists = [...box.querySelectorAll(".picklist")].map((n) => n.scrollTop);
      box.replaceChildren(...keywordBlock(s), ...placeBlock(s), ...progressBlock(s));
      box.querySelectorAll(".picklist").forEach((n, i) => { n.scrollTop = lists[i] || 0; });
      scroller.scrollTop = top;
    }

    // Adds keywords or places from a file, then selects them.
    function importFile(kind) {
      UI.pickText(".txt,.csv,text/plain,text/csv", async (text, name) => {
        const res = await UI.importLibrary(kind, text, name);
        if (!res) return ctx.log(`No ${kind} found in ${name}.`, true);
        const p = pick();
        if (kind === "keywords") {
          const items = res.parsed.keywordGroups.flatMap((g) => g.items);
          p.keywords = toggleMany(p.keywords, items, true);
          ctx.log(`Imported ${items.length} keywords from ${name}.`);
        } else {
          const places = res.parsed.countries.flatMap((c) => L.allPlaces(c));
          p.places = toggleMany(p.places, places, true);
          p.country = res.parsed.countries[0].name;
          ctx.log(`Imported ${places.length} places in ${res.parsed.countries.map((c) => c.name).join(", ")} from ${name}.`);
        }
        commit();
      });
    }

    function selection() {
      const p = pick();
      return { keywords: [...p.keywords], locations: [...p.places] };
    }

    return { render, selection };
  }

  root.QuarryPicker = Picker;
})(globalThis);
