// Shared by the console and the workspace: licence lock, What's New after an update, and "Update ready" notices.
(function (root) {
  const UI = root.QuarryUI, Lic = root.QuarryLicense, Plans = root.QuarryPlans, el = UI.el;
  const CONSENT = 1; // raise this when the terms change, so everyone agrees again
  const version = () => chrome.runtime.getManifest().version;
  const store = { get: async (k) => (await chrome.storage.local.get(k))[k], set: (k, v) => chrome.storage.local.set({ [k]: v }) };
  let unlocked = false;
  let plan = Plans.get("starter");
  let markReady;
  const ready = new Promise((r) => { markReady = r; });
  const selling = () => !!(root.QuarryLicenseConfig || {}).provider;
  const accountMode = () => (root.QuarryLicenseConfig || {}).provider === "kestrel";
  const APP = "https://kestrelleads.com/app";
  async function refreshPlan() {
    const saved = accountMode() && root.QuarryCloud ? await root.QuarryCloud.conn() : await Lic.load();
    plan = Plans.get(Plans.planId(saved, root.QuarryLicenseConfig)); return plan;
  }

  // "2.10.0" is newer than "2.9.1".
  function newer(a, b) {
    const x = String(a || "0").split(".").map(Number), y = String(b || "0").split(".").map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
    return false;
  }

  function sheet(...kids) {
    document.querySelector(".gate")?.remove();
    const box = el("div", { class: "gate" }, el("div", { class: "sheetbox scroll" }, ...kids));
    document.body.append(box);
    return box;
  }
  const close = () => document.querySelector(".gate")?.remove();

  // ---- account lock (account mode): connect to the Kestrel App, or choose a plan there
  let watching = false;
  function accountLock(st) {
    const note = el("p", { class: "gate-note", text: st.text });
    const again = el("button", { class: "btn", text: "Check Again" });
    const check = async () => {
      again.disabled = true; note.textContent = "Checking…";
      const s = await Lic.status();
      again.disabled = false; note.textContent = s.text;
      if (s.ok) { unlocked = true; await refreshPlan(); close(); afterUnlock(); if (root.QuarryOnPlan) root.QuarryOnPlan(plan); }
    };
    again.addEventListener("click", check);
    const ended = st.reason === "plan";
    sheet(el("h2", { text: ended ? "Your Plan Has Ended" : "Sign In to Kestrel" }),
      el("p", { text: ended ? "Kestrel is locked until your team chooses a plan. Everything you collected is safe in the App." : "This extension collects leads for your Kestrel App. It needs a Kestrel account with a free trial or plan." }),
      note,
      el("div", { class: "row-end" }, again, el("a", { class: "btn go", href: ended ? `${APP}?view=plan` : `${APP}?view=get&connect=1`, target: "_blank", rel: "noreferrer", text: ended ? "Choose a Plan" : "Sign In to Kestrel" })),
      ended ? null : codeBox(check));
    // Unlock by itself as soon as the App connects this extension or the plan is paid.
    if (!watching) {
      watching = true;
      chrome.storage.onChanged.addListener((changes) => { if (changes.cloud && !unlocked && document.querySelector(".gate")) check(); });
    }
  }

  // For an App in another browser: App → Settings → Extension → Get a connection code, pasted here.
  function codeBox(check) {
    const box = el("input", { type: "text", class: "wide", placeholder: "kestrel:…", autocomplete: "off", spellcheck: "false", "aria-label": "Connection code" });
    const msg = el("p", { class: "gate-note" });
    const go = el("button", { class: "btn", text: "Connect" });
    go.addEventListener("click", async () => {
      const info = root.QuarryCloud && root.QuarryCloud.parseCode(box.value);
      if (!info) { msg.textContent = "That is not a Kestrel connection code. Copy it again from the App."; return; }
      go.disabled = true; msg.textContent = "Connecting…";
      try { await root.QuarryCloud.connect(info); box.value = ""; msg.textContent = ""; await check(); }
      catch (e) { msg.textContent = e.message || "Could not connect. Try again."; }
      go.disabled = false;
    });
    return el("details", { class: "code-fold" }, el("summary", { text: "Using the App in another browser? Paste a connection code" }),
      el("p", { class: "gate-note", text: "In the App open Settings → Extension → Get a connection code, copy it, and paste it here." }),
      el("div", { class: "row-end" }, box, go), msg);
  }

  // ---- licence lock
  function lockScreen(why) {
    if (accountMode()) return accountLock(typeof why === "object" ? why : { text: why, reason: "connect" });
    const cfg = root.QuarryLicenseConfig || {};
    const input = el("input", { type: "text", class: "wide", placeholder: "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX", autocomplete: "off", spellcheck: "false" });
    const note = el("p", { class: "gate-note", text: why });
    const go = el("button", { class: "btn go", text: "Activate" });
    const run = async () => {
      go.disabled = true; note.textContent = "Checking…";
      const res = await Lic.activate(input.value);
      note.textContent = res.text; go.disabled = false;
      if (res.ok) { unlocked = true; await refreshPlan(); close(); afterUnlock(); if (root.QuarryOnPlan) root.QuarryOnPlan(plan); }
    };
    go.addEventListener("click", run);
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") run(); });
    sheet(el("h2", { text: "Activate Kestrel" }), el("p", { text: "Paste the licence key from your purchase email." }),
      el("div", { class: "group" }, el("label", { class: "cell stack" }, el("span", { text: "Licence key" }), input)), note,
      el("div", { class: "row-end" }, cfg.buyUrl ? el("a", { class: "btn", href: cfg.buyUrl, target: "_blank", rel: "noreferrer", text: "Buy a Key" }) : null, go));
    setTimeout(() => input.focus(), 50);
  }

  async function licencePanel() {
    const st = await Lic.status(), saved = await Lic.load();
    const rows = [["Status", st.text]];
    if (saved && saved.key) rows.push(["Key", Lic.mask(saved.key)], ["Plan", saved.plan || "-"], ["Seats used", saved.limit ? `${saved.used || 1} of ${saved.limit}` : "-"],
      ["Last checked", saved.checkedAt ? new Date(saved.checkedAt).toLocaleString() : "-"]);
    const out = el("p", { class: "gate-note" });
    await refreshPlan();
    const cfg = root.QuarryLicenseConfig || {};
    const n = (v) => (v ? Number(v).toLocaleString() : "No limit");
    const stored = root.QuarryDB ? (await root.QuarryDB.keys()).length : 0;
    const daily = root.QuarryDB ? await root.QuarryDB.get("daily", null) : null;
    const today = daily && daily.date === root.QuarryLib.todayKey() ? daily.count : 0;
    const mine = Number(((await root.QuarryUI.loadSettings()).limits || {}).maxPerDay) || 0;
    const Lib = root.QuarryLib, searchLog = root.QuarryDB ? await root.QuarryDB.get("searchLog", []) : [];
    const frees = (w) => (w.full ? `, frees up ${new Date(w.resetAt).toLocaleString(undefined, { weekday: "short", hour: "2-digit", minute: "2-digit" })}` : "");
    const searchText = () => { if (!plan.searchesPerWindow) return "Safe daily limits only"; const w = Lib.windowState(searchLog, plan.windowHours || 2, plan.searchesPerWindow); return `${w.used} of ${w.cap}${frees(w)}`; };
    const limits = [["Modes", plan.modes.map((m) => ({ maps: "Maps", search: "Search", youtube: "YouTube", page: "Page", sites: "Sites" }[m])).join(", ")],
      ["New leads today", `${today.toLocaleString()} of ${n(plan.leadsPerDay)} on your plan${mine && (!plan.leadsPerDay || mine < plan.leadsPerDay) ? ` (your own setting: ${mine.toLocaleString()})` : ""}`], ["Leads stored", `${stored.toLocaleString()} of ${n(plan.maxLeads)}`],
      [`Google searches per ${plan.windowHours || 2} hours`, searchText()],
      ["Websites per Sites run", n(plan.sitesPerRun)], ["AI Fit", plan.aiModes.includes("api") ? "API key, Claude Code and manual" : "Manual review"],
      ["Custom rules", n(plan.rules)], ["Lists", n(plan.lists)], ["Saved views", n(plan.views)], ["Playbooks", n(plan.playbooks)],
      ["Export", plan.exportFormats.map((f) => f.toUpperCase()).join(", ")], ["Activity history", plan.activityDays ? `${plan.activityDays} days` : "All"]];
    sheet(el("h2", { text: `Plan: ${plan.name}` }), el("p", { text: `Kestrel ${version()}. Safety limits are the same on every plan.` }),
      el("div", { class: "group" }, ...rows.map(([a, b]) => el("div", { class: "cell" }, el("span", { text: a }), el("span", { class: "muted", text: b })))),
      el("div", { class: "group" }, ...limits.map(([a, b]) => el("div", { class: "cell" }, el("span", { text: a }), el("span", { class: "muted", text: b })))), out,
      el("div", { class: "row-end" },
        plan.id !== "owner" && plan.id !== "agency" && (cfg.upgradeUrl || cfg.buyUrl) ? el("a", { class: "btn", href: cfg.upgradeUrl || cfg.buyUrl, target: "_blank", rel: "noreferrer", text: "Upgrade" }) : null,
        plan.id !== "owner" && cfg.manageUrl ? el("a", { class: "btn", href: cfg.manageUrl, target: "_blank", rel: "noreferrer", text: "Manage Subscription" }) : null,
        saved && saved.key ? el("button", { class: "btn bad", text: "Remove From This Computer", style: "margin-right:auto", onclick: async () => {
          if (!confirm("Remove the licence from this computer? You can use the key on another one.")) return;
          const r = await Lic.deactivate(); out.textContent = r.text || ""; if (r.ok) { unlocked = false; lockScreen("Licence removed. Enter a key to use Kestrel here."); }
        } }) : null,
        el("button", { class: "btn go", text: "Done", onclick: close })));
  }

  // ---- "This needs Pro" when a plan limit is reached
  function upgrade(what, needs) {
    const cfg = root.QuarryLicenseConfig || {};
    const target = needs ? Plans.get(needs) : null;
    sheet(el("h2", { text: target ? `Upgrade to ${target.name}` : "Plan limit reached" }),
      el("p", { text: `${what}${target ? ` Upgrade to ${target.name} to use it.` : " Upgrade your plan for more."}` }),
      el("div", { class: "row-end" }, el("button", { class: "btn", text: "Not Now", onclick: close }),
        (cfg.upgradeUrl || cfg.buyUrl) ? el("a", { class: "btn go", href: cfg.upgradeUrl || cfg.buyUrl, target: "_blank", rel: "noreferrer", text: "See Plans" }) : null));
  }

  // ---- first-run agreement (selling builds only): what Kestrel does with data, and the user's duties
  function consentScreen() {
    return new Promise((resolve) => {
      const cfg = root.QuarryLicenseConfig || {}, google = ["maps", "search", "youtube"].some((m) => root.QuarryLib.featureOn(cfg, m));
      const box = el("input", { type: "checkbox", class: "pick" });
      const go = el("button", { class: "btn go", text: "Agree and Continue", disabled: "" });
      box.addEventListener("change", () => { go.disabled = !box.checked; });
      const point = (t) => el("div", { class: "cell note", text: `• ${t}` });
      go.addEventListener("click", async () => { await store.set("consent", { v: CONSENT, at: Date.now() }); close(); resolve(); });
      sheet(el("h2", { text: "Before You Start" }), el("p", { text: "Please read. It takes one minute." }),
        el("div", { class: "group" },
          ...(accountMode() ? [
            point("Kestrel works with your Kestrel account. The leads you collect are sent to your team in the Kestrel App (kestrelleads.com, stored in the EU), where your team can see them. Do-not-contact leads are never sent."),
            point("Your plan and payments are handled in the Kestrel App. Payments are made through Lemon Squeezy; Kestrel never sees your card."),
          ] : [
            point("Your leads stay on this computer. Kestrel has no server and does not see your data."),
            point("Kestrel sends only your licence key to our payment provider (Lemon Squeezy) to check it."),
          ]),
          point("AI Fit with your own Claude key sends lead text to Anthropic. Only when you start it."),
          point("OpenStreetMap mode uses the free OpenStreetMap data service. Kestrel names itself to that server and keeps a polite pace. Map data © OpenStreetMap contributors (ODbL): credit it if you publish data built from it."),
          point("Hiring, Companies and Podcasts modes use official services (public job boards, Companies House, Listen Notes). Hunter.io finds emails only when you ask, with your own key and credits."),
          point("Kestrel reads public business pages you choose. It follows each website's robots.txt and never signs in anywhere."),
          google ? point("Google's terms do not allow automated collection. Kestrel keeps slow, capped, Safe limits, but Google may still show checks or block your connection. You use the Google modes at your own risk.") : null,
          point("You are responsible for how you contact people: follow the email and privacy laws where you and they are (for example UK and EU rules), always include a way to say no, and use the Do-not-contact list.")),
        el("label", { class: "cell consent" }, box, el("span", { text: "I have read this and agree to the Terms of Use." })),
        el("div", { class: "row-end" }, go));
    });
  }

  // ---- What's New: the full list shows the newest version; earlier versions stay folded.
  function whatsNew() {
    const log = root.QuarryChangelog || [];
    if (!log.length) return;
    const card = (e) => el("ul", { class: "wn-list" }, ...e.items.map((t) => el("li", { text: t })));
    const [latest, ...older] = log;
    sheet(el("h2", { text: "What's New" }), el("p", { class: "muted", text: `Kestrel ${latest.version} · ${latest.title || ""}` }), card(latest),
      older.length ? el("details", { class: "wn-old" }, el("summary", { text: "Earlier versions" }),
        ...older.map((e) => el("div", {}, el("b", { text: `${e.version} · ${e.title || ""}` }), card(e)))) : null,
      el("div", { class: "row-end" }, el("button", { class: "btn go", text: "Got It", onclick: close })));
  }
  // After an update: one small note at the bottom, not a pop-up. Nothing blocks your work.
  function updatedNote(fromVersion) {
    const e = (root.QuarryChangelog || [])[0];
    document.querySelector(".upd.wn")?.remove();
    const bar = el("div", { class: "upd wn" }, el("b", { text: `Updated to ${version()}` }), el("span", { text: e && e.title ? e.title : `from ${fromVersion}` }),
      el("button", { class: "btn", text: "See What's New", onclick: () => { bar.remove(); whatsNew(); } }),
      el("button", { class: "btn go", text: "Got It", onclick: () => bar.remove() }));
    document.body.append(bar);
  }

  async function checkWhatsNew() {
    const seen = await store.get("seenVersion");
    await store.set("seenVersion", version());
    if (!seen) return; // first install: nothing "new" yet
    if (newer(version(), seen)) {
      updatedNote(seen);
      if (root.QuarryDB) root.QuarryDB.log("update", `Updated from ${seen} to ${version()}`);
    }
  }

  // ---- "Update ready" for copies sold outside the Chrome Web Store
  async function checkForUpdate(force) {
    const url = (root.QuarryLicenseConfig || {}).updateUrl;
    if (!url || !/^https:\/\//.test(url)) return null;
    const last = (await store.get("updateCheck")) || { at: 0 };
    let info = last.info || null;
    if (force || Date.now() - last.at > 86400000) {
      try {
        const res = await fetch(url, { cache: "no-store" });
        const data = await res.json();
        if (data && typeof data.version === "string") info = { version: data.version, notes: String(data.notes || "").slice(0, 400), url: UI.safeUrl(data.url) };
      } catch (_) { /* offline */ }
      await store.set("updateCheck", { at: Date.now(), info });
    }
    return info && newer(info.version, version()) ? info : null;
  }

  function updateBanner(info) {
    if (!info || document.querySelector(".upd")) return;
    const bar = el("div", { class: "upd" }, el("b", { text: `Kestrel ${info.version} is ready.` }), el("span", { text: info.notes }),
      info.url ? el("a", { class: "btn go", href: info.url, target: "_blank", rel: "noreferrer", text: "Get Update" }) : null,
      el("button", { class: "btn", text: "Later", onclick: () => bar.remove() }));
    document.body.append(bar);
  }

  // A new version is downloaded: offer a restart, but never while a search is running.
  // runActive is refreshed every 20 s during a run; older than 90 s means the run ended or the panel closed.
  async function restartBanner() {
    const got = await chrome.storage.local.get(["updateWaiting", "runActive"]);
    const v = got.updateWaiting, running = got.runActive && Date.now() - got.runActive < 90000;
    document.querySelector(".upd.restart")?.remove();
    if (!v || !newer(v, version())) return;
    const btn = el("button", { class: "btn go", text: running ? "After This Run" : "Update Now", onclick: () => chrome.runtime.reload() });
    if (running) btn.disabled = true;
    document.body.append(el("div", { class: "upd restart" }, el("b", { text: `Kestrel ${v} is ready.` }),
      el("span", { text: running ? "It installs when the current run ends. Your run will not be cut." : "Update Now takes a second. Your leads and settings stay. Open the panel again after it." }), btn));
  }

  // Your own copy (loaded from a folder): when the files in the folder are a newer version than the one running,
  // offer Update Now. It reloads Kestrel from the folder. Leads and settings stay. Never during a run.
  async function folderVersion() {
    try {
      const m = await (await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" })).json();
      return typeof m.version === "string" ? m.version : "";
    } catch (_) { return ""; }
  }
  async function checkFolder() {
    const v = await folderVersion();
    if (v && newer(v, version())) { await chrome.storage.local.set({ updateWaiting: v }); return v; }
    return "";
  }
  // The "Check for Update" button: the folder first, then the update address of sold copies.
  async function checkNow() {
    const v = await checkFolder();
    if (v) { restartBanner(); return `Kestrel ${v} is ready. Click Update Now.`; }
    const info = await checkForUpdate(true);
    if (info) { document.querySelector(".upd")?.remove(); updateBanner(info); return `Kestrel ${info.version} is available.`; }
    return `You have the newest version (${version()}).`;
  }

  async function afterUnlock() {
    await checkFolder();
    setInterval(checkFolder, 60000);
    await checkWhatsNew();
    updateBanner(await checkForUpdate());
    restartBanner();
    chrome.storage.onChanged.addListener((changes) => { if (changes.updateWaiting || changes.runActive) restartBanner(); });
  }

  // Tamper check (selling builds only): every file must match the fingerprint list made at build time.
  // A changed copy locks itself. It never touches the user's data or computer.
  async function intact() {
    const list = root.QuarryIntegrity;
    if (!list || !selling()) return true;
    try {
      for (const [path, want] of Object.entries(list.files || {})) {
        const buf = await (await fetch(chrome.runtime.getURL(path))).arrayBuffer();
        const got = [...new Uint8Array(await crypto.subtle.digest("SHA-256", buf))].map((b) => b.toString(16).padStart(2, "0")).join("");
        if (got !== want) return false;
      }
      return true;
    } catch (_) { return false; }
  }

  async function start() {
    if (!(await intact())) {
      unlocked = false;
      markReady(plan);
      sheet(el("h2", { text: "This Copy Was Changed" }), el("p", { text: "Some Kestrel files are not the original ones, so Kestrel stopped to protect you. Remove it and install Kestrel again from the official page. Your leads are safe in this browser." }));
      return;
    }
    if (selling()) {
      const c = await store.get("consent");
      if (!c || c.v < CONSENT) await consentScreen();
    }
    const st = await Lic.status();
    unlocked = st.ok;
    await refreshPlan();
    markReady(plan);
    if (!st.ok) return lockScreen(accountMode() ? st : st.text);
    await afterUnlock();
    // Re-check the licence a few times a day while open.
    setInterval(async () => {
      const s = await Lic.status(), before = plan.id;
      await refreshPlan();
      if (before !== plan.id && root.QuarryOnPlan) root.QuarryOnPlan(plan);
      if (!s.ok && unlocked) { unlocked = false; lockScreen(accountMode() ? s : s.text); }
    }, accountMode() ? 3600000 : 6 * 3600000);
  }

  root.QuarryGate = { start, ready, plan: () => plan, upgrade, allowed: () => unlocked, whatsNew: () => whatsNew(), licencePanel, checkForUpdate, checkNow, newer, version };
})(globalThis);
