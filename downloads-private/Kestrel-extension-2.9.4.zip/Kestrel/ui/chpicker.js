// Companies House picker: business types (tick, add, delete) and UK towns (suggestions, search, add, delete),
// with progress for each town, in the same style as the Maps picker.
// ctx: { cfg(), save(), coverage(), log() }
(function (root) {
  const L = root.QuarryLib, UI = root.QuarryUI, S = root.QuarrySources, { el, icon } = UI;

  // Older versions stored one type, raw SIC codes and a text box of towns. Move them into the lists once.
  function upgrade(c) {
    if (!Array.isArray(c.types)) c.types = [String(c.preset || "0")];
    if (!Array.isArray(c.customTypes)) c.customTypes = [];
    if (!Array.isArray(c.towns)) c.towns = [];
    if (!Array.isArray(c.customTowns)) c.customTowns = [];
    if (String(c.sic || "").trim()) {
      const name = `SIC ${String(c.sic).trim()}`;
      if (!c.customTypes.some((t) => t.name === name)) c.customTypes.push({ name, sic: String(c.sic).trim() });
      c.types = [`c:${name}`];
      c.sic = "";
    }
    if (String(c.places || "").trim()) {
      for (const t of L.parseLines(c.places)) { if (!c.towns.includes(t)) c.towns.push(t); }
      c.places = "";
    }
    return c;
  }

  // Selected business types as [{ id, label, sic }].
  function selectedTypes(c) {
    return (c.types || []).map((id) => {
      if (String(id).startsWith("c:")) { const t = (c.customTypes || []).find((x) => `c:${x.name}` === id); return t ? { id, label: t.name, sic: t.sic } : null; }
      const p = S.CH_PRESETS[Number(id)];
      return p ? { id, label: p[0], sic: p[1] } : null;
    }).filter(Boolean);
  }

  // UK towns from the built-in library, grouped by area, as short names ("Shoreditch").
  function ukAreas() {
    const uk = L.libCountry(UI.activeLibrary(), "United Kingdom");
    return uk ? uk.areas.map((a) => ({ name: a.name, towns: [...new Set(a.places.map((p) => String(p).split(",")[0].trim()))] })) : [];
  }

  function Picker(box, ctx) {
    let townFilter = "", adding = false;
    const c = () => upgrade(ctx.cfg().companies);
    const commit = () => { ctx.save(); render(); };
    const toggle = (list, items, on) => { const s = new Set(list); items.forEach((i) => (on ? s.add(i) : s.delete(i))); return [...s]; };
    const check = (on) => el("i", { class: `tick${on ? " on" : ""}` });

    // done / total searches for a town across the selected types
    function townState(town, types) {
      const cov = ctx.coverage() || {};
      const done = types.filter((t) => L.isDone(cov, L.coverKey("companies", t.label, town))).length;
      const part = types.some((t) => { const r = cov[L.coverKey("companies", t.label, town)]; return r && r.status !== "done"; });
      return { done, total: types.length, state: types.length && done === types.length ? "done" : done || part ? "partial" : "none" };
    }

    function typeBlock() {
      const cfg = c(), chosen = new Set(cfg.types);
      const chip = (id, label, removable) => el("button", { class: `chip${chosen.has(id) ? " on" : ""}`, title: removable ? "Click to select. × removes it." : "Click to select", onclick: () => { cfg.types = toggle(cfg.types, [id], !chosen.has(id)); commit(); } },
        label, removable ? el("span", { class: "x", title: "Delete this type", text: "×", onclick: (e) => {
          e.stopPropagation();
          if (!confirm(`Delete the business type "${label}"? Progress already saved stays.`)) return;
          cfg.customTypes = cfg.customTypes.filter((t) => t.name !== label);
          cfg.types = cfg.types.filter((x) => x !== id);
          commit();
        } }) : null);
      const presets = S.CH_PRESETS.map((p, i) => chip(String(i), p[0], false));
      const customs = cfg.customTypes.map((t) => chip(`c:${t.name}`, t.name, true));
      const form = adding ? (() => {
        const name = el("input", { type: "text", placeholder: "Name, e.g. Web design" });
        const sic = el("input", { type: "text", placeholder: "SIC codes, e.g. 62012, 74100" });
        const save = () => {
          const n = name.value.trim().slice(0, 40), codes = sic.value.split(/[^0-9]+/).filter((x) => /^\d{4,5}$/.test(x));
          if (!n || !codes.length) return ctx.log("Add a name and at least one SIC code (4 or 5 digits).", true);
          if (cfg.customTypes.some((t) => t.name.toLowerCase() === n.toLowerCase()) || S.CH_PRESETS.some((p) => p[0].toLowerCase() === n.toLowerCase())) return ctx.log("That name is already in the list.", true);
          cfg.customTypes.push({ name: n, sic: codes.join(",") });
          cfg.types = toggle(cfg.types, [`c:${n}`], true);
          adding = false;
          commit();
        };
        sic.addEventListener("keydown", (e) => { if (e.key === "Enter") save(); });
        setTimeout(() => name.focus(), 30);
        return [el("div", { class: "cell stack" }, name), el("div", { class: "cell stack" }, sic),
          el("div", { class: "cell" }, el("a", { class: "link", href: "https://resources.companieshouse.gov.uk/sic/", target: "_blank", rel: "noreferrer", text: "Find SIC codes" }),
            el("span", { class: "sp" }), el("button", { class: "link", text: "Cancel", onclick: () => { adding = false; render(); } }), el("button", { class: "btn go", id: "addTypeSave", text: "Add", onclick: save }))];
      })() : [];
      return [
        el("div", { class: "cap row" }, el("span", { text: "Business types" }), el("span", { class: "cnt", text: `${cfg.types.length} selected` })),
        el("div", { class: "group" },
          el("div", { class: "cell chips" }, ...presets, ...customs),
          ...(adding ? form : [el("div", { class: "cell" }, el("button", { class: "link", id: "addType", text: "+ Add your own type", onclick: () => { adding = true; render(); } }),
            el("span", { class: "muted", text: "SIC codes from the UK register" }))])),
      ];
    }

    function townBlock() {
      const cfg = c(), chosen = new Set(cfg.towns), types = selectedTypes(cfg), q = townFilter.trim().toLowerCase();
      const areas = [...ukAreas(), ...(cfg.customTowns.length ? [{ name: "Your towns", towns: cfg.customTowns, custom: true }] : [])];
      const areaChips = areas.map((a) => {
        const n = a.towns.filter((t) => chosen.has(t)).length, on = n === a.towns.length && n > 0;
        return el("button", { class: `chip${on ? " on" : n ? " part" : ""}`, onclick: () => { cfg.towns = toggle(cfg.towns, a.towns, !on); commit(); } }, `${a.name} `, el("span", { class: "n", text: String(a.towns.length) }));
      });
      const known = new Set(areas.flatMap((a) => a.towns.map((t) => t.toLowerCase())));
      const list = [];
      for (const a of areas) {
        const towns = a.towns.filter((t) => !q || t.toLowerCase().includes(q));
        if (!towns.length) continue;
        list.push(el("div", { class: "areah", text: a.name }));
        for (const t of towns) {
          const on = chosen.has(t), st = townState(t, types);
          list.push(el("button", { class: "pickrow", onclick: () => { cfg.towns = toggle(cfg.towns, [t], !on); commit(); } },
            check(on), el("span", { class: "nm", text: t }),
            on && types.length ? el("span", { class: `meta${st.state === "done" ? " ok" : ""}`, text: `${st.done}/${st.total}` }) : null,
            el("i", { class: `dot ${on ? st.state : "none"}`, title: { done: "Finished", partial: "In progress", none: "Not started" }[on ? st.state : "none"] }),
            a.custom ? el("span", { class: "x", title: "Delete this town", text: "×", onclick: (e) => {
              e.stopPropagation();
              cfg.customTowns = cfg.customTowns.filter((x) => x !== t);
              cfg.towns = cfg.towns.filter((x) => x !== t);
              commit();
            } }) : null));
        }
      }
      const raw = townFilter.trim().replace(/\s+/g, " ").slice(0, 60);
      const addNew = raw && !known.has(raw.toLowerCase()) ? el("button", { class: "pickrow add", id: "addTown", onclick: () => {
        const name = raw.replace(/\b\w/g, (x) => x.toUpperCase());
        cfg.customTowns = toggle(cfg.customTowns, [name], true);
        cfg.towns = toggle(cfg.towns, [name], true);
        townFilter = "";
        commit();
      } }, el("span", { class: "plus", text: "+" }), el("span", { class: "nm", text: `Add "${raw}" as a town` })) : null;
      if (!list.length) list.push(el("div", { class: "areah", text: addNew ? "Not in the list yet:" : "No towns match." }));
      const filter = el("input", { type: "search", placeholder: "Find or add a town", value: townFilter, class: "chfind" });
      filter.addEventListener("input", () => { townFilter = filter.value; const at = filter.selectionStart; render(); const f2 = box.querySelector(".chfind"); f2.focus(); f2.setSelectionRange(at, at); });
      filter.addEventListener("keydown", (e) => { if (e.key === "Enter" && box.querySelector("#addTown")) box.querySelector("#addTown").click(); });
      const selectedChips = cfg.towns.slice(0, 40).map((t) => el("button", { class: "chip on", title: "Click to remove", onclick: () => { cfg.towns = cfg.towns.filter((x) => x !== t); commit(); } }, t, el("span", { class: "x", text: "×" })));
      return [
        el("div", { class: "cap row" }, el("span", { text: "Towns (United Kingdom)" }), el("span", { class: "cnt", text: `${cfg.towns.length} selected` })),
        el("div", { class: "group" },
          cfg.towns.length ? el("div", { class: "cell chips" }, ...selectedChips, cfg.towns.length > 40 ? el("span", { class: "muted", text: `+${cfg.towns.length - 40} more` }) : null) : null,
          el("div", { class: "cell chips" }, ...areaChips),
          el("div", { class: "cell" }, icon("search"), filter,
            el("button", { class: "link", text: "Clear", onclick: () => { cfg.towns = []; commit(); } })),
          el("div", { class: "picklist tall scroll" }, ...list, ...(addNew ? [addNew] : []))),
      ];
    }

    function progressBlock() {
      const cfg = c(), types = selectedTypes(cfg), cov = ctx.coverage() || {};
      let total = 0, done = 0, saved = 0;
      for (const town of cfg.towns) for (const t of types) {
        total += 1;
        const r = cov[L.coverKey("companies", t.label, town)];
        if (r && r.status === "done") done += 1;
        if (r) saved += r.saved || 0;
      }
      return [
        el("div", { class: "cap row" }, el("span", { text: "Progress" })),
        el("div", { class: "group" },
          el("div", { class: "cell prog" }, el("div", { class: "bar" }, el("i", { style: `transform:scaleX(${total ? done / total : 0})` })),
            el("div", { class: "nums" },
              el("div", {}, el("b", { text: String(done) }), el("span", { text: `of ${total} searches` })),
              el("div", {}, el("b", { text: String(cfg.towns.length) }), el("span", { text: "towns" })),
              el("div", {}, el("b", { text: String(saved) }), el("span", { text: "companies saved" })))),
          el("div", { class: "cell" }, el("span", { class: "muted", text: !types.length ? "Tick at least one business type." : !cfg.towns.length ? "Tick or add at least one town." : total - done ? `${total - done} searches left.` : "Every search in this selection is done." }))),
      ];
    }

    function render() {
      const scroller = box.closest(".body") || box.parentElement, top = scroller.scrollTop;
      const lists = [...box.querySelectorAll(".picklist")].map((n) => n.scrollTop);
      box.replaceChildren(...typeBlock(), ...townBlock(), ...progressBlock());
      box.querySelectorAll(".picklist").forEach((n, i) => { n.scrollTop = lists[i] || 0; });
      scroller.scrollTop = top;
    }

    return { render, selection: () => ({ types: selectedTypes(c()), towns: [...c().towns] }) };
  }

  root.QuarryCompanyPicker = Picker;
  root.QuarryCompanyTypes = { upgrade, selectedTypes };
})(globalThis);
