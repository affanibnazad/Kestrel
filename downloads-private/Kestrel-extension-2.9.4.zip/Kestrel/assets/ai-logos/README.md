# AI logos for Kestrel

In use now (11 Nov 2026): claude.png, chatgpt.png, gemini.png (128 px copies of the Wikimedia files), openrouter.svg, claude-code.svg, codex.svg, other.svg. The originals stay in their folders.

Put your logo files in this folder with these exact names. Kestrel uses them on the AI Fit buttons.
Until a file is here, Kestrel shows a coloured letter badge instead.

| File name | Shown on | Letter badge until then |
|---|---|---|
| `claude.svg` | AI Fit → API Key → **Claude** button | Orange "C" |
| `chatgpt.svg` | AI Fit → API Key → **ChatGPT** button | Green "O" |
| `gemini.svg` | AI Fit → API Key → **Gemini** button | Blue "G" |
| `openrouter.svg` | AI Fit → API Key → **OpenRouter** button | Purple "R" |
| `other.svg` | AI Fit → API Key → **Other** button (optional) | Grey "+" |
| `claude-code.svg` | AI Fit → Coding Agent steps, next to "Claude Code" | Orange "C" |
| `codex.svg` | AI Fit → Coding Agent steps, next to "Codex" | Green "X" |

## File rules
- **SVG is best.** PNG also works: use the same name with `.png` (for example `claude.png`), square, at least 64 × 64 pixels.
- Square logos look best. Kestrel shows them at 28 × 28 on a white rounded tile.
- Use only logos you are allowed to use: download them from each company's official brand or press page
  (Anthropic, OpenAI, Google, OpenRouter), and follow their brand rules.
- SVG files must be plain images. Kestrel shows them as pictures, so any script inside them never runs.

After adding files, reload Kestrel in `brave://extensions`.
