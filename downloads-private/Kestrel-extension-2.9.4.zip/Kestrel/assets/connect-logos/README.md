# Connection logos for Kestrel

In use (11 Nov 2026), 128 px PNGs: hunter.png (hunter.io touch icon), companies-house.png (the GOV.UK crown icon that Companies House's own site uses), listen-notes.png (Listen Notes' official GitHub avatar).

Put each service's logo here with these exact names. Kestrel shows them in Workspace → Connections.
Until a file is here, Kestrel shows a coloured letter instead.

| File name | Service |
|---|---|
| `companies-house.svg` (or `.png`) | Companies House |
| `hunter.svg` (or `.png`) | Hunter.io |
| `listen-notes.svg` (or `.png`) | Listen Notes |

Square, at least 64 × 64 pixels. SVG files must be plain images (Kestrel shows them as pictures, so any script inside never runs).
Use logos from each company's own brand or press page, and follow their brand rules.
After adding files, click Update Now in Kestrel (or reload it in brave://extensions).
