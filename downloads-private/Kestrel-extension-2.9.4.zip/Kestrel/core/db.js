// IndexedDB store shared by the console and workspace. Handles large lists and single-record updates.
//
// Workspaces: each workspace has its own database (leads, settings, progress, playbooks, views).
// The "default" workspace uses the original database name "quarry", so older data keeps working.
// SHARED keys always live in the default database, whichever workspace is open:
//   safety counts and pauses (switching workspace must never reset a daily limit),
//   the do-not-contact list (an opt-out applies everywhere), the activity log, AI keys and offer profiles.
(function (root) {
  const SHARED = ["usage", "cooldown", "daily", "searchLog", "dnc", "activity", "aiKeys", "aiKey", "apiKeys", "apiKeyStatus", "offerProfiles"];
  const channel = new BroadcastChannel("quarry");
  const conns = new Map();
  let active = null; // { id, name }

  const dbName = (id) => (!id || id === "default" ? "quarry" : `quarry-ws-${id}`);
  function openDb(name) {
    if (!conns.has(name)) conns.set(name, new Promise((resolve, reject) => {
      const req = indexedDB.open(name, 1);
      req.onupgradeneeded = () => {
        req.result.createObjectStore("leads", { keyPath: "id" });
        req.result.createObjectStore("meta");
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
    return conns.get(name);
  }
  const hasStore = () => !!(root.chrome && chrome.storage && chrome.storage.local);
  async function activeWs() {
    if (active) return active;
    let id = "default", list = [];
    if (hasStore()) {
      const got = await chrome.storage.local.get(["activeWorkspace", "workspaces"]);
      list = got.workspaces || [];
      id = got.activeWorkspace && list.some((w) => w.id === got.activeWorkspace) ? got.activeWorkspace : "default";
    }
    const hit = list.find((w) => w.id === id);
    active = { id, name: hit ? hit.name : "Main", color: hit ? hit.color : "" };
    return active;
  }
  const open = async () => openDb(dbName((await activeWs()).id));
  const openFor = async (key) => (SHARED.includes(key) ? openDb("quarry") : open());
  const done = (tx) => new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error); });
  const asked = (req) => new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });

  root.QuarryDB = {
    SHARED,
    async putMany(leads) {
      if (!leads.length) return;
      const db = await open(), tx = db.transaction("leads", "readwrite");
      leads.forEach((l) => tx.objectStore("leads").put(l));
      await done(tx);
      channel.postMessage("leads");
      if (root.QuarryCloud) root.QuarryCloud.changed(leads); // Kestrel App sync (only when connected)
    },
    async one(id) { const db = await open(); return asked(db.transaction("leads").objectStore("leads").get(id)); },
    async all() { const db = await open(); return asked(db.transaction("leads").objectStore("leads").getAll()); },
    async keys() { const db = await open(); return asked(db.transaction("leads").objectStore("leads").getAllKeys()); },
    async remove(ids) {
      const db = await open(), tx = db.transaction("leads", "readwrite");
      ids.forEach((id) => tx.objectStore("leads").delete(id));
      await done(tx);
      channel.postMessage("leads");
    },
    // Clears this workspace. Shared data (safety counts, pauses, activity, do-not-contact, offer profiles) always stays:
    // a wipe must never reset daily limits or forget who asked not to be contacted.
    // The AI keys are removed only when you clear the Main workspace.
    async clearAll() {
      const ws = await activeWs(), db = await open(), keep = {};
      const keepKeys = SHARED.filter((k) => ws.id !== "default" || !["aiKeys", "aiKey", "apiKeys", "apiKeyStatus"].includes(k));
      if (ws.id === "default") for (const k of keepKeys) keep[k] = await asked(db.transaction("meta").objectStore("meta").get(k));
      const tx = db.transaction(["leads", "meta"], "readwrite");
      tx.objectStore("leads").clear();
      tx.objectStore("meta").clear();
      for (const [k, v] of Object.entries(keep)) if (v !== undefined) tx.objectStore("meta").put(v, k);
      await done(tx);
      channel.postMessage("leads");
    },
    async get(key, fallback) {
      const db = await openFor(key);
      const value = await asked(db.transaction("meta").objectStore("meta").get(key));
      return value === undefined ? fallback : value;
    },
    async set(key, value) {
      const db = await openFor(key), tx = db.transaction("meta", "readwrite");
      tx.objectStore("meta").put(value, key);
      await done(tx);
      if (["settings", "coverage", "customLibrary", "usage", "cooldown", "daily", "searchLog", "dnc", "offerProfiles"].includes(key)) channel.postMessage(key);
    },
    // Activity log: one line per thing that happened, newest first, last 3,000 kept. Shared, tagged with the workspace.
    async log(type, text, extra) {
      try {
        const ws = await activeWs();
        const db = await openDb("quarry"), tx = db.transaction("meta", "readwrite"), store = tx.objectStore("meta");
        const list = (await asked(store.get("activity"))) || [];
        list.unshift({ at: Date.now(), type, text: String(text).slice(0, 300), ws: ws.name, ...(extra || {}) });
        store.put(list.slice(0, 3000), "activity");
        await done(tx);
        channel.postMessage("activity");
      } catch (_) { /* the log must never break real work */ }
    },

    // ---- workspaces
    workspace: activeWs,
    async workspaces() {
      const list = hasStore() ? (await chrome.storage.local.get("workspaces")).workspaces || [] : [];
      return [{ id: "default", name: "Main", color: "#007AFF", createdAt: 0 }, ...list.filter((w) => w.id !== "default")];
    },
    async createWorkspace(name, color) {
      const list = hasStore() ? (await chrome.storage.local.get("workspaces")).workspaces || [] : [];
      const ws = { id: crypto.randomUUID().slice(0, 8), name: String(name).trim().slice(0, 40) || "Workspace", color: color || "#34C759", createdAt: Date.now() };
      await chrome.storage.local.set({ workspaces: [...list, ws] });
      return ws;
    },
    async renameWorkspace(id, name, color) {
      if (id === "default") return;
      const list = (await chrome.storage.local.get("workspaces")).workspaces || [];
      await chrome.storage.local.set({ workspaces: list.map((w) => (w.id === id ? { ...w, name: String(name).trim().slice(0, 40) || w.name, color: color || w.color } : w)) });
      channel.postMessage("workspace");
    },
    async switchWorkspace(id) {
      await chrome.storage.local.set({ activeWorkspace: id || "default" });
      active = null;
      channel.postMessage("workspace");
    },
    // Deletes a workspace and all its leads. The Main workspace cannot be deleted.
    async deleteWorkspace(id) {
      if (!id || id === "default") return false;
      const list = (await chrome.storage.local.get("workspaces")).workspaces || [];
      await chrome.storage.local.set({ workspaces: list.filter((w) => w.id !== id) });
      const cur = await activeWs();
      if (cur.id === id) await this.switchWorkspace("default");
      const name = dbName(id);
      if (conns.has(name)) { (await conns.get(name)).close(); conns.delete(name); }
      await new Promise((resolve) => { const r = indexedDB.deleteDatabase(name); r.onsuccess = r.onerror = r.onblocked = () => resolve(); });
      channel.postMessage("workspace");
      return true;
    },

    onChange(fn) { channel.addEventListener("message", (e) => fn(e.data)); },
  };
})(globalThis);
