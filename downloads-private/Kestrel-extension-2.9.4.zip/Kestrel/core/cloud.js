// Kestrel App sync: sends this browser's leads and search progress to your team in the Kestrel App (kestrelleads.com).
// How it connects: App → Settings → Extension → "Connect the extension" hands this extension a connection key. The key can only add
// or update your team's leads and progress (database functions ext_*); it cannot read anything. It is kept in this browser
// (chrome.storage.local), never in backups or exports. Disconnect any time, here or in the App.
// Leads use the same one-per-business rule as the App (website domain, else email, else phone, else name + place).
(function (root) {
  const STORE = "cloud";          // { url, key (publishable), token, team, email, auto, at }
  const PENDING = "cloudPending"; // ids of leads waiting to be sent (kept if offline or the App is busy)
  const store = {
    get: async (k) => (await chrome.storage.local.get(k))[k],
    set: (k, v) => chrome.storage.local.set({ [k]: v }),
  };

  // ---- the same rules as the App (quarry-cloud/src/lib/leads.ts)
  const domain = (url) => {
    if (!url) return "";
    try { return new URL(/^https?:/i.test(url) ? url : `https://${url}`).hostname.replace(/^www\./, "").toLowerCase(); } catch (_) { return ""; }
  };
  function dedupeKey(l) {
    const d = domain(l.website); if (d) return `site:${d}`;
    if (l.email) return `email:${String(l.email).toLowerCase().trim()}`;
    const digits = String(l.phone || "").replace(/\D/g, ""); if (digits.length >= 7) return `phone:${digits}`;
    return `name:${String(l.name || "").toLowerCase().trim()}|${String(l.location || l.address || "").toLowerCase().trim()}`;
  }
  const verdictOf = (l) => {
    // The AI's verdict first; otherwise a team rule's mark (Mark Good / Mark No, 2.9.4).
    const v = String((l.ai && (l.ai.verdict || l.ai.fit)) || l.ruleMark || "").toLowerCase();
    return v.startsWith("good") ? "Good" : v.startsWith("maybe") ? "Maybe" : v.startsWith("no") ? "No" : null;
  };
  // A lead as the App stores it. Removed leads and leads on the Do-not-contact list are never sent.
  function toRow(l) {
    return {
      dedupe_key: dedupeKey(l), name: l.name || null, category: l.category || null, location: l.location || l.address || null, source: l.source || null,
      email: l.email || null, phone: l.phone || null, website: l.website || null, verdict: verdictOf(l), reason: (l.ai && l.ai.reason) || null,
      score: null, tier: null,   // points scoring was removed in 2.9.4
      hiring: Boolean(l.hiring && l.hiring.jobs && l.hiring.jobs.length), named: Boolean(l.contacts && l.contacts.length), data: l,
    };
  }
  const sendable = (l) => l && l.id && l.status !== "removed" && !l.dnc;

  // ---- connection
  const conn = () => store.get(STORE);
  const connected = async () => { const c = await conn(); return Boolean(c && c.token && c.url && c.key); };
  async function rpc(name, body) {
    const c = await conn();
    if (!c || !c.token) throw new Error("Not connected to the Kestrel App.");
    const res = await fetch(`${c.url}/rest/v1/rpc/${name}`, {
      method: "POST", credentials: "omit",
      headers: { "content-type": "application/json", apikey: c.key, authorization: `Bearer ${c.key}` },
      body: JSON.stringify({ k: c.token, ...body }), signal: AbortSignal.timeout(30000),
    });
    const text = await res.text();
    if (!res.ok) {
      let msg = text; try { msg = JSON.parse(text).message || text; } catch (_) { /* plain text */ }
      const err = new Error(String(msg).replace(/^PLAN_NEEDED:\s*/, "").slice(0, 200)); err.status = res.status; err.revoked = /not valid any more|can no longer/i.test(msg);
      err.plan = /PLAN_NEEDED/.test(msg);
      if (err.plan) { const c = await conn(); if (c) await store.set(STORE, { ...c, active: false, statusAt: Date.now() }); }
      throw err;
    }
    try { return JSON.parse(text); } catch (_) { return text; }
  }
  // Saves the key the App handed over, after checking it works.
  async function connect(info) {
    const ok = (u) => { try { const x = new URL(u); return x.protocol === "https:" || ["localhost", "127.0.0.1"].includes(x.hostname); } catch (_) { return false; } };
    if (!info || !/^kst_[a-f0-9]{48}$/.test(String(info.token || "")) || !ok(info.url) || !info.key) throw new Error("That connection code is not complete.");
    await store.set(STORE, { url: String(info.url).replace(/\/+$/, ""), key: String(info.key), token: String(info.token), auto: true, at: Date.now(), team: "", email: "" });
    try {
      const me = await rpc("ext_whoami", {});
      const c = await conn(); await store.set(STORE, { ...c, ...statusOf(me) });
      log("cloud", `Connected to the Kestrel App (${(me && me.team) || "your team"})`);
      pullKeys().catch(() => {});
      syncDnc().catch(() => {});
      pullRules().catch(() => {});
      return me;
    } catch (e) { await store.set(STORE, null); throw e; }
  }
  // What the App says about this team: its name, and whether it may collect (trial running or plan paid).
  const statusOf = (me) => ({ team: (me && me.team) || "", email: (me && me.email) || "", active: !me || me.active !== false, plan: (me && me.plan) || "",
    trialEndsAt: (me && me.trial_ends_at) || null, paidUntil: (me && me.paid_until) || null, statusAt: Date.now() });
  async function refreshStatus() {
    if (!(await connected())) return null;
    try {
      const me = await rpc("ext_whoami", {});
      const c = await conn(); if (c) await store.set(STORE, { ...c, ...statusOf(me) });
      return me;
    } catch (e) { if (e.revoked) await store.set(STORE, null); throw e; }
  }
  async function disconnect() { await store.set(STORE, null); await store.set(PENDING, []); log("cloud", "Disconnected from the Kestrel App"); }
  async function setAuto(on) { const c = await conn(); if (c) await store.set(STORE, { ...c, auto: Boolean(on) }); }
  // A connection code the App shows when it cannot reach the extension directly ("kestrel:" + base64 JSON).
  function parseCode(text) {
    const s = String(text || "").trim().replace(/^kestrel:/, "");
    try { return JSON.parse(atob(s)); } catch (_) { return null; }
  }

  // ---- leads
  let timer = 0;
  const waiting = new Set();
  // Called after any lead is saved in this browser. Sends a few seconds later, in batches.
  function changed(leads) {
    for (const l of leads || []) if (l && l.id) waiting.add(l.id);
    clearTimeout(timer);
    timer = setTimeout(() => { flush().catch(() => {}); }, 4000);
  }
  async function flush() {
    const c = await conn();
    if (!c || !c.token) { waiting.clear(); return { sent: 0 }; } // collector only: every lead goes to the App
    const ids = [...new Set([...(await store.get(PENDING) || []), ...waiting])];
    waiting.clear();
    if (!ids.length) return { sent: 0 };
    const DB = root.QuarryDB;
    const leads = (await Promise.all(ids.map((id) => DB.one(id).catch(() => null)))).filter(sendable);
    return sendLeads(leads, ids);
  }
  async function sendLeads(leads, ids) {
    let sent = 0;
    // Never send anyone on the Do-not-contact list.
    const L = root.QuarryLib, DB = root.QuarryDB;
    if (L && L.dncIndex && DB) { const idx = L.dncIndex(await DB.get("dnc", [])); leads = leads.filter((l) => !L.dncBlocks(l, idx)); }
    try {
      const rows = [...new Map(leads.map((l) => { const r = toRow(l); return [r.dedupe_key, r]; })).values()];
      for (let i = 0; i < rows.length; i += 200) sent += Number(await rpc("ext_push_leads", { rows: rows.slice(i, i + 200) })) || 0;
      await store.set(PENDING, []);
      const c = await conn(); if (c) await store.set(STORE, { ...c, lastSent: Date.now() });
      return { sent };
    } catch (e) {
      if (e.revoked) { await store.set(STORE, null); log("cloud", e.message); }
      else if (e.plan) { log("cloud", e.message); await store.set(PENDING, [...new Set([...(await store.get(PENDING) || []), ...(ids || leads.map((l) => l.id))])].slice(-20000)); }
      else await store.set(PENDING, [...new Set([...(await store.get(PENDING) || []), ...(ids || leads.map((l) => l.id))])].slice(-20000));
      throw e;
    }
  }
  // Sends every lead kept in this browser (once, the first time the side panel opens while connected).
  async function sendAll() {
    const leads = (await root.QuarryDB.all()).filter(sendable);
    const r = await sendLeads(leads);
    log("cloud", `Sent ${leads.length} leads to the Kestrel App`);
    return { ...r, total: leads.length };
  }

  // ---- search progress
  async function pushProgress(key, rec) {
    if (!(await connected()) || !key || !rec) return;
    try { await rpc("ext_push_progress", { rows: [{ key, status: rec.status === "done" ? "done" : "partial", found: Number(rec.found) || 0, saved: Number(rec.saved) || 0, at: new Date(rec.at || Date.now()).toISOString() }] }); }
    catch (_) { /* progress is a convenience; the next search sends it again */ }
  }
  async function pullProgress() {
    if (!(await connected())) return null;
    try { const p = await rpc("ext_pull_progress", {}); return p && typeof p === "object" ? p : null; } catch (_) { return null; }
  }

  // ---- team keys (App → Connections). Fills a key here when it is empty, or when it is still the one that came
  // from the App before. A key you typed into this extension yourself is never overwritten.
  const SOURCE_KEYS = ["companiesHouse", "hunter", "listenNotes"], AI_KEYS = ["anthropic", "openai", "gemini", "openrouter"];
  async function pullKeys() {
    const DB = root.QuarryDB;
    if (!DB || !(await connected())) return 0;
    let team;
    try { team = await rpc("ext_team_keys", {}); } catch (_) { return 0; }
    if (!team || typeof team !== "object") return 0;
    const before = (await store.get("cloudKeys")) || {}, api = (await DB.get("apiKeys", {})) || {};
    const ai = (await DB.get("aiKeys", null)) || { anthropic: (await DB.get("aiKey", "")) || "" }; // keep a key from very old versions
    let n = 0;
    const take = (bag, id) => { const v = team[id]; if (!v) return; if (!bag[id] || bag[id] === before[id]) { if (bag[id] !== v) n++; bag[id] = v; } };
    SOURCE_KEYS.forEach((id) => take(api, id));
    AI_KEYS.forEach((id) => take(ai, id));
    await DB.set("apiKeys", api); await DB.set("aiKeys", ai);
    await store.set("cloudKeys", team);
    if (n) log("cloud", `Got ${n} ${n === 1 ? "key" : "keys"} from the Kestrel App`);
    return n;
  }

  // The team's Do-not-contact list: send this extension's entries (the App only ever adds them), take the team's back.
  // Merge only: nothing is ever taken off the list here. Works after the trial too.
  async function syncDnc() {
    const DB = root.QuarryDB, L = root.QuarryLib;
    if (!DB || !L || !(await connected())) return 0;
    const mine = (await DB.get("dnc", [])) || [];
    let team;
    try { team = await rpc("ext_sync_dnc", { rows: mine.filter((r) => r && r.entry).slice(-5000).map((r) => ({ entry: r.entry, reason: r.reason || "" })) }); } catch (_) { return 0; }
    if (!Array.isArray(team)) return 0;
    const have = new Set(mine.map((r) => r.entry)), add = [];
    for (const r of team) {
      const e = L.normalizeDnc(r && r.entry);
      if (e && !have.has(e)) { have.add(e); add.push({ entry: e, reason: (r.reason || "from your team").slice(0, 200), at: Date.parse(r.at) || Date.now() }); }
    }
    if (add.length) { await DB.set("dnc", [...((await DB.get("dnc", [])) || []), ...add]); log("dnc", `Got ${add.length} Do-not-contact ${add.length === 1 ? "entry" : "entries"} from your team`); }
    return add.length;
  }

  // The team's Rules and scoring from the App: score weights, tier cut-offs, custom rules and collection filters.
  // Each part is taken only while this workspace still has what it last got from the team (or the defaults, the first time),
  // so a change someone made inside this extension is never overwritten. Returns how many parts changed.
  const RULE_PARTS = ["weights", "tiers", "rules", "refine"];
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  async function pullRules() {
    const DB = root.QuarryDB, L = root.QuarryLib;
    if (!DB || !L || !(await connected())) return 0;
    let team;
    try { team = await rpc("ext_team_rules", {}); } catch (_) { return 0; }
    if (!team || typeof team !== "object") return 0;
    const s = L.mergeDefaults(await DB.get("settings", null)), base = L.mergeDefaults({});
    const { rules: _ignore, ...filters } = s.refine, { rules: _b, ...baseFilters } = base.refine;
    const mine = { weights: s.weights, tiers: s.tiers, rules: s.refine.rules || [], refine: filters };
    const before = (await DB.get("cloudRules", null)) || { weights: base.weights, tiers: base.tiers, rules: [], refine: baseFilters };
    const theirs = {
      weights: { ...base.weights, ...(team.weights || {}) }, tiers: { ...base.tiers, ...(team.tiers || {}) },
      rules: Array.isArray(team.rules) ? team.rules : [], refine: { ...baseFilters, ...(team.refine || {}) },
    };
    let n = 0;
    for (const part of RULE_PARTS) {
      if (same(mine[part], theirs[part]) || !same(mine[part], before[part])) continue; // already the same, or changed here
      mine[part] = theirs[part]; n++;
    }
    await DB.set("cloudRules", theirs);
    if (!n) return 0;
    s.weights = mine.weights; s.tiers = mine.tiers; s.refine = { ...s.refine, ...mine.refine, rules: mine.rules };
    await DB.set("settings", s);
    await DB.set("rulesChangedAt", Date.now());
    log("cloud", "Got your team's Rules and scoring from the Kestrel App");
    return n;
  }

  // ---- Autopilot (App database 042): the searches the team's goal asks for. null when off, not set up, or not connected.
  async function pullAutopilot() {
    if (!(await connected())) return null;
    try {
      const g = await rpc("ext_autopilot", {});
      if (!g || !g.on || !Array.isArray(g.keywords) || !Array.isArray(g.places) || !g.keywords.length || !g.places.length) return null;
      return { source: g.source === "osm" ? "osm" : "maps", keywords: g.keywords.map(String).slice(0, 50), places: g.places.map(String).slice(0, 300) };
    } catch (_) { return null; }
  }

  function log(kind, text) { try { if (root.QuarryDB && root.QuarryDB.log) root.QuarryDB.log(kind, text); } catch (_) { /* ignore */ } }

  const api = { dedupeKey, toRow, connect, disconnect, refreshStatus, statusOf, setAuto, parseCode, conn, connected, changed, flush, sendAll, pushProgress, pullProgress, pullKeys, syncDnc, pullRules, pullAutopilot };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QuarryCloud = api;
})(globalThis);
