// Subscription plans. Numbers here are PROPOSED: change them in one place and every limit follows.
// Rules that never change by plan:
//  - Safety (daily Google limits, pauses, signed-in stop, robots.txt) is the same for everyone.
//    A higher plan never searches Google faster or more than Safe allows.
//  - Do-not-contact, backups, restore and moving profiles are in every plan.
// Limits set by Affan, 11 Nov 2026:
//  - leadsPerDay: new leads saved today (resets at local midnight), from every mode.
//  - searchesPerWindow every windowHours (2 hours): Google searches, Maps + Search + YouTube together.
// Both are shared by every workspace and sit on top of the daily safety caps, so they can only lower Google use.
// 0 means "no limit". Leads stored is per workspace. AI Fit uses the buyer's own AI key or coding agent, so every plan gets every AI mode.
(function (root) {
  const ALL_MODES = ["maps", "search", "youtube", "osm", "jobs", "companies", "podcasts", "page", "sites"];
  const PLANS = {
    starter: {
      id: "starter", name: "Starter", rank: 1,
      modes: ["maps", "osm", "jobs", "page", "sites"],
      leadsPerDay: 1000, maxLeads: 10000, sitesPerRun: 50,
      aiModes: ["api", "code", "manual"],
      rules: 3, lists: 3, views: 3, playbooks: 1, workspaces: 1, offerProfiles: 3,
      windowHours: 2, searchesPerWindow: 10,
      exportFormats: ["csv"], activityDays: 7, devices: 1,
    },
    pro: {
      id: "pro", name: "Pro", rank: 2,
      modes: ["maps", "search", "youtube", "osm", "jobs", "companies", "podcasts", "page", "sites"],
      leadsPerDay: 5000, maxLeads: 50000, sitesPerRun: 300,
      aiModes: ["api", "code", "manual"],
      rules: 25, lists: 20, views: 20, playbooks: 10, workspaces: 3, offerProfiles: 10,
      windowHours: 2, searchesPerWindow: 20,
      exportFormats: ["csv", "json", "txt"], activityDays: 90, devices: 2,
    },
    agency: {
      id: "agency", name: "Agency", rank: 3,
      modes: ALL_MODES,
      leadsPerDay: 0, maxLeads: 0, sitesPerRun: 1000,
      aiModes: ["api", "code", "manual"],
      rules: 0, lists: 0, views: 0, playbooks: 0, workspaces: 0, offerProfiles: 0,
      windowHours: 2, searchesPerWindow: 30,
      exportFormats: ["csv", "json", "txt"], activityDays: 0, devices: 5,
    },
    owner: {
      id: "owner", name: "Owner", rank: 9,
      modes: ALL_MODES,
      leadsPerDay: 0, maxLeads: 0, sitesPerRun: 0,
      aiModes: ["api", "code", "manual"],
      rules: 0, lists: 0, views: 0, playbooks: 0, workspaces: 0, offerProfiles: 0,
      windowHours: 2, searchesPerWindow: 0,
      exportFormats: ["csv", "json", "txt"], activityDays: 0, devices: 0,
    },
  };

  // Which plan a saved licence belongs to. The config maps Lemon Squeezy variant IDs to plans;
  // if a variant is not listed, the variant name ("Pro monthly") is used; anything unknown gets Starter.
  function planId(saved, config) {
    if (!config || !config.provider) return "owner";
    // Account mode: the plan comes from the Kestrel App. The free trial includes every Pro feature.
    if (config.provider === "kestrel") { const p = String((saved && saved.plan) || ""); return ["starter", "pro", "agency"].includes(p) ? p : "pro"; }
    if (!saved || !saved.key) return "starter";
    const map = config.tiers || {};
    for (const id of ["agency", "pro", "starter"]) if ((map[id] || []).map(Number).includes(Number(saved.variantId))) return id;
    const name = String(saved.plan || "").toLowerCase();
    if (/agency|team|business/.test(name)) return "agency";
    if (/\bpro\b|professional/.test(name)) return "pro";
    return "starter";
  }
  const get = (id) => PLANS[id] || PLANS.starter;

  // Smallest plan that has a feature, for "Upgrade to Pro" messages.
  function cheapestWith(test) {
    return ["starter", "pro", "agency"].map(get).find(test) || PLANS.agency;
  }
  const allows = (plan, list, value) => (plan[list] || []).includes(value);
  // true when `count` already uses the whole allowance (0 = unlimited).
  const full = (plan, key, count) => !!plan[key] && count >= plan[key];
  // The stricter of your own setting and the plan (0 = no limit on that side).
  const tighter = (mine, planned) => (!Number(planned) ? Number(mine) || 0 : !Number(mine) ? Number(planned) : Math.min(Number(mine), Number(planned)));

  const api = { PLANS, ALL_MODES, planId, get, cheapestWith, allows, full, tighter };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QuarryPlans = api;
})(globalThis);
