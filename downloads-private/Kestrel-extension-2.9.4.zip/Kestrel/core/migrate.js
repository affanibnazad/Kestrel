// Safe updates: data changes ("migrations") run once per workspace, after a backup, one at a time.
// Rules for adding a new version:
//  1. Never delete or rename a setting or lead field that users have. Add new ones with defaults (lib.js DEFAULTS).
//  2. If saved data must change shape, add a migration below with a new id. Never edit an old migration.
//  3. Add a What's New entry (core/changelog.js). The release builder refuses to build without it, and without passing tests.
(function (root) {
  const MIGRATIONS = [
    {
      id: "2026-11-sources",
      about: "Remember which sources found each lead, for the cross-source duplicate check",
      async run(DB) {
        const all = await DB.all(), changed = all.filter((l) => !Array.isArray(l.sources));
        changed.forEach((l) => { l.sources = [l.source].filter(Boolean); });
        if (changed.length) await DB.putMany(changed);
        return changed.length;
      },
    },
  ];

  // Runs the steps this workspace has not had yet. Only one page at a time (Web Locks), backup first.
  async function run() {
    const DB = root.QuarryDB, UI = root.QuarryUI;
    const work = async () => {
      const done = await DB.get("migrations", []);
      const todo = MIGRATIONS.filter((m) => !done.includes(m.id));
      if (!todo.length) return { ran: 0 };
      const count = (await DB.keys()).length;
      // A file backup only where the extension may still save files (older builds). From 2.9.0 the leads are kept in the App.
      if (count && chrome.downloads && UI && UI.saveFile) {
        try {
          const version = chrome.runtime.getManifest().version, data = await UI.buildBackup();
          await UI.saveFile(`kestrel/backups/kestrel_before_update_${version}.json`, JSON.stringify(data), "application/json", false, true);
          DB.log("update", `Backup saved before updating your data to ${version}`);
        } catch (_) { /* no backup possible; the update steps only add fields */ }
      }
      for (const m of todo) {
        try {
          const n = await m.run(DB);
          done.push(m.id);
          await DB.set("migrations", done);
          if (n) DB.log("update", `${m.about}: ${n} leads updated`);
        } catch (e) {
          // Stop at the first failure: later steps may depend on it. Your backup is in Downloads/kestrel/backups.
          DB.log("update", `Update step "${m.id}" failed: ${e.message}. Your data is unchanged after this step, and a backup was saved.`);
          return { ran: done.length, failed: m.id };
        }
      }
      return { ran: todo.length };
    };
    return navigator.locks ? navigator.locks.request("quarry-migrate", work) : work();
  }

  root.QuarryMigrate = { MIGRATIONS, run };
})(globalThis);
