// Kestrel core: pure logic shared by the console, workspace, page scripts and tests.
(function (root) {
  const EMAIL_RE = /[a-z0-9._+'-]+@[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,}/gi;
  const JUNK_DOMAINS = new Set(["example.com", "example.org", "domain.com", "yourdomain.com", "email.com",
    "sentry.io", "wixpress.com", "sentry.wixpress.com", "sentry-next.wixpress.com", "godaddy.com"]);
  const JUNK_END = /\.(png|jpe?g|gif|svg|webp|css|js|woff2?)$/i;
  const JUNK_LOCAL = /^(no-?reply|do-?not-?reply|postmaster|mailer-daemon|abuse|your-?(name|email)|name|email|user|privacy|dpo|gdpr|legal|compliance|dataprotection|data-protection|webmaster|unsubscribe)\b$|^[0-9a-f]{24,}$/i;
  const ROLE_LOCAL = /^(info|hello|hi|contact|sales|admin|office|support|enquir(y|ies)|inquir(y|ies)|team|mail|help|accounts?|billing|marketing|careers|jobs|press|media|reception|bookings?|studio|general|newbusiness|news|talk|talkto|design|creative|projects|work|people|hr|recruitment|events|orders|shop|store|services?|customers?|clients?|partners?|finance|tech|web|welcome|connect|ask|letstalk)\b/i;
  const FREE_MAIL = new Set(["gmail.com", "googlemail.com", "yahoo.com", "ymail.com", "hotmail.com", "outlook.com",
    "live.com", "msn.com", "icloud.com", "me.com", "aol.com", "proton.me", "protonmail.com", "gmx.com", "mail.com", "zoho.com"]);

  // Each network: display label, hosts, and paths that are shares or posts rather than a profile.
  const SOCIALS = {
    facebook: { label: "Facebook", color: "#0866FF", hosts: ["facebook.com", "fb.com", "fb.me"], not: /^\/(sharer|share|dialog|plugins|tr|login|photo|events\/\d|groups\/?$|watch|policies|help)/i },
    instagram: { label: "Instagram", color: "#E4405F", hosts: ["instagram.com"], not: /^\/(p|reel|reels|tv|explore|accounts|stories)\b/i },
    linkedin: { label: "LinkedIn", color: "#0A66C2", hosts: ["linkedin.com"], only: /^\/(company|in|school|showcase)\//i },
    x: { label: "X", color: "var(--label)", hosts: ["x.com", "twitter.com"], not: /^\/(intent|share|home|search|hashtag|i)\b|\/status\//i },
    youtube: { label: "YouTube", color: "#FF0000", hosts: ["youtube.com"], only: /^\/(channel\/|c\/|user\/|@)/i },
    tiktok: { label: "TikTok", color: "var(--label)", hosts: ["tiktok.com"], only: /^\/@[^/]+\/?$/i },
    pinterest: { label: "Pinterest", color: "#E60023", hosts: ["pinterest.com", "pinterest.ie", "pinterest.co.uk"], not: /^\/(pin|search|ideas)\b/i },
    whatsapp: { label: "WhatsApp", color: "#25D366", hosts: ["wa.me", "api.whatsapp.com", "chat.whatsapp.com"], not: /^\/?$/ },
    telegram: { label: "Telegram", color: "#26A5E4", hosts: ["t.me", "telegram.me"], not: /^\/(share|joinchat\/?$)/i },
    threads: { label: "Threads", color: "var(--label)", hosts: ["threads.net", "threads.com"], only: /^\/@/i },
    snapchat: { label: "Snapchat", color: "var(--yellow)", hosts: ["snapchat.com"], only: /^\/add\//i },
    vimeo: { label: "Vimeo", color: "#1AB7EA", hosts: ["vimeo.com"], not: /^\/(\d+|channels\/?$|ondemand|upgrade|join|log_in)\b/i },
    behance: { label: "Behance", color: "#1769FF", hosts: ["behance.net"], not: /^\/(gallery|search|joblist)\b/i },
    dribbble: { label: "Dribbble", color: "#EA4C89", hosts: ["dribbble.com"], not: /^\/(shots|search|tags|jobs)\b/i },
    github: { label: "GitHub", color: "var(--label)", hosts: ["github.com"], not: /^\/(features|login|join|pricing|sponsors|marketplace)\b/i },
    discord: { label: "Discord", color: "#5865F2", hosts: ["discord.gg", "discord.com"], not: /^\/(channels|developers|download|login|register)\b/i },
    reddit: { label: "Reddit", color: "#FF4500", hosts: ["reddit.com"], only: /^\/(r|user|u)\//i },
  };
  const SOCIAL_KEYS = Object.keys(SOCIALS);
  const HOST_TO_SOCIAL = {};
  SOCIAL_KEYS.forEach((k) => SOCIALS[k].hosts.forEach((h) => { HOST_TO_SOCIAL[h] = k; }));
  const SOCIAL_SCAN_RE = new RegExp("https?:(?:\\\\?/){2}(?:[a-z0-9-]+\\.)*(?:" +
    Object.keys(HOST_TO_SOCIAL).map((h) => h.replace(/\./g, "\\.")).join("|") + ")(?:\\\\?/[^\\s\"'<>)\\]]*)?", "gi");

  const DEFAULTS = {
    version: 2,
    mode: "maps",
    targets: { keywords: "", locations: "", sKeywords: "", sLocations: "", site: "instagram.com", customSite: "", emailHint: false, sites: "",
      source: { maps: "library", search: "library", osm: "library" },
      pick: { maps: { keywords: [], places: [], country: "" }, search: { keywords: [], places: [], country: "" }, osm: { keywords: [], places: [], country: "" } },
      youtube: { source: "niches", list: "", terms: [], countries: [], addWord: true, matchCountry: true, keepUnknown: false, minSubs: 1000, maxSubs: 500000, minVideos: 10, pages: 3 } },
    limits: { delaySec: 45, maxPerSearch: 120, maxPerRun: 0, maxPerDay: 300, maxSearches: 15, breakEvery: 5, breakMin: 10,
      maxRunMin: 90, scrollRounds: 40, sitePages: 3, siteWorkers: 4, siteTimeout: 8, failStop: 2 },
    safety: { level: "safe", jitter: true, blockSignedIn: true, respectRobots: true, cooldownHours: 12, daily: { maps: 60, search: 30, youtube: 40, ytChannels: 400, osm: 100, jobs: 500, companies: 1000, podcasts: 50 } },
    osm: { server: "" },
    jobs: { from: "leads", scope: "good", max: 100, boards: "", words: "" },
    companies: { types: ["0"], customTypes: [], towns: [], customTowns: [], max: 100, officers: true, hunter: false },
    podcasts: { method: "best", genre: "97", q: "", region: "gb", pages: 2 },
    refine: { minRating: 0, minReviews: 0, maxReviews: 0, needWebsite: false, needEmail: false, needPhone: false, needSocial: false,
      includeWords: "", excludeWords: "", businessEmailOnly: false,
      minQuality: 0, minSocials: 0, minChannels: 0, needDescription: false, needAddress: false, emailMatchesSite: false, rules: [] },
    page: { scrolls: 0, nextPages: 0, visitSites: false },
    weights: { email: 30, website: 10, phone: 5, social: 12, rating: 8, reviews: 10, description: 5, fit: 10, reach: 10 },
    tiers: { a: 70, b: 45 },
    backup: { auto: true },
    ai: { offer: "", customer: "", good: "", bad: "", criteria: "", strictness: "balanced", model: "claude-opus-5-5", capNoFit: true, workers: 4, mode: "api", provider: "anthropic", models: {}, prices: {}, baseUrl: "" },
  };

  const parseLines = (t) => [...new Set(String(t || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean))];
  const hostOf = (u) => { try { return new URL(u).hostname.toLowerCase().replace(/^www\./, ""); } catch (_) { return ""; } };

  const buildMapsUrl = (q) => `https://www.google.com/maps/search/${encodeURIComponent(q).replace(/%20/g, "+")}?hl=en`;
  const buildSearchUrl = (q) => `https://www.google.com/search?q=${encodeURIComponent(q)}&hl=en`;

  // ---- safety: pacing presets, daily caps and pauses that protect your Google account and IP
  const SAFETY_PRESETS = {
    safe: { limits: { delaySec: 45, maxSearches: 15, breakEvery: 5, breakMin: 10, maxRunMin: 90, maxPerDay: 300, failStop: 2, siteWorkers: 4, scrollRounds: 40 },
      daily: { maps: 60, search: 30, youtube: 40, ytChannels: 400, osm: 100, jobs: 500, companies: 1000, podcasts: 50 }, cooldownHours: 12 },
    balanced: { limits: { delaySec: 25, maxSearches: 30, breakEvery: 8, breakMin: 6, maxRunMin: 150, maxPerDay: 500, failStop: 3, siteWorkers: 6, scrollRounds: 60 },
      daily: { maps: 120, search: 60, youtube: 80, ytChannels: 800, osm: 200, jobs: 1000, companies: 2000, podcasts: 100 }, cooldownHours: 6 },
  };
  function applySafety(cfg, level) {
    const preset = SAFETY_PRESETS[level];
    cfg.safety.level = level;
    if (!preset) return cfg;
    Object.assign(cfg.limits, preset.limits);
    cfg.safety.daily = { ...preset.daily };
    cfg.safety.cooldownHours = preset.cooldownHours;
    return cfg;
  }
  // Wait between searches: the set delay, varied between 70% and 150% when jitter is on.
  const pace = (delaySec, jitter, rnd = Math.random) => Math.round(Number(delaySec) * 1000 * (jitter ? 0.7 + rnd() * 0.8 : 1));
  const todayKey = (now = new Date()) => `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  function usageToday(usage, now) {
    const day = todayKey(now);
    return usage && usage.date === day ? usage : { date: day, maps: 0, search: 0, youtube: 0, ytChannels: 0 };
  }
  // Returns why this source may not search now, or "".
  function safetyBlock(source, usage, cooldown, safety, now = Date.now()) {
    const until = cooldown && cooldown[source];
    if (until && until > now) return `paused until ${new Date(until).toLocaleString(undefined, { weekday: "short", hour: "2-digit", minute: "2-digit" })} because ${source === "youtube" ? "YouTube" : "Google"} showed a check`;
    const cap = Number((safety.daily || {})[source]) || 0;
    if (cap && (usage[source] || 0) >= cap) return `daily safety limit of ${cap} ${({ youtube: "YouTube", maps: "Maps", osm: "OpenStreetMap", jobs: "job board", companies: "Companies House", podcasts: "Listen Notes" })[source] || "Google"} searches reached. Continue tomorrow`;
    return "";
  }
  // Internal network addresses are never visited from scraped data.
  function isPrivateHost(host) {
    const h = String(host || "").toLowerCase().replace(/^\[|\]$/g, "");
    if (!h || h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost")) return true;
    if (h === "::1" || h.startsWith("fe80:") || h.startsWith("fc") || h.startsWith("fd")) return /:/.test(h);
    const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
    if (!m) return false;
    const [a, b] = [Number(m[1]), Number(m[2])];
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }

  // Progress tracking. One key per search: mode, site (search only), keyword and full location.
  const shortPlace = (location) => String(location || "").split(",")[0].trim();
  const coverKey = (mode, keyword, location, site) => [mode, mode === "search" ? site || "" : "", keyword, location].join("|").toLowerCase();
  const isDone = (coverage, key) => !!(coverage && coverage[key] && coverage[key].status === "done");

  function mapsQueue(keywords, locations, done, coverage) {
    const skip = new Set(done || []), out = [];
    for (const location of locations) for (const keyword of keywords) {
      const query = `${keyword} in ${location}`;
      const key = coverKey("maps", keyword, location);
      if (!skip.has(query) && !isDone(coverage, key)) out.push({ query, keyword, location, key });
    }
    return out;
  }

  function searchQuery(site, keyword, location, emailHint) {
    const place = location.includes(",") ? shortPlace(location) : location;
    return `site:${site} "${keyword}"${place ? ` "${place}"` : ""}${emailHint ? ' "@gmail.com"' : ""}`;
  }

  function searchQueue(keywords, locations, site, emailHint, done, coverage) {
    const skip = new Set(done || []), out = [];
    for (const location of locations.length ? locations : [""]) for (const keyword of keywords) {
      const query = searchQuery(site, keyword, location, emailHint);
      const key = coverKey("search", keyword, location, site);
      if (!skip.has(query) && !isDone(coverage, key)) out.push({ query, keyword, location, site, key });
    }
    return out;
  }

  // Counts how much of a keyword x place grid is finished.
  function coverageStats(mode, keywords, places, coverage, site) {
    const perPlace = {}, perKeyword = {};
    let done = 0, partial = 0;
    for (const place of places) perPlace[place] = { done: 0, partial: 0, total: keywords.length, last: 0, saved: 0 };
    for (const keyword of keywords) perKeyword[keyword] = { done: 0, partial: 0, total: places.length, saved: 0 };
    for (const place of places) for (const keyword of keywords) {
      const c = coverage && coverage[coverKey(mode, keyword, place, site)];
      if (!c) continue;
      const p = perPlace[place], k = perKeyword[keyword];
      if (c.status === "done") { done++; p.done++; k.done++; } else { partial++; p.partial++; k.partial++; }
      p.saved += c.saved || 0;
      k.saved += c.saved || 0;
      p.last = Math.max(p.last, c.at || 0);
    }
    return { total: keywords.length * places.length, done, partial, perPlace, perKeyword };
  }

  const placeState = (p) => (p.total && p.done >= p.total ? "done" : p.done || p.partial ? "partial" : "none");

  // Turns the old "done" lists into progress records, so earlier runs still count.
  function migrateCoverage(doneMaps, doneSearch) {
    const out = {};
    for (const q of doneMaps || []) {
      const at = q.indexOf(" in ");
      if (at > 0) out[coverKey("maps", q.slice(0, at), q.slice(at + 4))] = { status: "done", at: 0, saved: 0 };
    }
    for (const q of doneSearch || []) {
      const m = /^site:(\S+) "([^"]+)"(?: "([^"]+)")?/.exec(q);
      if (m) out[coverKey("search", m[2], m[3] && !m[3].includes("@") ? m[3] : "", m[1])] = { status: "done", at: 0, saved: 0 };
    }
    return out;
  }

  // ---- importing your own keywords and locations
  const titleCase = (t) => (t ? t[0].toUpperCase() + t.slice(1) : t);
  function nameFromFile(fileName, fallback) {
    const base = String(fileName || "").replace(/\.[^.]+$/, "").replace(/^\d+[\s._-]*/, "").replace(/[_-]+/g, " ").trim();
    return titleCase(base) || fallback;
  }
  const cleanLine = (l) => String(l === undefined || l === null ? "" : l).replace(/^\uFEFF/, "").replace(/^\s*(?:[-*\u2022]|\d+[.)])\s+/, "").replace(/\s+/g, " ").trim();
  const firstCells = (source) => (source.split(/\r?\n/, 1)[0] || "").split(/[,;\t]/).map((c) => c.trim().replace(/^"|"$/g, "").toLowerCase().replace(/[^a-z]/g, ""));
  function headerCol(headers, words) {
    return headers.find((h) => words.some((w) => h.toLowerCase().replace(/[^a-z]/g, "") === w));
  }

  // Keywords: plain lines, or a CSV with a Keyword column and an optional Group column.
  function parseKeywordImport(text, fileName) {
    const source = String(text || "").replace(/^\uFEFF/, "");
    const fallback = nameFromFile(fileName, "Imported keywords");
    const groups = new Map();
    const add = (group, kw) => {
      kw = cleanLine(kw);
      if (!kw || kw.length > 80) return;
      const g = groups.get(group) || groups.set(group, []).get(group);
      if (!g.some((x) => x.toLowerCase() === kw.toLowerCase())) g.push(kw);
    };
    const kHead = firstCells(source);
    if (kHead.length > 1 && kHead.some((c) => ["keyword", "keywords", "searchterm", "term"].includes(c))) {
      const { headers, rows } = parseCsv(source);
      const kc = headerCol(headers, ["keyword", "keywords", "searchterm", "term"]);
      const gc = headerCol(headers, ["group", "category", "list", "niche"]);
      rows.forEach((r) => add(cleanLine(gc && r[gc]) || fallback, r[kc]));
    } else {
      source.split(/\r?\n/).slice(kHead.length === 1 && ["keyword", "keywords", "searchterm"].includes(kHead[0]) ? 1 : 0).forEach((l) => add(fallback, l));
    }
    return { keywordGroups: [...groups].map(([name, items]) => ({ name, items, custom: true })).filter((g) => g.items.length), countries: [] };
  }

  // Locations: plain lines like "Cork, Ireland", or a CSV with Country, Area and Location columns.
  function parseLocationImport(text, fileName) {
    const source = String(text || "").replace(/^\uFEFF/, "");
    const fallbackArea = nameFromFile(fileName, "Imported");
    const countries = new Map();
    const add = (place, country, area) => {
      place = cleanLine(place);
      if (!place || place.length > 120) return;
      const parts = place.split(",").map((x) => x.trim()).filter(Boolean);
      country = cleanLine(country) || (parts.length > 1 ? parts[parts.length - 1] : "Other");
      if (parts.length === 1 && country !== "Other") place = `${place}, ${country}`;
      area = cleanLine(area) || (parts.length > 2 ? parts[parts.length - 2] : fallbackArea);
      const areas = countries.get(country) || countries.set(country, new Map()).get(country);
      const list = areas.get(area) || areas.set(area, []).get(area);
      if (!list.includes(place)) list.push(place);
    };
    const lHead = firstCells(source), LOC_WORDS = ["searchlocation", "location", "locations", "place", "places", "city", "town"];
    if (lHead.length > 1 && lHead.some((c) => LOC_WORDS.includes(c))) {
      const { headers, rows } = parseCsv(source);
      const pc = headerCol(headers, ["searchlocation", "location", "locations", "place", "city", "town"]);
      const cc = headerCol(headers, ["country"]);
      const ac = headerCol(headers, ["area", "region", "state", "county", "province"]);
      rows.forEach((r) => add(r[pc], cc && r[cc], ac && r[ac]));
    } else {
      source.split(/\r?\n/).slice(lHead.length === 1 && LOC_WORDS.includes(lHead[0]) ? 1 : 0).forEach((l) => add(l));
    }
    return { keywordGroups: [], countries: [...countries].map(([name, areas]) => ({ name, custom: true, areas: [...areas].map(([a, places]) => ({ name: a, places })) })) };
  }

  // Adds library b on top of library a. Same group, country or area names are joined.
  function mergeLibrary(a, b) {
    const out = { keywordGroups: [], countries: [] };
    const addGroup = (g) => {
      const hit = out.keywordGroups.find((x) => x.name.toLowerCase() === g.name.toLowerCase());
      if (!hit) { out.keywordGroups.push({ ...g, items: [...g.items] }); return; }
      g.items.forEach((k) => { if (!hit.items.some((x) => x.toLowerCase() === k.toLowerCase())) hit.items.push(k); });
      hit.custom = hit.custom || g.custom;
    };
    const addCountry = (c) => {
      let hit = out.countries.find((x) => x.name.toLowerCase() === c.name.toLowerCase());
      if (!hit) { hit = { name: c.name, custom: !!c.custom, areas: [] }; out.countries.push(hit); }
      hit.custom = hit.custom || !!c.custom;
      const seen = new Set(hit.areas.flatMap((x) => x.places));
      c.areas.forEach((ar) => {
        let area = hit.areas.find((x) => x.name.toLowerCase() === ar.name.toLowerCase());
        if (!area) { area = { name: ar.name, places: [] }; hit.areas.push(area); }
        ar.places.forEach((p) => { if (!seen.has(p)) { seen.add(p); area.places.push(p); } });
      });
      hit.areas = hit.areas.filter((x) => x.places.length);
    };
    [a, b].forEach((lib) => { ((lib && lib.keywordGroups) || []).forEach(addGroup); ((lib && lib.countries) || []).forEach(addCountry); });
    const yt = (a && a.youtube) || (b && b.youtube) || { niches: [], countries: [] };
    const niches = yt.niches.map((n) => ({ ...n, terms: [...n.terms] }));
    [a, b].forEach((lib) => ((lib && lib.ytNiches) || []).forEach((n) => {
      const hit = niches.find((x) => x.name.toLowerCase() === n.name.toLowerCase());
      if (!hit) niches.push({ name: n.name, terms: [...n.terms], custom: true });
      else n.terms.forEach((t) => { if (!hit.terms.includes(t)) hit.terms.push(t); });
    }));
    out.youtube = { ...yt, niches };
    out.ytNiches = [...((a && a.ytNiches) || []), ...((b && b.ytNiches) || [])].reduce((acc, n) => {
      const hit = acc.find((x) => x.name === n.name);
      if (hit) n.terms.forEach((t) => { if (!hit.terms.includes(t)) hit.terms.push(t); }); else acc.push({ name: n.name, terms: [...n.terms] });
      return acc;
    }, []);
    out.countries = out.countries.filter((c) => c.areas.length);
    return out;
  }

  function libraryCounts(lib) {
    return { groups: ((lib && lib.keywordGroups) || []).length, keywords: allKeywords(lib).length, countries: ((lib && lib.countries) || []).length,
      places: ((lib && lib.countries) || []).reduce((n, c) => n + allPlaces(c).length, 0) };
  }

  // ---- YouTube: channel search pages and channel About pages, read from YouTube's page data.
  const YT_CHANNEL_FILTER = "EgIQAg%3D%3D";
  const ANY_COUNTRY = "Any country";
  const ytSearchUrl = (q, gl) => `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}&sp=${YT_CHANNEL_FILTER}&hl=en${gl ? `&gl=${gl}` : ""}`;
  function ytInitialData(html) {
    const marker = "var ytInitialData = ";
    const at = String(html || "").indexOf(marker);
    if (at < 0) return null;
    const end = html.indexOf(";</script>", at);
    try { return JSON.parse(html.slice(at + marker.length, end)); } catch (_) { return null; }
  }
  const ytConfig = (html) => ({ key: (String(html).match(/"INNERTUBE_API_KEY":"([^"]+)"/) || [])[1] || "", version: (String(html).match(/"INNERTUBE_CLIENT_VERSION":"([^"]+)"/) || [])[1] || "" });
  function ytFind(o, key, out = []) {
    if (o && typeof o === "object") { if (o[key] !== undefined) out.push(o[key]); for (const v of Object.values(o)) ytFind(v, key, out); }
    return out;
  }
  const ytText = (t) => (!t ? "" : typeof t === "string" ? t : t.simpleText || t.content || (t.runs || []).map((r) => r.text).join("")).trim();
  function parseCount(text) {
    const m = String(text || "").replace(/,/g, "").match(/([\d.]+)\s*([KMB])?/i);
    if (!m) return 0;
    return Math.round(Number(m[1]) * ({ K: 1e3, M: 1e6, B: 1e9 }[(m[2] || "").toUpperCase()] || 1));
  }
  function ytChannels(data) {
    const channels = ytFind(data, "channelRenderer").map((c) => {
      const base = (c.navigationEndpoint && c.navigationEndpoint.browseEndpoint && c.navigationEndpoint.browseEndpoint.canonicalBaseUrl) || `/channel/${c.channelId}`;
      const texts = [c.subscriberCountText, c.videoCountText].map(ytText);
      return { id: c.channelId, name: ytText(c.title), path: base, url: `https://www.youtube.com${base}`,
        subs: parseCount(texts.find((t) => /subscriber/i.test(t))), videos: parseCount(texts.find((t) => /video/i.test(t))), snippet: ytText(c.descriptionSnippet) };
    }).filter((c) => c.id && c.name);
    // The results "next page" token sits in a continuationItemRenderer; other tokens belong to filter chips.
    const own = ytFind(data, "continuationItemRenderer").map((c) => ((c.continuationEndpoint || {}).continuationCommand || {}).token).filter(Boolean);
    const any = ytFind(data, "continuationCommand").map((c) => c.token).filter(Boolean);
    return { channels, token: own[0] || any[0] || "" };
  }
  function ytLinkUrl(link) {
    const run = ((link.link || {}).commandRuns || [])[0];
    const raw = run && run.onTap && run.onTap.innertubeCommand && run.onTap.innertubeCommand.urlEndpoint ? run.onTap.innertubeCommand.urlEndpoint.url : "";
    try {
      const u = new URL(raw);
      if (u.hostname.endsWith("youtube.com") && u.pathname === "/redirect") return u.searchParams.get("q") || "";
      if (raw) return raw;
    } catch (_) { /* fall back to the visible text */ }
    const text = ytText(link.link);
    return text && !/\s/.test(text) ? `https://${text.replace(/^https?:\/\//, "")}` : "";
  }
  function ytAbout(data) {
    const vm = ytFind(data, "aboutChannelViewModel")[0];
    if (!vm) return null;
    const meta = ytFind(data, "channelMetadataRenderer")[0] || {};
    return { name: meta.title || "", id: meta.externalId || vm.channelId || "", description: ytText(vm.description), country: ytText(vm.country), subs: parseCount(ytText(vm.subscriberCountText)), views: parseCount(ytText(vm.viewCountText)),
      videos: parseCount(ytText(vm.videoCountText)), joined: ytText(vm.joinedDateText).replace(/^Joined\s*/i, ""),
      hiddenEmail: !!vm.signInForBusinessEmail, links: (vm.links || []).map((l) => ytLinkUrl(l.channelExternalLinkViewModel || {})).filter(Boolean) };
  }
  // Turns pasted channel links, @handles or channel IDs into YouTube paths like "/@name".
  function parseChannelInput(text) {
    const out = [];
    for (const raw of String(text || "").split(/[\r\n,;\t ]+/)) {
      let line = raw.trim().replace(/^<|>$/g, "");
      if (!line) continue;
      let path = "";
      if (/^@[\w.\-]{2,}$/.test(line)) path = `/${line}`;
      else if (/^UC[\w-]{22}$/.test(line)) path = `/channel/${line}`;
      else {
        if (!/^https?:\/\//i.test(line) && /youtube\.com\//i.test(line)) line = `https://${line}`;
        try {
          const u = new URL(line);
          if (!/(^|\.)youtube\.com$/i.test(u.hostname)) continue;
          const m = u.pathname.match(/^\/(@[^/?#]+|channel\/UC[\w-]+|c\/[^/?#]+|user\/[^/?#]+)/);
          if (m) path = `/${decodeURIComponent(m[1])}`;
        } catch (_) { continue; }
      }
      if (path && !out.some((p) => p.toLowerCase() === path.toLowerCase())) out.push(path);
    }
    return out;
  }

  function ytQueue(terms, countries, addWord, coverage) {
    const out = [];
    for (const c of countries.length ? countries : [null]) for (const term of terms) {
      const country = c ? c.name : ANY_COUNTRY;
      const query = c && addWord ? `${term} ${c.word || c.name}` : term;
      const key = coverKey("youtube", term, country);
      if (!isDone(coverage, key)) out.push({ query, keyword: term, location: country, gl: c ? c.code : "", key });
    }
    return out;
  }
  // Returns why a channel does not fit, or "".
  function ytCheck(ch, target, opt) {
    if (opt.minSubs && ch.subs < Number(opt.minSubs)) return "too few subscribers";
    if (opt.maxSubs && ch.subs > Number(opt.maxSubs)) return "too many subscribers";
    if (opt.minVideos && ch.videos < Number(opt.minVideos)) return "too few videos";
    if (opt.matchCountry && target && target !== ANY_COUNTRY) {
      if (!ch.country) return opt.keepUnknown ? "" : "no country listed";
      if (ch.country.toLowerCase() !== target.toLowerCase()) return "other country";
    }
    return "";
  }
  const shortCount = (n) => (n >= 1e6 ? `${(n / 1e6).toFixed(n >= 1e7 ? 0 : 1)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(n >= 1e4 ? 0 : 1)}K` : String(n || 0)).replace(".0", "");

  // Library helpers: places for a country and its areas.
  const libCountry = (lib, name) => ((lib && lib.countries) || []).find((c) => c.name === name);
  const allPlaces = (country) => (country ? country.areas.flatMap((a) => a.places) : []);
  const allKeywords = (lib) => [...new Set(((lib && lib.keywordGroups) || []).flatMap((g) => g.items))];
  function areaOfPlace(lib) {
    const out = {};
    ((lib && lib.countries) || []).forEach((c) => c.areas.forEach((a) => a.places.forEach((p) => { out[p] = { country: c.name, area: a.name }; })));
    return out;
  }

  function normalizeSiteInput(line) {
    const first = String(line).split(/[\s,;]+/).find((p) => /\w\.\w/.test(p) && !p.includes("@"));
    if (!first) return "";
    try {
      const url = new URL(/^https?:\/\//i.test(first) ? first : `https://${first}`);
      return /^https?:$/.test(url.protocol) && url.hostname.includes(".") ? url.href : "";
    } catch (_) { return ""; }
  }

  function isJunkEmail(email) {
    const [local, domain] = email.split("@");
    return JUNK_DOMAINS.has(domain) || JUNK_END.test(email) || JUNK_LOCAL.test(local);
  }

  function findEmails(text) {
    const cleaned = String(text || "").replace(/%20|mailto:/gi, " ").replace(/\bu003[ce]/gi, " ");
    const found = (cleaned.match(EMAIL_RE) || []).map((e) => e.toLowerCase().replace(/^[.'-]+|[.'-]+$/g, ""));
    return [...new Set(found)].filter((e) => !isJunkEmail(e));
  }

  function findPhones(text) {
    const found = String(text || "").match(/\+\d[\d\s().-]{7,17}\d/g) || [];
    return [...new Set(found.map((p) => p.replace(/\s+/g, " ").trim()))];
  }

  function cleanWebsite(url) {
    try {
      const parsed = new URL(url);
      if (parsed.hostname.endsWith("google.com") && parsed.pathname === "/url") {
        return cleanWebsite(parsed.searchParams.get("q") || parsed.searchParams.get("url") || "");
      }
      [...parsed.searchParams.keys()].filter((k) => /^utm_|^gclid$|^fbclid$|^msclkid$/i.test(k)).forEach((k) => parsed.searchParams.delete(k));
      return /^https?:$/.test(parsed.protocol) ? parsed.href : "";
    } catch (_) { return ""; }
  }

  function socialFromUrl(raw) {
    let parsed;
    try { parsed = new URL(String(raw).replace(/\\\//g, "/").replace(/[.,;]+$/, "")); } catch (_) { return null; }
    const host = parsed.hostname.toLowerCase().replace(/^(www|m|mobile|web|[a-z]{2})\./, "");
    const key = HOST_TO_SOCIAL[host] || HOST_TO_SOCIAL[parsed.hostname.toLowerCase().replace(/^www\./, "")];
    if (!key) return null;
    const rule = SOCIALS[key];
    const path = parsed.pathname;
    if (path === "/" && key !== "whatsapp") return null;
    if (rule.only && !rule.only.test(path)) return null;
    if (rule.not && rule.not.test(path)) return null;
    if (key === "whatsapp" && host === "api.whatsapp.com" && !parsed.searchParams.get("phone")) return null;
    const keepQuery = key === "whatsapp" || (key === "facebook" && path.startsWith("/profile.php"));
    return { key, url: `${parsed.origin}${path.replace(/\/$/, "")}${keepQuery ? parsed.search : ""}` };
  }

  function findSocials(text) {
    const socials = {};
    for (const match of String(text || "").match(SOCIAL_SCAN_RE) || []) {
      const hit = socialFromUrl(match);
      if (hit && !socials[hit.key]) socials[hit.key] = hit.url;
    }
    return socials;
  }

  function decodeCloudflare(hex) {
    const key = parseInt(hex.slice(0, 2), 16);
    let out = "";
    for (let i = 2; i < hex.length; i += 2) out += String.fromCharCode(parseInt(hex.slice(i, i + 2), 16) ^ key);
    return out;
  }

  // One pass, so "&amp;lt;" becomes "&lt;" and is not decoded twice. Handles &#39; &#x27; &hellip; and similar.
  const NAMED = { amp: "&", quot: '"', apos: "'", lt: "<", gt: ">", nbsp: " ", hellip: "\u2026", ndash: "\u2013", mdash: "\u2014", lsquo: "\u2018", rsquo: "\u2019", ldquo: "\u201C", rdquo: "\u201D", bull: "\u2022", middot: "\u00B7", copy: "\u00A9", reg: "\u00AE", trade: "\u2122", pound: "\u00A3", euro: "\u20AC" };
  function unescapeHtml(t) {
    return String(t === undefined || t === null ? "" : t).replace(/&(#x[0-9a-f]{1,6}|#\d{1,7}|[a-z]{2,8});/gi, (all, code) => {
      if (code[0] === "#") {
        const n = code[1] === "x" || code[1] === "X" ? parseInt(code.slice(2), 16) : parseInt(code.slice(1), 10);
        return n > 0 && n <= 0x10ffff && !(n >= 0xd800 && n <= 0xdfff) ? String.fromCodePoint(n) : all;
      }
      const hit = NAMED[code.toLowerCase()];
      return hit === undefined ? all : hit;
    });
  }
  // Cleans scraped text already saved: decodes leftovers like &#x27; and squeezes spaces. Returns true if it changed anything.
  function cleanLeadText(lead) {
    let changed = false;
    for (const f of ["name", "category", "address", "description"]) {
      const v = lead[f];
      if (typeof v !== "string" || !v.includes("&")) continue;
      const next = unescapeHtml(v).replace(/[ \t]{2,}/g, " ").trim();
      if (next !== v) { lead[f] = next; changed = true; }
    }
    return changed;
  }

  // The business's own address from the website's structured data (schema.org PostalAddress in JSON-LD or microdata),
  // so a lead found in a search for Topeka but based in Pittsburgh shows Pittsburgh (UX audit row 10). JSON-LD is read
  // with JSON.parse (data only, nothing runs). Only structured data counts: free text is too easy to misread.
  const ADDR_TEXT = (v) => (typeof v === "string" ? unescapeHtml(v).replace(/\s+/g, " ").trim().slice(0, 120)
    : v && typeof v === "object" && typeof v.name === "string" ? unescapeHtml(v.name).trim().slice(0, 120) : "");
  function siteAddress(html) {
    const found = [];
    const visit = (node, depth) => {
      if (!node || typeof node !== "object" || depth > 8 || found.length > 20) return;
      if (Array.isArray(node)) { node.forEach((n) => visit(n, depth + 1)); return; }
      const type = [].concat(node["@type"] || []).join(" ");
      if (/PostalAddress/i.test(type) || node.addressLocality) found.push(node);
      for (const [k, v] of Object.entries(node)) if (k !== "addressLocality" && v && typeof v === "object") visit(v, depth + 1);
    };
    for (const m of String(html || "").matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
      try { visit(JSON.parse(m[1].trim()), 0); } catch (_) { /* broken JSON-LD: skip it */ }
    }
    const micro = (prop) => { const r = String(html || "").match(new RegExp(`itemprop=["']${prop}["'][^>]*>([^<]{1,120})<`, "i")) || String(html || "").match(new RegExp(`itemprop=["']${prop}["'][^>]*content=["']([^"']{1,120})`, "i")); return r ? r[1] : ""; };
    if (!found.length && micro("addressLocality")) found.push({ streetAddress: micro("streetAddress"), addressLocality: micro("addressLocality"), addressRegion: micro("addressRegion"), postalCode: micro("postalCode"), addressCountry: micro("addressCountry") });
    for (const a of found) {
      const city = ADDR_TEXT(a.addressLocality);
      if (!city || /^\d+$/.test(city) || /[{}<>]|^(city|town|locality)$|\byour\b|city name|^(n\/a|none|null|undefined|-)$/i.test(city)) continue;
      const place = { street: ADDR_TEXT(a.streetAddress), city, region: ADDR_TEXT(a.addressRegion), postcode: ADDR_TEXT(a.postalCode), country: ADDR_TEXT(a.addressCountry) };
      place.text = [place.street, place.city, [place.region, place.postcode].filter(Boolean).join(" "), place.country].filter(Boolean).join(", ");
      return place;
    }
    return null;
  }

  // The real city on the lead, from its website (enrich in ui/console.js). `location` stays the search location: the
  // App's duplicate key and coverage use it. Returns true when the lead changed.
  function applySiteAddress(lead, place) {
    if (!lead || !place || !place.city) return false;
    const before = `${lead.city}|${lead.address}`;
    lead.city = place.region ? `${place.city}, ${place.region}` : place.city;
    lead.cityFrom = "website";
    if (!lead.address) lead.address = place.text;
    return before !== `${lead.city}|${lead.address}`;
  }

  // Reads HTML as plain text; a scraped page's code never runs.
  function parseSite(html, pageUrl) {
    const source = String(html || "");
    const noComments = source.replace(/<!--[\s\S]*?-->/g, " ");
    const cf = [...noComments.matchAll(/data-cfemail="([0-9a-f]+)"/gi)].map((m) => decodeCloudflare(m[1])).join(" ");
    const visible = noComments.replace(/<(script|style)[\s\S]*?<\/\1>/gi, " ");
    const mailtos = [...noComments.matchAll(/href=["']mailto:([^"'?]+)/gi)].map((m) => { try { return decodeURIComponent(m[1]); } catch (_) { return m[1]; } }).join(" ");
    const emails = findEmails([mailtos, cf, unescapeHtml(visible)].join(" "));
    const phones = [...new Set([...noComments.matchAll(/href=["']tel:([^"']+)/gi)].map((m) => { try { return decodeURIComponent(m[1]).trim(); } catch (_) { return m[1]; } }))];

    const contact = new Set();
    const siteHost = hostOf(pageUrl);
    for (const m of noComments.matchAll(/<a\b[^>]*href=["']([^"'#]+)/gi)) {
      try {
        const absolute = new URL(unescapeHtml(m[1]), pageUrl);
        if (hostOf(absolute.href) === siteHost && /contact|about|team|impressum|reach/i.test(absolute.pathname)) contact.add(absolute.href);
      } catch (_) { /* not a usable link */ }
    }
    const meta = noComments.match(/<meta\b[^>]*name=["']description["'][^>]*>/i) || noComments.match(/<meta\b[^>]*property=["']og:description["'][^>]*>/i);
    const content = meta && meta[0].match(/content=["']([^"']*)/i);
    const title = noComments.match(/<title[^>]*>([^<]*)/i);
    return { emails, phones, socials: findSocials(source), contactLinks: [...contact],
      description: content ? unescapeHtml(content[1]).trim() : "", title: title ? unescapeHtml(title[1]).trim() : "", place: siteAddress(source) };
  }

  function emailKind(email, website) {
    if (!email) return "none";
    const [local, domain] = email.split("@");
    if (FREE_MAIL.has(domain)) return "free";
    const site = hostOf(website);
    const onDomain = site && (domain === site || site.endsWith(`.${domain}`) || domain.endsWith(`.${site}`));
    if (!onDomain && site) return "other";
    return ROLE_LOCAL.test(local) ? "role" : "person";
  }

  const EMAIL_RANK = { person: 0, role: 1, other: 2, free: 3, none: 4 };
  const EMAIL_LABEL = { person: "Named", role: "Role", other: "Other domain", free: "Free mail", none: "" };

  function rankEmails(emails, website) {
    return [...emails].sort((a, b) => EMAIL_RANK[emailKind(a, website)] - EMAIL_RANK[emailKind(b, website)]);
  }

  function setEmails(lead, emails) {
    lead.emails = rankEmails([...new Set(emails)], lead.website);
    lead.email = lead.emails[0] || "";
    lead.emailKind = emailKind(lead.email, lead.website);
  }

  function dataQuality(lead) {
    const fields = lead.source === "youtube"
      ? [lead.email, lead.website, lead.description, Object.keys(lead.socials || {}).length > 1, lead.subscribers, lead.country]
      : [lead.email, lead.phone, lead.website, lead.address, lead.description, Object.keys(lead.socials || {}).length, lead.rating];
    return Math.round((fields.filter(Boolean).length / fields.length) * 100);
  }


  const RULE_FIELDS = [
    ["name", "Business name", "text"], ["category", "Category", "text"], ["description", "Description", "text"], ["address", "Address", "text"],
    ["location", "Search location", "text"], ["website", "Website", "text"], ["email", "Email", "text"], ["emailKind", "Email type", "text"], ["phone", "Phone", "text"],
    ["keyword", "Search keyword", "text"], ["rating", "Rating", "number"], ["reviews", "Reviews", "number"], ["socialCount", "Social profiles", "number"],
    ["quality", "Data quality", "number"],
    ["subscribers", "YouTube subscribers", "number"], ["videos", "YouTube videos", "number"], ["country", "Channel country", "text"],
    ...SOCIAL_KEYS.map((k) => [`social:${k}`, SOCIALS[k].label, "text"]),
  ];
  const RULE_OPS = [["contains", "contains"], ["notContains", "doesn't contain"], ["is", "is"], ["empty", "is empty"], ["notEmpty", "has a value"], ["gt", "above"], ["lt", "below"]];
  const NO_VALUE = new Set(["empty", "notEmpty"]);

  function ruleValue(lead, field) {
    if (field === "socialCount") return Object.keys(lead.socials || {}).length;
    if (field.startsWith("social:")) return (lead.socials || {})[field.slice(7)] || "";
    return lead[field] === undefined || lead[field] === null ? "" : lead[field];
  }

  function ruleMatches(rule, lead) {
    const value = ruleValue(lead, rule.field);
    const text = String(value).toLowerCase();
    const wanted = String(rule.value === undefined ? "" : rule.value).trim().toLowerCase();
    const terms = wanted.split(",").map((w) => w.trim()).filter(Boolean);
    switch (rule.op) {
      case "empty": return value === "" || value === 0;
      case "notEmpty": return value !== "" && value !== 0;
      case "contains": return terms.length > 0 && terms.some((w) => text.includes(w));
      case "notContains": return terms.length > 0 && !terms.some((w) => text.includes(w));
      case "is": return terms.includes(text);
      case "gt": return wanted !== "" && value !== "" && Number(value) > Number(wanted);
      case "lt": return wanted !== "" && value !== "" && Number(value) < Number(wanted);
      default: return false;
    }
  }

  // Team rules (Affan, 18 Nov 2026: points scoring removed). Same as the App's src/lib/scoring.ts applyRules: data quality,
  // whether a rule rejects the lead, and whether a rule marks it Good or No (No wins over Good; Reject wins over both).
  // Old "boost" / "penalty" points rules are skipped.
  function applyRules(lead, rules) {
    lead.quality = dataQuality(lead);
    let rejected = false, good = false, no = false;
    for (const rule of rules || []) {
      if (rule.action === "boost" || rule.action === "penalty" || !ruleMatches(rule, lead)) continue;
      if (rule.action === "reject") rejected = true;
      else if (rule.action === "no") no = true;
      else if (rule.action === "good") good = true;
    }
    lead.ruleReject = rejected;
    lead.ruleMark = rejected || no ? "No" : good ? "Good" : null;
    delete lead.score; delete lead.tier;   // older versions stored points; they mean nothing now
    return lead;
  }
  // The collect code passes the whole settings object.
  const applyScore = (lead, config) => applyRules(lead, (config && config.refine && config.refine.rules) || []);

  const wordList = (t) => String(t || "").split(/[\n,]+/).map((w) => w.trim().toLowerCase()).filter(Boolean);
  const wholeWord = (word, text) => new RegExp(`(?<![\\p{L}\\d])${word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![\\p{L}\\d])`, "iu").test(text);

  // Checks that need no website visit, so rejected leads never cost a fetch.
  function preFilter(lead, refine) {
    const reviews = Number(lead.reviews) || 0;
    if (refine.minRating && (Number(lead.rating) || 0) < Number(refine.minRating)) return "low rating";
    const hidden = lead.rating && lead.reviews === "";
    if (refine.minReviews && !hidden && reviews < Number(refine.minReviews)) return "too few reviews";
    if (refine.maxReviews && !hidden && reviews > Number(refine.maxReviews)) return "too many reviews";
    if (refine.needWebsite && !lead.website) return "no website";
    if (refine.needPhone && !lead.phone) return "no phone";
    const text = `${lead.name || ""} ${lead.category || ""}`;
    if (wordList(refine.excludeWords).some((w) => wholeWord(w, text))) return "excluded word";
    const include = wordList(refine.includeWords);
    if (include.length && !include.some((w) => wholeWord(w, text))) return "missing required word";
    return "";
  }

  function postFilter(lead, refine) {
    if (lead.ruleReject) return "custom rule";
    if (refine.needEmail && !lead.email) return "no email";
    if (refine.businessEmailOnly && !["person", "role"].includes(lead.emailKind)) return "no business email";
    if (refine.needSocial && !Object.keys(lead.socials || {}).length) return "no social";
    if (refine.needPhone && !lead.phone) return "no phone";
    if (refine.minQuality && lead.quality < Number(refine.minQuality)) return "data quality below minimum";
    const socialCount = Object.keys(lead.socials || {}).length;
    if (refine.minSocials && socialCount < Number(refine.minSocials)) return "too few socials";
    if (refine.minChannels && [lead.email, lead.phone, socialCount].filter(Boolean).length < Number(refine.minChannels)) return "too few contact channels";
    if (refine.needDescription && !lead.description) return "no description";
    if (refine.needAddress && !lead.address) return "no address";
    if (refine.emailMatchesSite && !["person", "role"].includes(lead.emailKind)) return "email doesn't match website";
    return "";
  }

  function placeKey(url, name, address) {
    const id = String(url || "").match(/!1s(0x[0-9a-f]+:0x[0-9a-f]+)/i);
    return id ? id[1] : `${name}|${address}`.toLowerCase();
  }

  function newLead(source, fields) {
    return Object.assign({ source, name: "", category: "", address: "", location: "", keyword: "", phone: "", website: "",
      email: "", emails: [], emailKind: "none", socials: {}, rating: "", reviews: "", description: "", url: "",
      status: "new", exported: false, createdAt: Date.now() }, fields);
  }

  const FORMULA_RE = /^=|^[+\-@].*[A-Za-z(]/s;
  function csvCell(value) {
    let text = value === undefined || value === null ? "" : String(value);
    if (FORMULA_RE.test(text)) text = `'${text}`;
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  }

  const SOURCE_LABEL = { maps: "Google Maps", search: "Google Search", youtube: "YouTube", osm: "OpenStreetMap", jobs: "Job boards", companies: "Companies House", podcasts: "Listen Notes", page: "Web page", site: "Website", import: "Imported" };
  const COLUMNS = [
    ["Business", (l) => l.name], ["Category", (l) => l.category], ["Address", (l) => l.address], ["City", (l) => l.city || ""], ["Search Location", (l) => l.location],
    ["Phone", (l) => l.phone], ["Website", (l) => l.website], ["Email", (l) => l.email], ["All Emails", (l) => (l.emails || []).join("; ")],
    ["Email Type", (l) => EMAIL_LABEL[l.emailKind] || ""],
    ...SOCIAL_KEYS.map((k) => [SOCIALS[k].label, (l) => (l.socials || {})[k] || ""]),
    ["Rating", (l) => l.rating], ["Reviews", (l) => l.reviews], ["Data Quality", (l) => l.quality], ["AI Fit", (l) => (l.ai ? l.ai.fit : "")], ["AI Verdict", (l) => (l.ai ? l.ai.verdict : "")], ["AI Reason", (l) => (l.ai ? l.ai.reason : "")],
    ["Description", (l) => l.description], ["Profile URL", (l) => l.url], ["Source", (l) => SOURCE_LABEL[l.source]], ["Search Keyword", (l) => l.keyword],
    ["Contact Name", (l) => ((l.contacts || [])[0] || {}).name || ""], ["Contact Role", (l) => { const c = (l.contacts || [])[0] || {}; return c.position || c.role || ""; }],
    ["Hiring For", (l) => ((l.hiring && l.hiring.jobs) || []).map((j) => j.title).join("; ")],
    ["Subscribers", (l) => l.subscribers || ""], ["Videos", (l) => l.videos || ""], ["Channel Country", (l) => l.country || ""], ["Joined YouTube", (l) => l.joined || ""],
    // Personal email parts (AI → Emails). Column names match the Manyreach variables {{FIRST_NAME}}, {{ICEBREAKER}}, {{QUESTION}}.
    ["FIRST_NAME", (l) => (l.outreach ? l.outreach.firstName : "")], ["SUBJECT", (l) => (l.outreach ? l.outreach.subject : "")],
    ["ICEBREAKER", (l) => (l.outreach ? l.outreach.icebreaker : "")], ["QUESTION", (l) => (l.outreach ? l.outreach.question : "")], ["EMAIL_BODY", (l) => (l.outreach ? l.outreach.body : "")],
  ];
  const leadsToCsv = (leads) => [COLUMNS.map((c) => c[0]), ...leads.map((l) => COLUMNS.map((c) => c[1](l)))]
    .map((row) => row.map(csvCell).join(",")).join("\r\n") + "\r\n";
  const exportFolder = (source) => ({ maps: "google_maps", search: "google_search", youtube: "youtube", osm: "openstreetmap", jobs: "hiring", companies: "companies_house", podcasts: "podcasts" }[source] || "web");

  // ---- export
  const COLUMN_NAMES = COLUMNS.map((c) => c[0]);
  const SOCIAL_LABELS = SOCIAL_KEYS.map((k) => SOCIALS[k].label);
  const EXPORT_PRESETS = {
    full: { label: "Everything", columns: COLUMN_NAMES },
    nameEmail: { label: "Name and Email", columns: ["Business", "Email"], need: "Email" },
    contact: { label: "Contact Details", columns: ["Business", "Email", "Phone", "Website"] },
    emails: { label: "Emails Only", columns: ["Email"], need: "Email" },
    phones: { label: "Name and Phone", columns: ["Business", "Phone"], need: "Phone" },
    socials: { label: "Social Profiles", columns: ["Business", ...SOCIAL_LABELS] },
    websites: { label: "Websites", columns: ["Business", "Website"], need: "Website" },
    emailReady: { label: "Email Ready (Manyreach / Gmail)", columns: ["Email", "FIRST_NAME", "SUBJECT", "ICEBREAKER", "QUESTION", "EMAIL_BODY", "Business", "Website"], need: "Email", needDraft: true },
    custom: { label: "Custom", columns: [] },
  };

  function buildExport(leads, options) {
    const getters = options.columns.map((name) => [name, COLUMNS.find((c) => c[0] === name)[1]]);
    const out = [], seen = new Set();
    for (const lead of leads) {
      if (options.needDraft && !lead.outreach) continue;
      const emails = options.perEmail && lead.emails && lead.emails.length ? lead.emails : [lead.email];
      for (const email of emails) {
        const copy = options.perEmail ? { ...lead, email } : lead;
        const row = {};
        for (const [name, get] of getters) row[name] = get(copy);
        if (options.need && !String(row[options.need] || "")) continue;
        if (options.requireEmail && !email) continue;
        if (options.uniqueEmail && email) {
          if (seen.has(email)) continue;
          seen.add(email);
        }
        if (Object.values(row).some((v) => String(v) !== "")) out.push(row);
      }
    }
    return out;
  }

  function serializeExport(rows, columns, format) {
    if (format === "json") return JSON.stringify(rows, null, 2);
    if (format === "txt") return rows.map((r) => columns.map((c) => String(r[c] === undefined ? "" : r[c]).replace(/[\t\r\n]+/g, " ")).join("\t")).join("\n") + "\n";
    return [columns, ...rows.map((r) => columns.map((c) => r[c]))].map((row) => row.map(csvCell).join(",")).join("\r\n") + "\r\n";
  }

  // ---- import
  function parseCsv(text) {
    const source = String(text || "").replace(/^\uFEFF/, "");
    const first = source.split(/\r?\n/, 1)[0] || "";
    const delimiter = [",", ";", "\t"].reduce((a, b) => (first.split(b).length > first.split(a).length ? b : a));
    const rows = [];
    let row = [], cell = "", quoted = false;
    for (let i = 0; i < source.length; i++) {
      const c = source[i];
      if (quoted) {
        if (c === '"' && source[i + 1] === '"') { cell += '"'; i++; }
        else if (c === '"') quoted = false;
        else cell += c;
      } else if (c === '"' && cell === "") quoted = true;
      else if (c === delimiter) { row.push(cell); cell = ""; }
      else if (c === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; }
      else if (c !== "\r") cell += c;
    }
    if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
    const headers = (rows.shift() || []).map((h, i) => h.trim() || `Column ${i + 1}`);
    const clean = (v) => String(v === undefined ? "" : v).trim().replace(/^'(?=[=+\-@])/, "");
    return { headers, rows: rows.filter((r) => r.some((v) => String(v).trim())).map((r) => Object.fromEntries(headers.map((h, i) => [h, clean(r[i])]))) };
  }

  const IMPORT_FIELDS = [
    ["name", "Business name", /^(business|company|name|organi[sz]ation|title|brand)/i], ["email", "Email", /e-?mail/i], ["phone", "Phone", /phone|mobile|tel/i],
    ["website", "Website", /web ?site|domain|^url$/i], ["category", "Category", /categor|industry|type/i], ["address", "Address", /address|street/i],
    ["city", "City", /^city$/i], ["location", "Location", /location|city|country|area/i], ["description", "Description", /descri|about|bio|snippet/i], ["rating", "Rating", /^rating/i], ["reviews", "Reviews", /review/i],
    ["keyword", "Keyword", /keyword/i],
    ...SOCIAL_KEYS.map((k) => [`social:${k}`, SOCIALS[k].label, new RegExp(`^${SOCIALS[k].label}$`, "i")]),
  ];

  function guessMapping(headers) {
    const used = new Set(), mapping = {};
    for (const [field, , pattern] of [...IMPORT_FIELDS].reverse()) {
      if (!field.startsWith("social:")) continue;
      const hit = headers.find((h) => pattern.test(h));
      if (hit) { mapping[field] = hit; used.add(hit); }
    }
    for (const [field, , pattern] of IMPORT_FIELDS) {
      if (field.startsWith("social:")) continue;
      const hit = headers.find((h) => !used.has(h) && pattern.test(h) && !/type|status|valid|verdict|score/i.test(h));
      if (hit) { mapping[field] = hit; used.add(hit); }
    }
    return mapping;
  }

  function leadFromRow(row, mapping, list) {
    const value = (field) => (mapping[field] ? row[mapping[field]] || "" : "");
    const socials = {};
    SOCIAL_KEYS.forEach((k) => { const v = value(`social:${k}`); if (/^https?:/i.test(v)) socials[k] = v; });
    const rawSite = value("website");
    const siteUrl = rawSite ? (/^https?:\/\//i.test(rawSite) ? rawSite : normalizeSiteInput(rawSite)) : "";
    const hit = siteUrl ? socialFromUrl(siteUrl) : null;
    if (hit) socials[hit.key] = socials[hit.key] || hit.url;
    const website = hit ? "" : cleanWebsite(siteUrl);
    const lead = newLead("import", { name: value("name"), category: value("category"), address: value("address"), location: value("location"), ...(value("city") ? { city: value("city") } : {}), description: value("description"),
      phone: value("phone"), website, rating: value("rating"), reviews: value("reviews"), keyword: value("keyword"), socials, url: website, lists: list ? [list] : [] });
    setEmails(lead, findEmails(`${value("email")} ${mapping.email ? "" : ""}`));
    lead.id = lead.email || hostOf(website) || `${lead.name}|${lead.address}`.toLowerCase();
    if (!lead.name) lead.name = hostOf(website) || lead.email;
    return lead;
  }

  // ---- duplicates: the most complete record of each company survives and absorbs the others.
  function findDuplicates(leads) {
    const byEmail = new Map(), byHost = new Map(), merges = [];
    for (const lead of [...leads].sort((a, b) => (Number(b.quality) || 0) - (Number(a.quality) || 0))) {
      const host = hostOf(lead.website);
      const keeper = (lead.email && byEmail.get(lead.email)) || (host && byHost.get(host));
      if (keeper) { merges.push([keeper, lead]); continue; }
      if (lead.email) byEmail.set(lead.email, lead);
      if (host) byHost.set(host, lead);
    }
    return merges;
  }

  // ---- one business, many sources: keys that identify the same company across Maps, Search, OSM, pages and imports
  // Hosts many unrelated businesses share, so they never prove two leads are the same company.
  const SHARED_HOSTS = /(^|\.)(linktr\.ee|bio\.link|beacons\.ai|carrd\.co|calendly\.com|yell\.com|yelp\.[a-z.]+|tripadvisor\.[a-z.]+|booking\.com|bit\.ly|goo\.gl|g\.page|google\.[a-z.]+|business\.site|wa\.me|whatsapp\.com|linkedin\.com|facebook\.com|instagram\.com|clutch\.co|upwork\.com|fiverr\.com)$/i;
  const NAME_NOISE = /\b(ltd|limited|llc|inc|plc|co|company|the|uk|gmbh|bv|ab|as|srl|sl|sa|pty|llp|group)\b/g;
  function normName(name) {
    return String(name || "").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/&/g, " and ").replace(/[^a-z0-9 ]+/g, " ").replace(NAME_NOISE, " ").replace(/\s+/g, " ").trim();
  }
  function companyKeys(lead) {
    const keys = [];
    const host = hostOf(lead.website);
    if (host && !SHARED_HOSTS.test(host)) keys.push(`web:${host}`);
    for (const e of new Set([lead.email, ...(lead.emails || [])].filter(Boolean).map((x) => String(x).toLowerCase()))) keys.push(`mail:${e}`);
    const digits = String(lead.phone || "").replace(/\D/g, "");
    if (digits.length >= 9) keys.push(`tel:${digits.slice(-9)}`);
    const n = normName(lead.name), town = normName(String(lead.address || "").split(",").slice(-2, -1)[0] || "") || normName(String(lead.location || "").split(",")[0]);
    if (n.length >= 4 && town) keys.push(`name:${n}|${town}`);
    return keys;
  }
  // Index of the businesses already in this workspace. find() returns the id of the matching lead, or "".
  function dupIndex(leads) {
    const map = new Map();
    const add = (lead) => { for (const k of companyKeys(lead)) if (!map.has(k)) map.set(k, lead.id); };
    (leads || []).forEach(add);
    return { add, find: (lead) => { for (const k of companyKeys(lead)) { const id = map.get(k); if (id && id !== lead.id) return id; } return ""; }, size: () => map.size };
  }
  // People at a company, one entry per person: roles are joined, the first email kept.
  function mergeContacts(...lists) {
    const out = new Map();
    for (const c of lists.flat().filter((x) => x && x.name)) {
      const k = c.name.toLowerCase().replace(/\s+/g, " ").trim(), had = out.get(k);
      if (!had) { out.set(k, { name: c.name, position: c.position || c.role || "", email: c.email || "" }); continue; }
      const role = c.position || c.role || "";
      if (role && !had.position.toLowerCase().includes(role.toLowerCase())) had.position = had.position ? `${had.position}, ${role}` : role;
      if (!had.email && c.email) had.email = c.email;
    }
    return [...out.values()].slice(0, 5);
  }
  // Adds what the new copy knows to the lead you already have, and remembers every source it was seen in.
  function mergeSighting(keeper, other) {
    absorb(keeper, other);
    if (!keeper.website && other.website) keeper.website = other.website;
    keeper.sources = [...new Set([...(keeper.sources || [keeper.source]), other.source].filter(Boolean))];
    if ((other.contacts || []).length) keeper.contacts = mergeContacts(keeper.contacts || [], other.contacts);
    keeper.seenAgainAt = Date.now();
    return keeper;
  }

  function absorb(keeper, other) {
    setEmails(keeper, [...keeper.emails, ...(other.emails || [])]);
    keeper.socials = { ...(other.socials || {}), ...keeper.socials };
    for (const f of ["phone", "description", "address", "category", "rating", "reviews", "city", "cityFrom"]) if (!keeper[f] && other[f]) keeper[f] = other[f];
    keeper.lists = [...new Set([...(keeper.lists || []), ...(other.lists || [])])];
  }

  // ---- polite website reading: robots.txt rules for "*" (browsers cannot set their own user agent name)
  function parseRobots(text) {
    const groups = [];
    let cur = null, lastWasAgent = false;
    for (const raw of String(text || "").split(/\r?\n/)) {
      const line = raw.replace(/#.*/, "").trim();
      const m = /^([a-z-]+)\s*:\s*(.*)$/i.exec(line);
      if (!m) continue;
      const key = m[1].toLowerCase(), val = m[2].trim();
      if (key === "user-agent") {
        if (!cur || !lastWasAgent) { cur = { agents: [], rules: [] }; groups.push(cur); }
        cur.agents.push(val.toLowerCase());
        lastWasAgent = true;
      } else {
        lastWasAgent = false;
        if (cur && (key === "allow" || key === "disallow")) cur.rules.push({ allow: key === "allow", path: val });
      }
    }
    const star = groups.filter((g) => g.agents.includes("*"));
    return star.flatMap((g) => g.rules).filter((r) => r.path || r.allow);
  }
  // Longest matching rule wins; Allow wins a tie. Supports * and $ like Google's parser.
  function robotsAllows(rules, path) {
    let best = null;
    for (const r of rules || []) {
      if (!r.path) continue;
      const re = new RegExp("^" + r.path.replace(/[.+?^{}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\\\$$/, "$"));
      if (re.test(path) && (!best || r.path.length > best.path.length || (r.path.length === best.path.length && r.allow))) best = r;
    }
    return !best || best.allow;
  }

  // ---- do-not-contact list: emails and whole domains. Same columns as _pipeline/do_not_contact.csv
  function normalizeDnc(entry) {
    const e = String(entry || "").trim().toLowerCase().replace(/^mailto:/, "");
    if (!e) return "";
    if (e.includes("@") && !e.startsWith("@")) return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) ? e : "";
    const host = hostOf(/^https?:\/\//.test(e) ? e : `https://${e.replace(/^@/, "")}`);
    return host && host.includes(".") ? host : "";
  }
  function dncIndex(rows) {
    const emails = new Set(), domains = new Set();
    for (const r of rows || []) { const e = normalizeDnc(r.entry); if (!e) continue; (e.includes("@") ? emails : domains).add(e); }
    return { emails, domains };
  }
  // True when any of the lead's emails, email domains or its website is on the list.
  function dncBlocks(lead, index) {
    if (!index || (!index.emails.size && !index.domains.size)) return false;
    const mails = [...new Set([lead.email, ...(lead.emails || [])].filter(Boolean).map((e) => String(e).toLowerCase()))];
    const doms = new Set([hostOf(lead.website), ...mails.map((e) => e.split("@")[1])].filter(Boolean));
    if (mails.some((e) => index.emails.has(e))) return true;
    for (const d of doms) { const parts = d.split("."); for (let i = 0; i < parts.length - 1; i++) if (index.domains.has(parts.slice(i).join("."))) return true; }
    return false;
  }
  // Reads a do-not-contact CSV. With headers it uses the email/domain column; a plain list of lines also works.
  function parseDncCsv(text) {
    const source = String(text || "").replace(/^\uFEFF/, "");
    const first = (source.split(/\r?\n/, 1)[0] || "").toLowerCase();
    if (!/email|domain|entry/.test(first)) return source.split(/\r?\n/).map((l) => ({ entry: normalizeDnc(l.split(/[,;\t]/)[0]), reason: (l.split(/[,;\t]/)[1] || "").trim() })).filter((r) => r.entry);
    const { headers, rows } = parseCsv(source);
    const col = headers.find((h) => /email|domain|entry/i.test(h)), why = headers.find((h) => /reason/i.test(h));
    return rows.map((r) => ({ entry: normalizeDnc(r[col]), reason: why ? r[why] : "" })).filter((r) => r.entry);
  }

  // ---- rolling time limit: Google searches per window (2 hours)
  const WINDOW_SOURCES = ["maps", "search", "youtube"];
  const H = 3600000;
  const isSearch = (e) => WINDOW_SOURCES.includes(e.s);
  // used = total in the window; resetAt = when enough old entries expire to go back under the cap (or when the oldest expires).
  function windowState(log, hours, cap, now = Date.now()) {
    const since = now - hours * H;
    const hits = (log || []).filter((e) => e && isSearch(e) && e.at > since && e.at <= now).sort((a, b) => a.at - b.at);
    const used = hits.reduce((k, e) => k + (Number(e.n) || 1), 0);
    const c = Number(cap) || 0, full = !!c && used >= c;
    let resetAt = hits.length ? hits[0].at + hours * H : null;
    if (full) {
      let left = used;
      for (const e of hits) { left -= Number(e.n) || 1; if (left < c) { resetAt = e.at + hours * H; break; } }
    }
    return { used, cap: c, full, left: c ? Math.max(0, c - used) : Infinity, resetAt };
  }
  const whenText = (t) => new Date(t).toLocaleString(undefined, { weekday: "short", hour: "2-digit", minute: "2-digit" });
  // Returns why no more Google searches are allowed now ("" when they are).
  function windowBlock(log, plan, now = Date.now()) {
    const w = windowState(log, plan.windowHours || 2, plan.searchesPerWindow, now);
    return w.full ? `your ${plan.name} plan allows ${w.cap} Google searches every ${plan.windowHours || 2} hours. The next one frees up ${whenText(w.resetAt)}` : "";
  }
  // Keeps 8 days of entries, newest first.
  function pruneSearchLog(log, now = Date.now()) {
    return (log || []).filter((e) => e && e.at > now - 192 * H).sort((a, b) => b.at - a.at).slice(0, 20000);
  }
  function mergeSearchLog(a, b, now = Date.now()) {
    const seen = new Set(), out = [];
    for (const e of [...(a || []), ...(b || [])]) { const k = `${e.at}|${e.s}|${e.n || 1}`; if (!seen.has(k)) { seen.add(k); out.push(e); } }
    return pruneSearchLog(out, now);
  }

  // ---- editions: a selling build can switch off whole modes
  const featureOn = (config, mode) => !(config && config.features && config.features[mode] === false);

  // ---- merging a backup from another browser profile: never lose work on either side
  const aiRank = (ai) => (!ai ? 0 : ai.manual ? 2 : 1);
  function mergeLead(mine, theirs) {
    if (!mine) return theirs;
    if (!theirs) return mine;
    const out = { ...mine, socials: { ...(mine.socials || {}) }, emails: [...(mine.emails || [])], lists: [...(mine.lists || [])] };
    absorb(out, theirs);
    for (const f of ["website", "location", "keyword", "url", "name"]) if (!out[f] && theirs[f]) out[f] = theirs[f];
    // Fit: set by you beats AI; otherwise the newer judgement wins.
    const a = mine.ai, b = theirs.ai;
    if (aiRank(b) > aiRank(a) || (aiRank(b) === aiRank(a) && b && (b.at || 0) > (a.at || 0))) out.ai = b;
    // Review status: any decision beats "new"; if both decided, keep the newer one.
    if (mine.status === "new" && theirs.status && theirs.status !== "new") out.status = theirs.status;
    else if (theirs.status && theirs.status !== "new" && (theirs.statusAt || 0) > (mine.statusAt || 0)) { out.status = theirs.status; out.statusAt = theirs.statusAt; }
    out.exported = !!(mine.exported || theirs.exported);
    out.createdAt = Math.min(mine.createdAt || Infinity, theirs.createdAt || Infinity) === Infinity ? mine.createdAt : Math.min(mine.createdAt || Infinity, theirs.createdAt || Infinity);
    return out;
  }
  // Search progress: "done" beats "in progress"; otherwise the newer record wins. Saved counts keep the larger.
  function mergeCoverage(mine, theirs) {
    const out = { ...(mine || {}) };
    for (const [key, t] of Object.entries(theirs || {})) {
      const m = out[key];
      if (!m) { out[key] = t; continue; }
      const mDone = m.status === "done", tDone = t.status === "done";
      const pick = mDone !== tDone ? (tDone ? t : m) : (t.at || 0) > (m.at || 0) ? t : m;
      out[key] = { ...pick, saved: Math.max(m.saved || 0, t.saved || 0), at: Math.max(m.at || 0, t.at || 0) };
    }
    return out;
  }
  // Safety: today's counts and pauses follow you, so a new profile does not reset the daily limits.
  function mergeSafetyState(mine, theirs, now = Date.now()) {
    const date = new Date(now), day = todayKey(date);
    const usage = { ...usageToday(mine.usage, date) }, tu = theirs.usage && theirs.usage.date === day ? theirs.usage : null;
    if (tu) for (const k of ["maps", "search", "youtube", "ytChannels"]) usage[k] = Math.max(usage[k] || 0, tu[k] || 0);
    const cooldown = { ...(mine.cooldown || {}) };
    for (const [k, until] of Object.entries(theirs.cooldown || {})) if (until > now) cooldown[k] = Math.max(cooldown[k] || 0, until);
    const md = mine.daily && mine.daily.date === day ? mine.daily.count : 0, td = theirs.daily && theirs.daily.date === day ? theirs.daily.count : 0;
    return { usage, cooldown, daily: { date: day, count: Math.max(md, td) }, searchLog: mergeSearchLog(mine.searchLog, theirs.searchLog, now) };
  }

  function mergeDefaults(saved) {
    const out = {}, base = JSON.parse(JSON.stringify(DEFAULTS));
    for (const key of Object.keys(base)) {
      out[key] = typeof base[key] === "object" ? { ...base[key], ...((saved || {})[key] || {}) } : (saved && saved[key] !== undefined ? saved[key] : base[key]);
    }
    const t = out.targets;
    t.source = { ...base.targets.source, ...(t.source || {}) };
    t.pick = { maps: { ...base.targets.pick.maps, ...((t.pick || {}).maps || {}) }, search: { ...base.targets.pick.search, ...((t.pick || {}).search || {}) }, osm: { ...base.targets.pick.osm, ...((t.pick || {}).osm || {}) } };
    t.youtube = { ...base.targets.youtube, ...(t.youtube || {}) };
    out.safety.daily = { ...base.safety.daily, ...(((saved || {}).safety || {}).daily || {}) };
    return out;
  }

  const api = { SOCIALS, SOCIAL_KEYS, DEFAULTS, EMAIL_LABEL, SOURCE_LABEL, parseLines, hostOf, buildMapsUrl, buildSearchUrl, mapsQueue, searchQueue, searchQuery, shortPlace, coverKey, isDone, coverageStats, placeState, migrateCoverage, libCountry, allPlaces, allKeywords, areaOfPlace, parseKeywordImport, parseLocationImport, mergeLibrary, libraryCounts, nameFromFile,
    ANY_COUNTRY, ytSearchUrl, ytInitialData, ytConfig, ytFind, ytText, parseCount, ytChannels, ytAbout, ytLinkUrl, ytQueue, ytCheck, shortCount, parseChannelInput,
    SAFETY_PRESETS, applySafety, pace, todayKey, usageToday, safetyBlock, isPrivateHost,
    normalizeSiteInput, findEmails, findPhones, cleanWebsite, socialFromUrl, findSocials, parseSite, siteAddress, applySiteAddress, emailKind, rankEmails, setEmails,
    applyScore, applyRules, mergeContacts, normName, companyKeys, dupIndex, mergeSighting, WINDOW_SOURCES, windowState, windowBlock, pruneSearchLog, mergeSearchLog, parseRobots, robotsAllows, normalizeDnc, dncIndex, dncBlocks, parseDncCsv, featureOn, unescapeHtml, cleanLeadText, mergeLead, mergeCoverage, mergeSafetyState, dataQuality, RULE_FIELDS, RULE_OPS, NO_VALUE, ruleMatches, preFilter, postFilter, placeKey, newLead, leadsToCsv, exportFolder, mergeDefaults, COLUMNS, COLUMN_NAMES, EXPORT_PRESETS, buildExport, serializeExport, parseCsv, IMPORT_FIELDS, guessMapping, leadFromRow, findDuplicates, absorb };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QuarryLib = api;
})(globalThis);
