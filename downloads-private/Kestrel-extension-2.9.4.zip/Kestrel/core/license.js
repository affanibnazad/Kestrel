// Licence keys. Works with Lemon Squeezy's public licence API, which needs no secret in the extension.
// The key is kept in chrome.storage.local: it is never put in backups and "Clear All" does not remove it.
(function (root) {
  const API = "https://api.lemonsqueezy.com/v1/licenses/";
  const DAY = 86400000;
  const cfg = () => root.QuarryLicenseConfig || { provider: "" };
  const hasStore = () => !!(root.chrome && chrome.storage && chrome.storage.local);
  const load = async () => (hasStore() ? (await chrome.storage.local.get("license")).license || null : null);
  const save = async (v) => { if (hasStore()) await chrome.storage.local.set({ license: v }); };

  // Account mode (provider "kestrel"): no licence key. Kestrel works while it is connected to a team in the
  // Kestrel App whose free trial is running or whose plan is paid. `account` is the saved App connection (core/cloud.js).
  // Fully locked without an account (Affan, 14 Nov 2026): checked at least every 12 hours, locked after 24 hours offline.
  const ACCOUNT_FRESH = DAY / 2, ACCOUNT_GRACE = DAY;
  function decideAccount(account, now) {
    if (!account || !account.token) return { state: "locked", ok: false, reason: "connect", text: "Kestrel works only with a Kestrel account. Click Sign in to Kestrel: the App opens, you sign in, and it connects this extension." };
    if (account.active === false) return { state: "locked", ok: false, reason: "plan", text: "Your team's free trial or plan has ended. Choose a plan in the Kestrel App to use Kestrel again. Your leads are safe in the App." };
    const age = now - (account.statusAt || 0);
    if (age < ACCOUNT_FRESH) return { state: "active", ok: true, text: `Connected to ${account.team || "your team"}.` };
    if (age < ACCOUNT_GRACE) return { state: "stale", ok: true, text: `Connected to ${account.team || "your team"}. Checking again when online.` };
    return { state: "locked", ok: false, reason: "offline", text: "Connect to the internet so Kestrel can check your plan (needed at least once a day)." };
  }

  // Pure decision, so it can be tested: what state is this saved licence in right now?
  function decide(saved, config, now = Date.now(), account = null) {
    if (!config || !config.provider) return { state: "owner", ok: true, text: "Owner build. No key needed." };
    if (config.provider === "kestrel") return decideAccount(account, now);
    if (!saved || !saved.key) return { state: "locked", ok: false, text: "Enter your licence key to start." };
    if (saved.status && saved.status !== "active") return { state: "locked", ok: false, text: `This key is ${saved.status}.` };
    if (saved.expiresAt && Date.parse(saved.expiresAt) < now) return { state: "locked", ok: false, text: "This key has expired." };
    const age = now - (saved.checkedAt || 0);
    if (age < DAY) return { state: "active", ok: true, text: "Licence active." };
    if (age < (Number(config.graceDays) || 7) * DAY) return { state: "stale", ok: true, text: "Licence active. Checking again when online." };
    return { state: "locked", ok: false, text: "Connect to the internet once to check your licence." };
  }

  const mask = (k) => (k ? `${String(k).slice(0, 4)}••••${String(k).slice(-4)}` : "");

  async function call(action, body) {
    const res = await fetch(API + action, { method: "POST", headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(body) });
    let data = {};
    try { data = await res.json(); } catch (_) { /* empty reply */ }
    return data;
  }

  // Checks the key belongs to this product, so a key from another Lemon Squeezy shop does not work.
  function matches(meta, config) {
    if (!meta) return false;
    if (config.storeId && Number(meta.store_id) !== Number(config.storeId)) return false;
    if (config.productId && Number(meta.product_id) !== Number(config.productId)) return false;
    return true;
  }

  async function deviceName() {
    let id = hasStore() ? (await chrome.storage.local.get("deviceId")).deviceId : "";
    if (!id) { id = crypto.randomUUID().slice(0, 8); if (hasStore()) await chrome.storage.local.set({ deviceId: id }); }
    return `Kestrel ${id}`;
  }

  async function activate(key) {
    const config = cfg();
    key = String(key || "").trim();
    if (!config.provider) return { ok: true, text: "Owner build. No key needed." };
    if (!/^[A-Za-z0-9-]{8,80}$/.test(key)) return { ok: false, text: "That doesn't look like a licence key." };
    let data;
    try { data = await call("activate", { license_key: key, instance_name: await deviceName() }); } catch (_) { return { ok: false, text: "No internet. Connect and try again." }; }
    if (!data.activated) return { ok: false, text: data.error || "That key could not be activated." };
    if (!matches(data.meta, config)) return { ok: false, text: "That key is for a different product." };
    const lk = data.license_key || {};
    await save({ key, instanceId: (data.instance || {}).id, status: lk.status || "active", expiresAt: lk.expires_at || null, checkedAt: Date.now(),
      name: (data.meta || {}).customer_name || "", plan: (data.meta || {}).variant_name || "", variantId: (data.meta || {}).variant_id || null, limit: lk.activation_limit || null, used: lk.activation_usage || null });
    if (root.QuarryDB) root.QuarryDB.log("licence", `Licence activated (${mask(key)})`);
    return { ok: true, text: "Licence active. Thank you!" };
  }

  async function validate() {
    const config = cfg(), saved = await load();
    if (config.provider === "kestrel") return status();
    if (!config.provider || !saved || !saved.key) return decide(saved, config);
    try {
      const data = await call("validate", { license_key: saved.key, instance_id: saved.instanceId || "" });
      if (data.valid && matches(data.meta, config)) {
        const lk = data.license_key || {};
        const meta = data.meta || {};
        // A subscription can move between plans; take the plan from every check.
        await save({ ...saved, status: lk.status || "active", expiresAt: lk.expires_at || null, checkedAt: Date.now(), plan: meta.variant_name || saved.plan, variantId: meta.variant_id || saved.variantId });
      } else if (data.error || data.valid === false) {
        await save({ ...saved, status: (data.license_key || {}).status || "invalid", checkedAt: Date.now() });
      }
    } catch (_) { /* offline: the grace period decides */ }
    return decide(await load(), config);
  }

  async function status() {
    const config = cfg();
    if (config.provider === "kestrel") {
      const C = root.QuarryCloud;
      let account = C ? await C.conn() : null;
      // Ask the App again when the last answer is over an hour old (or said the plan had ended).
      if (C && account && account.token && (account.active === false || Date.now() - (account.statusAt || 0) > 3600000)) { await C.refreshStatus().catch(() => null); account = await C.conn(); }
      return decide(null, config, Date.now(), account);
    }
    const saved = await load(), now = decide(saved, config);
    if (now.state === "stale" || (now.state === "locked" && saved && saved.key && saved.status === "active")) return validate();
    return now;
  }

  // Frees this computer's seat so the key can be used on another one.
  async function deactivate() {
    const saved = await load();
    if (!saved) return { ok: true };
    try { await call("deactivate", { license_key: saved.key, instance_id: saved.instanceId || "" }); } catch (_) { return { ok: false, text: "No internet. Connect and try again." }; }
    await save(null);
    if (root.QuarryDB) root.QuarryDB.log("licence", "Licence removed from this computer");
    return { ok: true, text: "Licence removed from this computer." };
  }

  const api = { decide, status, activate, validate, deactivate, load, mask, matches };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QuarryLicense = api;
})(globalThis);
