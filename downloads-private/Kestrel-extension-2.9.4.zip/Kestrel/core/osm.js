// OpenStreetMap mode: finds businesses through the official Overpass API. No Google involved.
// Data © OpenStreetMap contributors, licensed under the ODbL (openstreetmap.org/copyright).
// Using leads inside your business is fine with this credit; publishing a database built from it brings share-alike duties.
(function (root) {
  const L = root.QuarryLib;
  const DEFAULT_SERVER = "https://overpass-api.de/api/interpreter";
  // Public Overpass servers listed on the OpenStreetMap wiki. When one is full, Kestrel asks the next one (once each).
  const PUBLIC_SERVERS = [DEFAULT_SERVER, "https://overpass.private.coffee/api/interpreter", "https://overpass.kumi.systems/api/interpreter"];
  const COUNTRY_CODES = {
    "Ireland": "IE", "United Kingdom": "GB", "Australia": "AU", "New Zealand": "NZ", "United States": "US", "Canada": "CA",
    "Italy": "IT", "Germany": "DE", "Netherlands": "NL", "Sweden": "SE", "Denmark": "DK", "Norway": "NO", "Finland": "FI",
    "Switzerland": "CH", "Austria": "AT", "Belgium": "BE", "France": "FR", "Spain": "ES", "Singapore": "SG", "United Arab Emirates": "AE",
    "UK": "GB", "USA": "US", "UAE": "AE",
  };
  const STOP = new Set(["agency", "agencies", "company", "companies", "services", "service", "the", "and", "of", "in", "for", "a", "an", "ltd", "limited", "&", "-", "firm", "firms", "business", "businesses"]);
  // Keywords that also match OpenStreetMap's own tag for ad agencies.
  const AD_WORDS = /advertis|marketing|media|creative|brand|digital|social|content|performance|pr\b|public relations/i;

  const quote = (s) => `"${String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
  const reEscape = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  // "Social media agency" -> ["social", "media"]
  function keywordWords(keyword) {
    return [...new Set(String(keyword || "").toLowerCase().split(/[^a-z0-9À-ɏ]+/).filter((w) => w.length > 1 && !STOP.has(w)))].slice(0, 6);
  }

  // "Shoreditch, London, United Kingdom" -> { name: "Shoreditch", country: "United Kingdom", code: "GB" }
  function parsePlace(location) {
    const parts = String(location || "").split(",").map((p) => p.trim()).filter(Boolean);
    const country = parts.length > 1 ? parts[parts.length - 1] : "";
    // Country code: the short list above, else the built-in world library (every country has its ISO code there).
    const lib = (root.QuarryLibrary && root.QuarryLibrary.countries) || [];
    const code = COUNTRY_CODES[country] || ((lib.find((c) => c.name === country) || {}).code || "");
    return { name: parts[0] || "", country, code };
  }

  // One Overpass query for one keyword in one place. Light on the server: find the place point first (by exact name,
  // then only inside the right country), take the offices and studios near it, and only then match the keyword words.
  function buildQuery(keyword, location, limit) {
    const place = parsePlace(location), words = keywordWords(keyword);
    if (!place.name) throw new Error("No place name.");
    const nm = quote(place.name), max = Math.max(10, Math.min(1000, Number(limit) || 300));
    const scope = place.code ? `area["ISO3166-1"=${quote(place.code)}]["admin_level"="2"]->.c;\n` : "";
    const inC = (set) => (place.code ? `node.${set}(area.c)->.${set};\n` : "");
    const re = words.length ? quote(words.map(reEscape).join("|")) : "";
    const match = [re ? `  nwr.near["name"~${re},i];\n  nwr.near["description"~${re},i];` : "", !re || AD_WORDS.test(keyword) ? `  nwr.near["office"="advertising_agency"];` : ""].filter(Boolean).join("\n");
    return `[out:json][timeout:60];
${scope}node["place"="city"]["name"=${nm}]->.pc;
node["place"~"^(town|borough)$"]["name"=${nm}]->.pt;
node["place"~"^(suburb|quarter|neighbourhood|village|hamlet)$"]["name"=${nm}]->.ps;
${inC("pc")}${inC("pt")}${inC("ps")}(
  nwr["office"](around.pc:6000); nwr["craft"](around.pc:6000);
  nwr["office"](around.pt:3000); nwr["craft"](around.pt:3000);
  nwr["office"](around.ps:1200); nwr["craft"](around.ps:1200);
)->.near;
(
${match}
);
out center meta ${max};`;
  }

  const pretty = (v) => String(v || "").replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());
  const withScheme = (u) => (!u ? "" : /^https?:\/\//i.test(u) ? u : /^[\w.-]+\.[a-z]{2,}(\/|$)/i.test(u) ? `https://${u}` : "");

  // One OpenStreetMap element -> a Kestrel lead (or null when it has no name).
  function toLead(e, item) {
    const t = e.tags || {};
    if (!t.name) return null;
    const street = [t["addr:housenumber"], t["addr:street"]].filter(Boolean).join(" ");
    const address = [street, t["addr:city"], t["addr:postcode"]].filter(Boolean).join(", ");
    const site = withScheme(t.website || t["contact:website"] || t.url || "");
    const socials = {};
    for (const [k, v] of Object.entries(t)) {
      if (!/^contact:(facebook|instagram|linkedin|twitter|x|youtube|tiktok|pinterest|vimeo)$/.test(k)) continue;
      const hit = L.socialFromUrl(withScheme(v));
      if (hit) socials[hit.key] = hit.url;
    }
    const emails = [t.email, t["contact:email"]].filter(Boolean).flatMap((x) => String(x).split(/[;,\s]+/)).filter((x) => /@/.test(x));
    const lat = e.lat ?? (e.center && e.center.lat), lon = e.lon ?? (e.center && e.center.lon);
    // Freshness: when someone last edited this place (or last checked it on the ground). Older than 3 years may be out of date.
    const edited = [e.timestamp, t.check_date, t["check_date:opening_hours"]].map((d) => Date.parse(d || "")).filter(Number.isFinite).sort((a, b) => b - a)[0] || 0;
    const lead = L.newLead("osm", {
      id: `osm:${e.type}/${e.id}`, name: t.name, category: pretty(t.office || t.craft || t.shop || "Business"), address, location: item.location, keyword: item.keyword,
      phone: t.phone || t["contact:phone"] || "", website: L.cleanWebsite(site), description: t.description || "", socials,
      url: `https://www.openstreetmap.org/${e.type}/${e.id}`, emails,
      osm: { lat: lat || null, lon: lon || null, edited: edited ? new Date(edited).toISOString() : null, stale: !!edited && Date.now() - edited > 3 * 365 * 86400000 },
    });
    return lead;
  }

  function queue(keywords, locations, coverage) {
    const out = [];
    for (const location of locations) for (const keyword of keywords) {
      const key = L.coverKey("osm", keyword, location);
      if (!L.isDone(coverage, key)) out.push({ query: `${keyword} in ${location}`, keyword, location, key });
    }
    return out;
  }

  // A server must be https (or a server on this computer).
  function safeServer(url) {
    try {
      const u = new URL(String(url || "").trim() || DEFAULT_SERVER);
      if (u.protocol === "https:" || (u.protocol === "http:" && ["localhost", "127.0.0.1"].includes(u.hostname))) return u.href;
    } catch (_) { /* not a URL */ }
    return "";
  }

  class Busy extends Error {}

  async function search(server, query, signal) {
    const res = await fetch(server, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: `data=${encodeURIComponent(query)}`, credentials: "omit", signal });
    if (res.status === 429 || res.status === 502 || res.status === 503 || res.status === 504) throw new Busy(res.status === 429 ? "The OpenStreetMap server says: too many requests. Waiting." : "The OpenStreetMap server is busy. Waiting.");
    if (!res.ok) throw new Error(`OpenStreetMap server error ${res.status}.`);
    const data = await res.json();
    if (data.remark && /runtime error|timed out|out of memory/i.test(data.remark)) throw new Busy("That search was too big for the server. Try a smaller place.");
    // timestamp_osm_base: how current the server's copy of the map is.
    return { elements: data.elements || [], base: (data.osm3s && data.osm3s.timestamp_osm_base) || "" };
  }

  const api = { DEFAULT_SERVER, PUBLIC_SERVERS, COUNTRY_CODES, keywordWords, parsePlace, buildQuery, toLead, queue, safeServer, search, Busy };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QuarryOSM = api;
})(globalThis);
