// Live page rules: when Google changes its pages, Kestrel fixes the selectors on kestrelleads.com/ext/rules and every
// extension uses the fix within about 30 minutes, with no new version (Affan, 18 Nov 2026).
//
// Safety (AGENTS.md rule 1), enforced here, not only on the server:
// - Data only: CSS selectors and text patterns. Nothing from the file is ever run as code or loaded as a URL, and it
//   holds no limits, pauses or timings (those stay in core/lib.js).
// - Each rule is a list: the live value first, then the built-in one. Pages use the first selector that finds
//   something, so a wrong live value can never do worse than the built-in rules.
// - Safety checks (blocked, signedIn) use ALL entries: the live file can add checks, never remove the built-in ones.
// - Unknown keys, long strings, control characters, bad selectors and risky patterns are dropped.
(function (root) {
  const RULES_URL = "https://kestrelleads.com/ext/rules";
  const CACHE_KEY = "kestrelLiveRules";   // chrome.storage.local
  const MAX_AGE = 30 * 60 * 1000;         // fetch again after 30 minutes
  const RETRY_AFTER = 5 * 60 * 1000;      // after a failed fetch, wait 5 minutes before trying again

  // Built-in rules (what the extension used before live rules). "re:" keys are patterns, the rest are selectors.
  const BUILT_IN = {
    maps: {
      feed: ['div[role="feed"]'],
      card: ['div[role="article"]'],
      placeLink: ['a[href*="/maps/place/"]'],
      stars: ['span[role="img"][aria-label]'],
      phone: [".UsdlK"],
      site: ['a[data-value][href^="http"]'],
      placeName: ["h1"],
      placeAddress: ['button[data-item-id="address"]'],
      placePhone: ['button[data-item-id^="phone"]'],
      placeSite: ['a[data-item-id="authority"]'],
      placeCategory: ['button[jsaction*="category"]'],
      "re:endOfList": ["reached the end of the list"],
      "re:notAddress": ["^(open|closed|opens|closes|temporarily|permanently|24 hours|website|directions|book|order|reserve|get quote|on-site|online)"],
    },
    search: {
      heading: ["#search a h3, #rso a h3"],
    },
    google: {
      // Safety checks: every entry is checked (live entries only add to these).
      signedIn: ['a[aria-label^="Google Account"]', 'a[href^="https://accounts.google.com/SignOutOptions"]'],
      "re:blocked": ["unusual traffic"],
    },
  };
  const SAFETY = new Set(["google.signedIn", "google.re:blocked"]);

  const okString = (s) => typeof s === "string" && s.length > 0 && s.length <= 300 && !/[\u0000-\u001f\u007f]/.test(s);
  // Patterns: must compile, and no nested repeats like (a+)+ or (a*)* that can freeze a page.
  function okPattern(s) {
    if (!okString(s) || /\([^()]*[+*}][^()]*\)\s*[+*{]/.test(s) || /\\[1-9]/.test(s)) return false;
    try { new RegExp(s, "i"); return true; } catch (_) { return false; }
  }
  function okSelector(s) {
    if (!okString(s)) return false;
    if (typeof document === "undefined" || !document.createDocumentFragment) return true;   // checked again in the page
    try { document.createDocumentFragment().querySelector(s); return true; } catch (_) { return false; }
  }

  // Keep only known keys with valid values. Returns { section: { key: [values] } }.
  function clean(raw) {
    const out = {};
    if (!raw || typeof raw !== "object" || raw.schema !== 1) return out;
    for (const section of Object.keys(BUILT_IN)) {
      const given = raw[section];
      if (!given || typeof given !== "object" || Array.isArray(given)) continue;
      for (const key of Object.keys(BUILT_IN[section])) {
        if (!Object.prototype.hasOwnProperty.call(given, key)) continue;
        const list = (Array.isArray(given[key]) ? given[key] : [given[key]]).slice(0, 5);
        const ok = list.filter(key.startsWith("re:") ? okPattern : okSelector);
        if (ok.length) (out[section] = out[section] || {})[key] = ok;
      }
    }
    return out;
  }

  // Live values first, then the built-in ones (no duplicates).
  function merge(live) {
    const out = {};
    for (const section of Object.keys(BUILT_IN)) {
      out[section] = {};
      for (const key of Object.keys(BUILT_IN[section])) {
        const add = (live[section] && live[section][key]) || [];
        out[section][key] = [...new Set([...add, ...BUILT_IN[section][key]])];
      }
    }
    return out;
  }

  let current = merge({}), info = { updated: "", at: 0, from: "built-in" };

  async function readCache() {
    try { const got = await chrome.storage.local.get(CACHE_KEY); return got[CACHE_KEY] || null; } catch (_) { return null; }
  }

  // Load the rules: the saved copy, refreshed from kestrelleads.com when older than 30 minutes. Never throws; offline
  // or on any error the extension keeps the last good copy, or the built-in rules.
  async function load(force) {
    const cache = await readCache();
    if (cache && cache.rules) { current = merge(clean(cache.rules)); info = { updated: cache.rules.updated || "", at: cache.at || 0, from: "saved" }; }
    const at = (cache && cache.at) || 0, failedAt = (cache && cache.failedAt) || 0;
    const waitFor = failedAt > at ? RETRY_AFTER : MAX_AGE;   // a failed try waits 5 minutes, a good copy 30
    if (!force && cache && Date.now() - Math.max(at, failedAt) < waitFor) return current;
    try {
      const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), 6000);
      const res = await fetch(RULES_URL, { cache: "no-store", credentials: "omit", signal: ctl.signal });
      clearTimeout(timer);
      if (!res.ok) throw new Error(String(res.status));
      const text = await res.text();
      if (text.length > 20000) throw new Error("too large");
      const rules = JSON.parse(text);
      const safe = clean(rules);
      current = merge(safe);
      info = { updated: typeof rules.updated === "string" ? rules.updated.slice(0, 20) : "", at: Date.now(), from: "live" };
      await chrome.storage.local.set({ [CACHE_KEY]: { at: info.at, rules: { schema: 1, updated: info.updated, ...safe } } });
    } catch (_) {
      try { await chrome.storage.local.set({ [CACHE_KEY]: { ...(cache || {}), failedAt: Date.now() } }); } catch (_) { /* storage full or closed */ }
    }
    return current;
  }

  const api = { URL: RULES_URL, BUILT_IN, SAFETY, clean, merge, okPattern, okSelector, load, get: (section) => current[section], info: () => info };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.QuarryRules = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
