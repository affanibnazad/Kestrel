// Licence and update settings for this build.
//
// OWNER BUILD: leave provider empty. Kestrel opens with no key (this is Affan's own copy).
// SELLING BUILD: set provider to "lemonsqueezy" and fill storeId and productId from your Lemon Squeezy dashboard.
//   Store IDs and product IDs are public numbers, not secrets. Never put an API key in this file:
//   anything inside an extension can be read by the people who install it.
//
// updateUrl: optional. A public link to a small JSON file like
//   {"version": "2.7.0", "notes": "What changed", "url": "https://where-to-download"}
//   Kestrel checks it once a day and shows "Update ready" when the number is higher.
//   Not needed for Chrome Web Store copies: the store updates them by itself.
//
// tiers: which Lemon Squeezy variant IDs belong to which plan (see core/plans.js for the limits).
// features: a whole edition can switch modes off (the "safe" edition has no Google modes).
// upgradeUrl / manageUrl: your pricing page and the Lemon Squeezy customer portal.
globalThis.QuarryLicenseConfig = {
  provider: "kestrel",
  storeId: 0,
  productId: 0,
  buyUrl: "https://kestrelleads.com/pricing",
  upgradeUrl: "",
  manageUrl: "",
  updateUrl: "",
  graceDays: 7,
  tiers: { starter: [], pro: [], agency: [] },
  features: { maps: true, search: true, youtube: true, osm: true, jobs: true, companies: true, podcasts: true, page: true, sites: true },
};
