// Official data sources (no scraping): job boards (Greenhouse, Lever, Ashby), UK Companies House, Listen Notes, Hunter.io.
// Pure request builders and parsers, so they can be tested without the network. Keys are passed in, never stored here.
(function (root) {
  const L = root.QuarryLib;

  // ---------- hiring signals: public job boards ----------
  const DEFAULT_JOB_WORDS = "video|editor|motion|post[- ]?production|videographer|animator|content (creator|producer)|youtube|reels|tiktok";
  // Finds the company's job board from its website HTML.
  function detectBoards(html) {
    const s = String(html || ""), out = [], seen = new Set();
    const add = (ats, token, eu) => { const t = String(token || "").toLowerCase(); const k = `${ats}:${t}`; if (t && !/^(embed|jobs?|careers?|api|v\d)$/.test(t) && !seen.has(k)) { seen.add(k); out.push({ ats, token: t, eu: !!eu }); } };
    for (const m of s.matchAll(/(?:job-)?boards(\.eu)?\.greenhouse\.io\/(?:embed\/job_board(?:\/js)?\?for=)?([a-z0-9_-]+)/gi)) add("greenhouse", m[2], m[1]);
    for (const m of s.matchAll(/job-boards(\.eu)?\.greenhouse\.io\/([a-z0-9_-]+)/gi)) add("greenhouse", m[2], m[1]);
    for (const m of s.matchAll(/jobs(\.eu)?\.lever\.co\/([a-z0-9_.-]+)/gi)) add("lever", m[2], m[1]);
    for (const m of s.matchAll(/jobs\.ashbyhq\.com\/([a-z0-9_.%-]+)/gi)) add("ashby", decodeURIComponent(m[1]));
    return out;
  }
  // "greenhouse:acme", "https://jobs.lever.co/acme", "jobs.ashbyhq.com/Acme"
  function parseBoardLine(line) {
    const t = String(line || "").trim();
    const m = /^(greenhouse|lever|ashby)\s*[:/]\s*([a-z0-9_.%-]+)$/i.exec(t);
    if (m) return { ats: m[1].toLowerCase(), token: m[2].toLowerCase(), eu: false };
    return detectBoards(t)[0] || null;
  }
  function boardUrl(b) {
    if (b.ats === "greenhouse") return `https://boards-api.greenhouse.io/v1/boards/${encodeURIComponent(b.token)}/jobs`;
    if (b.ats === "lever") return `https://api${b.eu ? ".eu" : ""}.lever.co/v0/postings/${encodeURIComponent(b.token)}?mode=json`;
    if (b.ats === "ashby") return `https://api.ashbyhq.com/posting-api/job-board/${encodeURIComponent(b.token)}`;
    return "";
  }
  function parseJobs(ats, data) {
    if (ats === "greenhouse") return ((data && data.jobs) || []).map((j) => ({ title: j.title, url: j.absolute_url, location: (j.location || {}).name || "", at: j.updated_at || "" }));
    if (ats === "lever") return (Array.isArray(data) ? data : []).map((j) => ({ title: j.text, url: j.hostedUrl, location: (j.categories || {}).location || "", at: j.createdAt ? new Date(j.createdAt).toISOString() : "" }));
    if (ats === "ashby") return ((data && data.jobs) || []).filter((j) => j.isListed !== false).map((j) => ({ title: j.title, url: j.jobUrl, location: j.location || "", at: j.publishedAt || "" }));
    return [];
  }
  function jobWords(text) { try { return new RegExp(String(text || "").trim() || DEFAULT_JOB_WORDS, "i"); } catch (_) { return new RegExp(DEFAULT_JOB_WORDS, "i"); } }
  // Job titles on an agency's own careers page (no job board). Short headings, links or list items that name a role
  // and match the job words, for example "Video Editor (Freelance)".
  const ROLE = /(editor|videographer|animator|producer|designer|creator|artist|specialist|executive|manager|assistant|intern|lead|director|operator|shooter|cinematographer)\b/i;
  function careersJobs(html, url, words) {
    const re = jobWords(words), seen = new Set(), out = [];
    const strip = (x) => String(x).replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/&nbsp;|&#160;/g, " ").replace(/&#39;|&rsquo;/g, "'").replace(/\s+/g, " ").trim();
    for (const m of String(html || "").matchAll(/<(h[1-5]|a|li|strong|dt)\b[^>]*>([\s\S]{2,300}?)<\/\1>/gi)) {
      const title = strip(m[2]);
      if (title.length < 5 || title.length > 80 || !re.test(title) || !ROLE.test(title) || seen.has(title.toLowerCase())) continue;
      seen.add(title.toLowerCase());
      out.push({ title, location: "", url, from: "careers page" });
      if (out.length >= 10) break;
    }
    return out;
  }
  const matchingJobs = (jobs, words) => jobs.filter((j) => j.title && jobWords(words).test(j.title)).slice(0, 20);
  const titleCase = (s) => String(s || "").replace(/[-_.]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

  // ---------- UK Companies House (official, free key) ----------
  const CH_BASE = "https://api.company-information.service.gov.uk";
  const CH_PRESETS = [
    ["Advertising and marketing agencies", "73110,73120"],
    ["PR and communications", "70210"],
    ["Video, film and TV production", "59111,59112,59113"],
    ["Design studios", "74100"],
    ["Post-production (competitors, for research)", "59120"],
    ["Advertising agencies only", "73110"],
    ["Media buying and representation", "73120"],
    ["Video production only", "59112"],
    ["Film production", "59111"],
    ["TV programme production", "59113"],
    ["Podcast and audio production (sound recording)", "59200"],
    ["Photography studios", "74201,74202,74209"],
    ["Market research", "73200"],
    ["Event and conference organisers", "82301,82302"],
    ["Magazine and online publishers", "58142,58190"],
    ["Web portals and online media", "63120"],
    ["Business and management consultancy", "70229"],
    ["Web and digital agencies (noisy: many software firms)", "62012,62020,62090"],
    ["Online shops (e-commerce brands)", "47910"],
    ["Artists and content creators", "90030"],
  ];
  const chAuth = (key) => `Basic ${btoa(`${String(key || "").trim()}:`)}`;
  function chSearchUrl({ sic, location, start = 0, size = 100 }) {
    const p = new URLSearchParams({ company_status: "active", size: String(Math.max(1, Math.min(5000, size))), start_index: String(start) });
    const codes = String(sic || "").split(/[^0-9]+/).filter((c) => /^\d{4,5}$/.test(c));
    if (codes.length) p.set("sic_codes", codes.join(","));
    if (String(location || "").trim()) p.set("location", String(location).trim());
    return `${CH_BASE}/advanced-search/companies?${p}`;
  }
  const chOfficersUrl = (number) => `${CH_BASE}/company/${encodeURIComponent(number)}/officers?items_per_page=20`;
  const prettyCase = (s) => String(s || "").toLowerCase().replace(/\b([a-z])/g, (c) => c.toUpperCase()).replace(/\b(Llp|Plc|Uk|Cic)\b/g, (w) => w.toUpperCase());
  // "SMITH, John Paul" -> "John Paul Smith"
  function personName(n) { const [last, first] = String(n || "").split(","); return prettyCase(first ? `${first.trim()} ${last.trim()}` : last); }
  // Active directors only, at most 3. Public register data, kept to name and role.
  function chOfficers(data) {
    return ((data && data.items) || []).filter((o) => !o.resigned_on && /director|member/i.test(o.officer_role || ""))
      .slice(0, 3).map((o) => ({ name: personName(o.name), role: prettyCase(String(o.officer_role || "").replace(/-/g, " ")) }));
  }
  function chToLead(item, ctx) {
    const a = item.registered_office_address || {};
    const address = [a.address_line_1, a.address_line_2, a.locality, a.postal_code].filter(Boolean).join(", ");
    return L.newLead("companies", {
      id: `ch:${item.company_number}`, name: prettyCase(item.company_name), category: ctx.category || `SIC ${(item.sic_codes || []).join(", ")}`,
      address, location: ctx.location || a.locality || "", keyword: ctx.category || "", url: `https://find-and-update.company-information.service.gov.uk/company/${item.company_number}`,
      description: [item.date_of_creation ? `Registered ${item.date_of_creation}` : "", (item.sic_codes || []).length ? `SIC ${item.sic_codes.join(", ")}` : ""].filter(Boolean).join(". "),
      company: { number: item.company_number, created: item.date_of_creation || "", sic: item.sic_codes || [] },
    });
  }

  // ---------- Listen Notes (podcasts) ----------
  const LN_BASE = "https://listen-api.listennotes.com/api/v2";
  const LN_GENRES = [[93, "Business"], [97, "Marketing"], [127, "Technology"], [111, "Education"], [100, "Arts"], [68, "TV & Film"], [88, "Health & Fitness"], [122, "Society & Culture"]];
  const lnBestUrl = ({ genre, region, page = 1 }) => `${LN_BASE}/best_podcasts?${new URLSearchParams({ genre_id: String(genre || 93), region: String(region || "gb").toLowerCase(), page: String(page), safe_mode: "0" })}`;
  const lnSearchUrl = ({ q, region, offset = 0 }) => `${LN_BASE}/search?${new URLSearchParams({ q: String(q || ""), type: "podcast", offset: String(offset), ...(region ? { region: String(region).toLowerCase() } : {}) })}`;
  // Podcast apps are not the show's own website.
  const PLATFORM = /(^|\.)(apple\.com|spotify\.com|stitcher\.com|anchor\.fm|podbean\.com|buzzsprout\.com|libsyn\.com|simplecast\.com|megaphone\.fm|iheart\.com|soundcloud\.com|youtube\.com|listennotes\.com|podcasts\.google\.com|audible\.[a-z.]+|amazon\.[a-z.]+|transistor\.fm|captivate\.fm|acast\.com|omny\.fm|spreaker\.com)$/i;
  function showWebsite(url) {
    try {
      const u = new URL(url);
      if (PLATFORM.test(u.hostname)) return "";
      [...u.searchParams.keys()].filter((k) => /^utm_/i.test(k)).forEach((k) => u.searchParams.delete(k));
      return L.cleanWebsite(u.href);
    } catch (_) { return ""; }
  }
  function lnToLead(p, ctx) {
    const title = p.title || p.title_original || "", publisher = p.publisher || p.publisher_original || "";
    if (!title) return null;
    const email = /@/.test(p.email || "") ? String(p.email).trim() : "";
    return L.newLead("podcasts", {
      id: `ln:${p.id}`, name: publisher || title, category: "Podcast", location: p.country || ctx.region || "", keyword: ctx.label || "",
      description: `Podcast: ${title}${p.total_episodes ? `, ${p.total_episodes} episodes` : ""}${p.latest_pub_date_ms ? `, latest ${new Date(p.latest_pub_date_ms).toISOString().slice(0, 10)}` : ""}. ${String(p.description || p.description_original || "").replace(/<[^>]+>/g, " ").slice(0, 600)}`.trim(),
      website: showWebsite(p.website || ""), url: p.listennotes_url || "", emails: email ? [email] : [],
      podcast: { title, episodes: p.total_episodes || 0, latest: p.latest_pub_date_ms || 0, rss: p.rss || "" },
    });
  }

  // ---------- Hunter.io (emails for a website or a company name) ----------
  const HUNTER = "https://api.hunter.io/v2";
  function hunterUrl(lead, key) {
    const domain = L.hostOf(lead.website);
    const p = new URLSearchParams({ limit: "10", api_key: String(key || "").trim() });
    if (domain) p.set("domain", domain); else if (lead.name) p.set("company", lead.name); else return "";
    return `${HUNTER}/domain-search?${p}`;
  }
  const hunterAccountUrl = (key) => `${HUNTER}/account?${new URLSearchParams({ api_key: String(key || "").trim() })}`;
  const DECIDER = /founder|owner|director|ceo|chief|managing|partner|head|lead|creative|producer|principal|president/i;
  // Best contacts first: decision makers, then senior people, then a general inbox.
  function hunterPick(data) {
    const d = (data && data.data) || {}, list = d.emails || [];
    const score = (e) => (e.decision_maker ? 40 : 0) + (DECIDER.test(e.position || "") ? 30 : 0) + (e.seniority === "executive" ? 20 : e.seniority === "senior" ? 10 : 0) + (e.type === "personal" ? 5 : 0) + (Number(e.confidence) || 0) / 10;
    const sorted = list.filter((e) => e && /@/.test(e.value || "") && (Number(e.confidence) || 0) >= 50 && (e.verification || {}).status !== "invalid").sort((a, b) => score(b) - score(a));
    const contacts = sorted.filter((e) => e.type === "personal" && (e.first_name || e.last_name)).slice(0, 3)
      .map((e) => ({ name: [e.first_name, e.last_name].filter(Boolean).join(" "), position: e.position || "", email: e.value }));
    return { domain: d.domain || "", organization: d.organization || "", emails: sorted.map((e) => e.value), contacts };
  }
  function hunterCredits(data) {
    const a = (data && data.data) || {}, r = a.requests || {}, c = r.credits || r.searches || {};
    return { plan: a.plan_name || "", used: c.used ?? null, available: c.available ?? null, reset: a.reset_date || "" };
  }

  const api = {
    DEFAULT_JOB_WORDS, detectBoards, parseBoardLine, boardUrl, parseJobs, jobWords, matchingJobs, careersJobs, titleCase,
    CH_BASE, CH_PRESETS, chAuth, chSearchUrl, chOfficersUrl, chOfficers, chToLead, personName,
    LN_BASE, LN_GENRES, lnBestUrl, lnSearchUrl, lnToLead, showWebsite,
    hunterUrl, hunterAccountUrl, hunterPick, hunterCredits,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QuarrySources = api;
})(globalThis);
