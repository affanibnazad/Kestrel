// The toolbar icon opens the side-panel console. All work happens there.
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

// Updates never cut a run: Chrome tells us a new version is downloaded; Kestrel shows "Restart" when no search is running.
// While a run is active, the side panel sends a small "running" message every 20 seconds, which keeps this worker awake,
// so Chrome waits and installs the update after the run instead of in the middle of it.
chrome.runtime.onUpdateAvailable.addListener((details) => {
  chrome.storage.local.set({ updateWaiting: details.version });
});
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg && msg.type === "quarry-running") reply({ ok: true });
});

// Kestrel App (kestrelleads.com) connects the extension: App → Settings → Extension → Connect the extension.
// Only the pages listed in manifest "externally_connectable" can send these messages; we check the address again here.
importScripts("core/cloud.js");
const APP_ORIGINS = ["https://kestrelleads.com", "https://www.kestrelleads.com", "http://localhost:3100", "http://localhost:3200"];
chrome.runtime.onMessageExternal.addListener((msg, sender, reply) => {
  let origin = "";
  try { origin = new URL(sender.url || sender.origin || "").origin; } catch (_) { /* unknown */ }
  if (!APP_ORIGINS.includes(origin) || !msg || typeof msg.type !== "string") { reply({ ok: false, error: "Not allowed" }); return false; }
  const version = chrome.runtime.getManifest().version;
  if (msg.type === "kestrel-ping") {
    QuarryCloud.conn().then((c) => reply({ ok: true, version, connected: Boolean(c && c.token), team: c ? c.team : "", email: c ? c.email : "" }));
    return true;
  }
  if (msg.type === "kestrel-connect") {
    QuarryCloud.connect(msg).then((me) => reply({ ok: true, version, team: me && me.team })).catch((e) => reply({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === "kestrel-disconnect") {
    QuarryCloud.disconnect().then(() => reply({ ok: true }));
    return true;
  }
  reply({ ok: false, error: "Unknown request" });
  return false;
});
