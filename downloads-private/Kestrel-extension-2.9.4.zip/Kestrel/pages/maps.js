// Injected into a Google Maps results tab. options.rules = page rules from core/rules.js (lists: live first, then built-in).
globalThis.__quarryMaps = async (options) => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const R = options.rules || {};
  const list = (key, base) => (Array.isArray(R[key]) && R[key].length ? R[key] : [base]);
  // The first selector in the list that finds something wins; a bad selector is skipped.
  const one = (root, key, base) => { for (const s of list(key, base)) { try { const el = root.querySelector(s); if (el) return el; } catch (_) { /* bad selector */ } } return null; };
  const many = (root, key, base) => { for (const s of list(key, base)) { try { const els = root.querySelectorAll(s); if (els.length) return [...els]; } catch (_) { /* bad selector */ } } return []; };
  const re = (p) => { try { return new RegExp(p, "i"); } catch (_) { return null; } };
  const anyText = (key, base, text) => list(key, base).some((p) => { const r = re(p); return r ? r.test(text) : false; });
  // Safety: every blocked pattern is checked, and the built-in one always is.
  const blockedList = [...new Set([...(Array.isArray(options.blocked) ? options.blocked : []), "unusual traffic"])];
  const blocked = () => location.pathname.startsWith("/sorry") || blockedList.some((p) => { const r = re(p); return r ? r.test(document.body.innerText.slice(0, 3000)) : false; });
  if (location.hostname.startsWith("consent.")) return { status: "consent", places: [] };
  if (blocked()) return { status: "blocked", places: [] };

  let feed = null;
  for (let i = 0; i < 120 && !feed; i++) {
    feed = one(document, "feed", 'div[role="feed"]');
    if (feed || one(document, "placeAddress", 'button[data-item-id="address"]')) break;
    await sleep(150);
  }
  if (!feed) {
    const name = (one(document, "placeName", "h1") || {}).innerText || "";
    if (!name || !one(document, "placeAddress", 'button[data-item-id="address"]')) return { status: "ok", places: [] };
    const label = (key, base) => { const el = one(document, key, base); return el ? (el.getAttribute("aria-label") || "").replace(/^[^:]+:\s*/, "").trim() : ""; };
    const site = one(document, "placeSite", 'a[data-item-id="authority"]');
    return { status: "ok", places: [{ name, category: (one(document, "placeCategory", 'button[jsaction*="category"]') || {}).innerText || "",
      address: label("placeAddress", 'button[data-item-id="address"]'), phone: label("placePhone", 'button[data-item-id^="phone"]'), website: site ? site.href : "", url: location.href, rating: "", reviews: "" }] };
  }

  let last = 0, still = 0;
  const cards = () => many(feed, "card", 'div[role="article"]').length;
  const atEnd = () => anyText("re:endOfList", "reached the end of the list", feed.innerText.slice(-400));
  for (let i = 0; i < options.scrollRounds && still < 4; i++) {
    feed.scrollTop = feed.scrollHeight;
    const before = cards();
    for (let t = 0; t < 20 && cards() === before && !atEnd(); t++) await sleep(100);
    if (blocked()) return { status: "blocked", places: [] };
    const count = cards();
    if (options.maxPerSearch && count >= options.maxPerSearch) break;
    still = count === last ? still + 1 : 0;
    last = count;
    if (atEnd()) break;
  }

  const notAddress = re(list("re:notAddress", "")[0]) || /^(open|closed|opens|closes|temporarily|permanently|24 hours|website|directions|book|order|reserve|get quote|on-site|online)/i;
  const places = many(feed, "card", 'div[role="article"]').map((card) => {
    const link = one(card, "placeLink", 'a[href*="/maps/place/"]');
    const name = link ? (link.getAttribute("aria-label") || "").trim() : "";
    const stars = one(card, "stars", 'span[role="img"][aria-label]');
    let rating = stars ? (stars.getAttribute("aria-label").match(/(\d[.,]\d)\D+([\d,]+)/) || []) : [];
    if (!rating[1]) {
      // Some sessions render the rating as plain text: "5.0(44)", or "5.0" and "(44)" on separate lines.
      const pieces = card.innerText.split("\n").map((t) => t.trim());
      const at = pieces.findIndex((t) => /^\d[.,]\d(\s*\(|$)/.test(t));
      if (at >= 0) {
        const count = pieces[at].match(/\(([\d,]+)\)/) || (pieces[at + 1] || "").match(/^\(([\d,]+)\)$/);
        rating = [null, pieces[at].slice(0, 3).replace(",", "."), count ? count[1] : ""];
      }
    }
    const phoneEl = one(card, "phone", ".UsdlK");
    const phone = (phoneEl ? phoneEl.innerText : (card.innerText.match(/\+?\d[\d\s().-]{7,}\d/) || [""])[0]).trim();
    const tokens = card.innerText.split(/\n|\s+·\s+/).map((t) => t.replace(/[-​-‏⁠﻿]/g, "").replace(/^·$/, "").trim())
      .filter((t) => t && t !== name && t !== "Sponsored" && !/^\d[.,]\d/.test(t) && !/^\(?[\d,]+\)?$/.test(t) && !/^No reviews/i.test(t));
    const second = tokens[1] || "";
    const site = one(card, "site", 'a[data-value][href^="http"]');
    return { name, category: tokens[0] || "", address: notAddress.test(second) || second === phone ? "" : second, phone,
      website: site ? site.href : "", url: link ? link.href : "", rating: rating[1] || "", reviews: (rating[2] || "").replace(/,/g, "") };
  }).filter((p) => p.name);
  return { status: "ok", places: options.maxPerSearch ? places.slice(0, options.maxPerSearch) : places };
};
