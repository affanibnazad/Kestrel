// Injected into a youtube.com tab (after core/lib.js). Reads YouTube's own pages from inside the site.
globalThis.__quarryYt = {
  state() {
    if (/consent\./.test(location.hostname)) return { state: "consent" };
    if (location.pathname.startsWith("/sorry") || /unusual traffic/i.test((document.body || {}).innerText || "")) return { state: "blocked" };
    // YouTube writes LOGGED_IN into its page settings; the avatar button is a second sign.
    const signedIn = [...document.scripts].some((s) => s.textContent.includes('"LOGGED_IN":true')) || !!document.querySelector("#avatar-btn");
    return { state: "ok", signedIn };
  },

  async get(url, init) {
    // No cookies: requests are never tied to a signed-in Google or YouTube account.
    const res = await fetch(url, { credentials: "omit", ...init });
    if (/consent\.(youtube|google)\.com/.test(res.url)) return { halt: "consent" };
    if (res.status === 429 || /\/sorry\//.test(res.url)) return { halt: "blocked" };
    if (!res.ok) return { error: `YouTube answered ${res.status}` };
    return { res };
  },

  async search(query, gl, pages) {
    const L = globalThis.QuarryLib;
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const first = await this.get(L.ytSearchUrl(query, gl));
    if (!first.res) return first;
    const html = await first.res.text();
    const data = L.ytInitialData(html);
    if (!data) return { error: "YouTube page could not be read" };
    const conf = L.ytConfig(html);
    let { channels, token } = L.ytChannels(data);
    for (let p = 1; p < pages && token && conf.key; p++) {
      await sleep(1200 + Math.random() * 900);
      const next = await this.get(`/youtubei/v1/search?key=${conf.key}&prettyPrint=false`, { method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ context: { client: { clientName: "WEB", clientVersion: conf.version, hl: "en", gl: gl || "US" } }, continuation: token }) });
      if (!next.res) break;
      const more = L.ytChannels(await next.res.json());
      channels = channels.concat(more.channels);
      token = more.token;
    }
    const seen = new Set();
    return { channels: channels.filter((c) => !seen.has(c.id) && seen.add(c.id)) };
  },

  async about(path) {
    const L = globalThis.QuarryLib;
    const got = await this.get(`${path}/about?hl=en`);
    if (!got.res) return got;
    return { about: L.ytAbout(L.ytInitialData(await got.res.text())) };
  },
};

// Channels visible on the page you have open: a channel, a video, or search results of any kind.
globalThis.__quarryYt.pageChannels = function () {
  const own = location.pathname.match(/^\/(@[^/?#]+|channel\/UC[\w-]+|c\/[^/?#]+|user\/[^/?#]+)/);
  if (own) return { page: "channel", channels: [{ path: `/${decodeURIComponent(own[1])}`, name: (document.querySelector("meta[property='og:title']") || {}).content || "" }] };
  const skip = "#masthead, ytd-guide-renderer, ytd-mini-guide-renderer, tp-yt-app-drawer, ytd-comments, ytd-comment-thread-renderer, #comments, ytd-live-chat-frame";
  const seen = new Map();
  for (const a of document.querySelectorAll("a[href]")) {
    if (a.closest(skip)) continue;
    const m = (a.getAttribute("href") || "").match(/^(?:https?:\/\/(?:www\.)?youtube\.com)?\/(@[^/?#]+|channel\/UC[\w-]+|c\/[^/?#]+|user\/[^/?#]+)/);
    if (!m) continue;
    const path = `/${decodeURIComponent(m[1])}`;
    const name = (a.innerText || a.getAttribute("title") || "").trim().split("\n")[0];
    if (!seen.has(path) || (!seen.get(path) && name)) seen.set(path, name && !name.startsWith("@") ? name : seen.get(path) || "");
  }
  const page = location.pathname.startsWith("/results") ? "search" : location.pathname.startsWith("/watch") ? "video" : "page";
  return { page, channels: [...seen].map(([path, name]) => ({ path, name })) };
};
