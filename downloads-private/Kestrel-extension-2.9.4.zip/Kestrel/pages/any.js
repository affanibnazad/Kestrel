// Injected into any page: finds repeating lists and reads them into leads.
globalThis.__quarryAny = globalThis.__quarryAny || (() => {
  const L = globalThis.QuarryLib;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let lists = [], marked = null;

  const signature = (el) => `${el.tagName}.${[...el.classList].filter((c) => !/\d/.test(c)).sort().slice(0, 3).join(".")}`;
  const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const inChrome = (el) => !!el.closest("nav, footer, header, aside, [role=navigation], [role=banner], [role=contentinfo]");

  function detect() {
    const found = [];
    for (const parent of document.body.querySelectorAll("*")) {
      if (parent.children.length < 3 || /^(SCRIPT|STYLE|SELECT|SVG|NOSCRIPT|HEAD)$/.test(parent.tagName) || inChrome(parent)) continue;
      const groups = new Map();
      for (const child of parent.children) {
        const sig = signature(child);
        if (!groups.has(sig)) groups.set(sig, []);
        groups.get(sig).push(child);
      }
      for (const [sig, items] of groups) {
        const shown = items.filter(visible);
        if (shown.length < 3 || shown.length < parent.children.length * 0.4) continue;
        const avg = shown.reduce((n, e) => n + e.innerText.trim().length, 0) / shown.length;
        if (avg < 12) continue;
        const links = shown.filter((e) => e.querySelector("a[href]") || e.closest("a")).length / shown.length;
        found.push({ parent, sig, count: shown.length, score: shown.length * Math.log(avg + 1) * (links > 0.5 ? 1.4 : 1) });
      }
    }
    found.sort((a, b) => b.score - a.score);
    const chosen = [];
    for (const item of found) {
      if (chosen.some((c) => (c.parent.contains(item.parent) || item.parent.contains(c.parent)) && Math.abs(c.count - item.count) <= c.count * 0.2)) continue;
      chosen.push(item);
      if (chosen.length === 6) break;
    }
    return chosen;
  }

  const items = (list) => [...list.parent.children].filter((c) => signature(c) === list.sig && visible(c));

  function readItem(el) {
    const heading = el.querySelector("h1,h2,h3,h4,h5,strong,[class*=title],[class*=name]");
    const anchors = [...el.querySelectorAll("a[href]"), ...(el.closest("a") ? [el.closest("a")] : [])].filter((a) => /^https?:/.test(a.href));
    const socials = {};
    let website = "";
    for (const a of anchors) {
      const hit = L.socialFromUrl(a.href);
      if (hit) socials[hit.key] = socials[hit.key] || hit.url;
      else if (!website && L.hostOf(a.href) !== L.hostOf(location.href)) website = L.cleanWebsite(a.href);
    }
    const text = el.innerText.replace(/\s+/g, " ").trim();
    const hrefs = [...el.querySelectorAll('a[href^="mailto:"]')].map((a) => a.href).join(" ");
    const tels = [...el.querySelectorAll('a[href^="tel:"]')].map((a) => a.href.slice(4));
    const name = ((heading && heading.innerText) || (anchors[0] && anchors[0].innerText) || text).replace(/\s+/g, " ").trim().slice(0, 120);
    return { name, url: anchors[0] ? anchors[0].href : location.href, website, text: text.slice(0, 500),
      emails: L.findEmails(`${hrefs} ${text}`), phones: tels.length ? tels : L.findPhones(text), socials };
  }

  function wholePage() {
    const html = document.documentElement.outerHTML;
    const site = L.parseSite(html, location.href);
    return [{ name: document.title || L.hostOf(location.href), url: location.href, website: location.origin + "/", text: site.description,
      emails: L.findEmails(`${site.emails.join(" ")} ${document.body.innerText}`), phones: site.phones.length ? site.phones : L.findPhones(document.body.innerText), socials: site.socials }];
  }

  return {
    scan() {
      if (location.pathname.startsWith("/sorry")) return { status: "blocked", lists: [] };
      lists = detect();
      return { status: "ok", title: document.title, lists: lists.map((l, i) => ({ index: i, count: l.count, sig: l.sig,
        sample: items(l).slice(0, 3).map((e) => e.innerText.replace(/\s+/g, " ").trim().slice(0, 70)) })) };
    },
    highlight(index) {
      if (marked) marked.style.outline = "";
      marked = null;
      if (index < 0 || !lists[index]) return;
      marked = lists[index].parent;
      marked.style.outline = "3px solid #FF5A1F";
      marked.scrollIntoView({ block: "center", behavior: "smooth" });
    },
    async collect(index, options) {
      if (index < 0) return { status: "ok", rows: wholePage() };
      for (let i = 0; i < options.scrolls; i++) { window.scrollTo(0, document.documentElement.scrollHeight); await sleep(1800); }
      lists = detect();
      const list = lists.find((l) => l.sig === options.sig) || lists[index];
      if (!list) return { status: "ok", rows: [] };
      if (marked) marked.style.outline = "";
      return { status: "ok", sig: list.sig, rows: items(list).map(readItem).filter((r) => r.name) };
    },
    next() {
      const link = document.querySelector('a[rel="next"], [aria-label="Next" i], [aria-label="Next page" i]')
        || [...document.querySelectorAll("a, button")].find((e) => /^(next|next page|›|»|→)\s*[›»→]?$/i.test(e.innerText.trim()));
      if (!link || link.disabled || link.getAttribute("aria-disabled") === "true") return false;
      link.click();
      return true;
    },
  };
})();
