// Injected into the Google Search results page that is open. rules = page rules from core/rules.js (live first, then built-in).
globalThis.__quarrySearch = (rules, blockedPatterns) => {
  if (location.hostname.startsWith("consent.")) return { status: "consent", results: [] };
  // Safety: every blocked pattern is checked, and the built-in one always is.
  const top = document.body.innerText.slice(0, 3000);
  const blocked = [...new Set([...(Array.isArray(blockedPatterns) ? blockedPatterns : []), "unusual traffic"])]
    .some((p) => { try { return new RegExp(p, "i").test(top); } catch (_) { return false; } });
  if (location.pathname.startsWith("/sorry") || blocked) return { status: "blocked", results: [] };
  if (location.pathname !== "/search") return { status: "notsearch", results: [] };
  const seen = new Set(), results = [];
  const lists = rules && Array.isArray(rules.heading) && rules.heading.length ? rules.heading : ["#search a h3, #rso a h3"];
  let headings = [];
  for (const sel of lists) { try { headings = [...document.querySelectorAll(sel)]; } catch (_) { headings = []; } if (headings.length) break; }
  for (const heading of headings) {
    const link = heading.closest("a");
    if (!link || !link.href.startsWith("http") || seen.has(link.href)) continue;
    seen.add(link.href);
    let box = link;
    for (let i = 0; i < 6 && box.parentElement && box.innerText.length < heading.innerText.length + 40; i++) box = box.parentElement;
    results.push({ title: heading.innerText.trim(), url: link.href, text: box.innerText.replace(/\s+/g, " ").trim() });
  }
  return { status: "ok", results };
};
