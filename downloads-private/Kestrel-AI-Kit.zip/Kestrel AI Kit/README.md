# Kestrel AI Kit: START HERE

Score your Kestrel leads and write personal first emails with your own Claude Code or Codex plan.
No API key, no extra cost per lead. Nothing in this kit sends emails or needs a password.

## 1. Set up once (5 minutes)
1. Keep this folder somewhere safe, for example Documents/Kestrel AI Kit. Do not rename the jobs/ and results/ folders.
2. Install Claude Code (claude.com/code) or Codex, if you do not have one yet.
3. Open this folder in it:
   - Claude Code app: File -> Open Folder -> choose "Kestrel AI Kit".
   - Terminal: cd into this folder, then type: claude
4. In Kestrel (kestrelleads.com/app) -> Assistant -> Score and write -> "Claude Code or Codex" card ->
   Connect folder -> choose this "Kestrel AI Kit" folder. (Chrome, Edge or Brave. In Safari or Firefox, skip this:
   the job file goes to Downloads and the kit picks it up from there by itself.)

## 2. Score leads (Good / Maybe / No)
1. Kestrel: Send fit job. The job lands in jobs/ by itself.
2. Claude Code: type  /score-leads      (Codex: "score the newest Kestrel job")
3. Kestrel finds the result in results/ by itself and saves every verdict. (Without a connected folder: Upload results.)

## 3. Write first emails and follow-ups
1. Kestrel: Send email job.
2. Claude Code: type  /write-emails     (Codex: "write the newest Kestrel email job")
3. Kestrel picks the drafts up from results/ by itself.

## The folders
| Folder | What is in it |
|---|---|
| jobs/ | Jobs from Kestrel. Finished jobs move to jobs/done/. |
| results/ | Results for Kestrel. Imported ones move to results/imported/. |
| tools/ | Two small helper scripts the commands use. |
| prompts/ | A prompt that helps you write your offer, and the first email rules. |

## Write your offer first
Open prompts/ai-fit-profile-writer.txt, answer the questions, paste it into any AI chat, and copy the answers into
Kestrel -> Rules and scoring (What you sell, Ideal customer, Good signs, Disqualifiers).
