Read AGENTS.md in this folder and follow it. It is the full map of what to do and the rules.
