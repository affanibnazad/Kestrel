Results for Kestrel appear here; Kestrel picks them up by itself and moves them to results/imported/.
