Kestrel puts job files here. Finished jobs move to jobs/done/.
