# First email rules (what Kestrel's email writer follows)

- The only goal of a first email is a reply. No price, packages, trials, free work, discounts or payment.
- Greeting, one personal line about that business (from its own public details), one line on what you do, one clear question about their own work.
- If the email could go to another business unchanged, rewrite it.
- Plain words. No AI-style words (leverage, elevate, seamless, unlock, tailored, delve, robust), no spam words, nothing that looks like phishing.
- Never invent clients, results, numbers or testimonials.
- Every email has your real sender name, a postal address and an easy way to say no.
- Read every draft before sending. Kestrel never sends emails itself.
