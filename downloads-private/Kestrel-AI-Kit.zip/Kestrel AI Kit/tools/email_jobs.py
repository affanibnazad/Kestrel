#!/usr/bin/env python3
"""Writes the personal parts of Kestrel emails through Claude Code or Codex, batch by batch.

  python3 email_jobs.py status
  python3 email_jobs.py next [count]      print the rules and the next leads
  python3 email_jobs.py save              read drafts as JSON on stdin
  python3 email_jobs.py finish            write the results file for Kestrel

Jobs are read from the folder in QUARRY_AI_DIR; or, inside the Kestrel AI Kit (a .kestrel-kit file next to tools/), from
the kit's jobs/ folder, with results written to its results/ folder; otherwise from ~/Downloads/kestrel/ai
(older files: ~/Downloads/quarry/ai). Job files saved straight into Downloads are picked up too.

Version 1 jobs (the extension, and the App without follow-ups) ask for first_name, subject, icebreaker, question.
Version 2 jobs (the App with a sequence) also ask for follow_up_1 .. follow_up_3: they are listed in the job's "fields".
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

FIELDS = ("first_name", "subject", "icebreaker", "question")
FOLLOW_UPS = ("follow_up_1", "follow_up_2", "follow_up_3")
# one_line (19 Nov 2026): the sender's one line reworded for each email; only when the job asks for it.
EXTRAS = ("one_line",)
LIMITS = {"first_name": 60, "subject": 80, "icebreaker": 220, "question": 160, "one_line": 240, **{f: 400 for f in FOLLOW_UPS}}


def fields_of(job: dict) -> tuple:
    # The four first-email fields always; follow-ups only when the job asks for them (version 2).
    asked = job.get("fields") if isinstance(job.get("fields"), list) else []
    return FIELDS + tuple(f for f in EXTRAS + FOLLOW_UPS if f in asked)


KIT = Path(__file__).resolve().parent.parent


def in_kit() -> bool:
    # The Kestrel AI Kit downloaded from the App has a .kestrel-kit file at its top.
    return not os.environ.get("QUARRY_AI_DIR") and (KIT / ".kestrel-kit").exists()


def folder() -> Path:
    if os.environ.get("QUARRY_AI_DIR"):
        return Path(os.environ["QUARRY_AI_DIR"]).expanduser()
    if in_kit():
        return KIT / "jobs"
    # Kestrel saves to Downloads/kestrel; Kestrel (its old name) saved to Downloads/quarry.
    new, old = Path("~/Downloads/kestrel/ai").expanduser(), Path("~/Downloads/quarry/ai").expanduser()
    return new if new.exists() or not old.exists() else old


def fail(message: str) -> None:
    print(message, file=sys.stderr)
    sys.exit(1)


def adopt_downloads() -> None:
    # The Kestrel App (website) saves job files straight into Downloads: move them into the job folder.
    if os.environ.get("QUARRY_AI_DIR"):
        return
    for p in Path("~/Downloads").expanduser().glob("email_job_*.json"):
        target = folder()
        target.mkdir(parents=True, exist_ok=True)
        if not (target / p.name).exists():
            p.rename(target / p.name)


def newest_job() -> Path:
    adopt_downloads()
    jobs = sorted((p for p in folder().glob("email_job_*.json") if not p.name.endswith(".progress.json")), key=lambda p: p.stat().st_mtime)
    if not jobs:
        fail(f"No email job found in {folder()}. Click Export Email Job in Kestrel first.")
    return jobs[-1]


def load_job(path: Path) -> dict:
    try:
        job = json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        fail(f"{path.name} is not valid JSON.")
    if job.get("type") != "quarry-email-job":
        fail(f"{path.name} is not a Kestrel email job.")
    return job


def progress_path(job_path: Path) -> Path:
    return job_path.with_suffix(".progress.json")


def load_progress(job_path: Path) -> dict:
    path = progress_path(job_path)
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def remaining(job: dict, done: dict) -> list:
    return [lead for lead in job["leads"] if lead["id"] not in done]


def cmd_status() -> None:
    path = newest_job()
    job, done = load_job(path), load_progress(path)
    print(json.dumps({"job": path.name, "fields": list(fields_of(job)), "total": len(job["leads"]), "done": len(done), "left": len(remaining(job, done))}))


def cmd_next(count: int) -> None:
    path = newest_job()
    job, done = load_job(path), load_progress(path)
    out = {"rules": job["rules"], "fields": list(fields_of(job)), "left": len(remaining(job, done)), "leads": remaining(job, done)[:count]}
    if job.get("sequence"):
        out["sequence"] = job["sequence"]  # the steps the texts go into, for context only
    print(json.dumps(out, ensure_ascii=False, indent=1))


def cmd_save() -> None:
    path = newest_job()
    job, done = load_job(path), load_progress(path)
    try:
        items = json.loads(sys.stdin.read())
    except ValueError as error:
        fail(f"Input is not valid JSON: {error}")
    if not isinstance(items, list):
        fail("Input must be a JSON list.")
    known = {lead["id"] for lead in job["leads"]}
    fields = fields_of(job)
    saved, bad = 0, []
    for item in items:
        valid = isinstance(item, dict) and item.get("id") in known and all(isinstance(item.get(f), str) and item.get(f).strip() for f in fields)
        if not valid:
            bad.append(item.get("id") if isinstance(item, dict) else item)
            continue
        done[item["id"]] = {"id": item["id"], **{f: " ".join(item[f].split())[: LIMITS[f]] for f in fields}}
        saved += 1
    temporary = progress_path(path).with_suffix(".tmp")
    temporary.write_text(json.dumps(done, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, progress_path(path))
    print(json.dumps({"saved": saved, "rejected": bad, "left": len(remaining(job, done))}))


def cmd_finish() -> None:
    path = newest_job()
    job, done = load_job(path), load_progress(path)
    if not done:
        fail("Nothing has been written yet.")
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    results = KIT / "results" if in_kit() else folder()   # the kit: Kestrel picks results up from results/
    results.mkdir(parents=True, exist_ok=True)
    output = results / f"email_result_{stamp}.json"
    output.write_text(json.dumps({"type": "quarry-email-result", "results": list(done.values())}, ensure_ascii=False, indent=1), encoding="utf-8")
    archive = folder() / "done"
    archive.mkdir(exist_ok=True)
    shutil.move(str(path), str(archive / path.name))
    progress_path(path).unlink(missing_ok=True)
    print(json.dumps({"results": len(done), "left_unwritten": len(remaining(job, done)), "file": str(output)}))


def main() -> None:
    command = sys.argv[1] if len(sys.argv) > 1 else ""
    if command == "status":
        cmd_status()
    elif command == "next":
        cmd_next(int(sys.argv[2]) if len(sys.argv) > 2 else 20)
    elif command == "save":
        cmd_save()
    elif command == "finish":
        cmd_finish()
    else:
        fail(__doc__)


if __name__ == "__main__":
    main()
